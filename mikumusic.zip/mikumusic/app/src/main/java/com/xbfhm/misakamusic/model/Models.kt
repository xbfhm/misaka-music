package com.xbfhm.misakamusic.model

data class Song(
    val id: Long,
    val name: String,
    val artists: String,
    val album: String,
    val duration: Long,
    val cover: String
)

data class Playlist(
    val id: Long,
    val name: String,
    val cover: String,
    val trackCount: Int,
    val playCount: Long,
    val isLiked: Boolean = false
)
