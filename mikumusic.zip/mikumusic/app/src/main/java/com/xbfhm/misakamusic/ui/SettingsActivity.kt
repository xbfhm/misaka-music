package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivitySettingsBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.aboutCard.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
        binding.btnLogout.setOnClickListener { logout() }
        binding.btnRefreshVip.setOnClickListener { loadVip() }

        renderAccount()
        loadVip()
    }

    private fun renderAccount() {
        binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
        binding.tvUid.text = "${getString(R.string.uid_label)}: ${Session.uid}"
        Glide.with(this)
            .load(Session.avatar)
            .placeholder(R.drawable.ic_account)
            .error(R.drawable.ic_account)
            .into(binding.avatar)
    }

    private fun loadVip() {
        binding.tvVipStatus.text = getString(R.string.loading)
        binding.tvVipLevel.text = "--"
        binding.tvVipExpire.text = "--"
        scope.launch {
            val info = withContext(Dispatchers.IO) {
                NeteaseApi.vipInfo(this@SettingsActivity, Session.uid)
            }
            binding.tvVipStatus.text =
                if (info.isVip) getString(R.string.vip_yes) else getString(R.string.vip_no)
            binding.tvVipStatus.setTextColor(
                if (info.isVip) androidx.core.content.ContextCompat.getColor(this@SettingsActivity, R.color.net_red)
                else androidx.core.content.ContextCompat.getColor(this@SettingsActivity, android.R.color.darker_gray)
            )
            binding.tvVipLevel.text = info.level.ifEmpty { "--" }
            binding.tvVipExpire.text = info.expireTime.ifEmpty { "--" }
        }
    }

    private fun logout() {
        PlayerEngine.stopAndClear()
        Session.clearLogin()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
