package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityMainBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val adapter = PlaylistAdapter { p -> openPlaylist(p) }
    private var liked: Playlist? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvPlaylists.layoutManager = LinearLayoutManager(this)
        binding.rvPlaylists.adapter = adapter

        binding.avatar.setOnClickListener { showAccountDialog() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.likedCard.setOnClickListener {
            liked?.let { openPlaylist(it) } ?: toast("未找到「我喜欢的音乐」")
        }

        // 迷你播放条
        binding.miniBar.setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.miniPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updateMiniPlayer()
        }

        loadHeader()
        loadPlaylists()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { _ -> runOnUiThread { updateMiniPlayer() } }
        PlayerEngine.onPlayState = { runOnUiThread { updateMiniPlayer() } }
        updateMiniPlayer()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
    }

    private fun loadHeader() {
        binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
        Glide.with(this)
            .load(Session.avatar)
            .placeholder(R.drawable.ic_account)
            .error(R.drawable.ic_account)
            .into(binding.avatar)
    }

    private fun loadPlaylists() {
        scope.launch {
            if (Session.uid <= 0) {
                val info = withContext(Dispatchers.IO) { NeteaseApi.accountInfo(this@MainActivity) }
                val profile = info.optJSONObject("profile")
                Session.uid = profile?.optLong("userId", 0) ?: 0
                Session.nickname = profile?.optString("nickname", "") ?: ""
                Session.avatar = profile?.optString("avatarUrl", "") ?: ""
                loadHeader()
            }
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@MainActivity, Session.uid)
            }
            if (playlists.isEmpty()) {
                toast("未获取到歌单（请检查登录态）")
                return@launch
            }
            liked = playlists.firstOrNull { it.isLiked }
            if (liked != null) {
                binding.likedCard.visibility = View.VISIBLE
                binding.likedInfo.text = "${liked!!.trackCount} 首"
                Glide.with(this@MainActivity)
                    .load(liked!!.cover)
                    .placeholder(R.drawable.ic_music_note)
                    .into(binding.likedCover)
            } else {
                binding.likedCard.visibility = View.GONE
            }
            adapter.submit(playlists.filter { !it.isLiked })
        }
    }

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(this, PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        startActivity(intent)
    }

    private fun updateMiniPlayer() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            binding.miniBar.visibility = View.GONE
            return
        }
        binding.miniBar.visibility = View.VISIBLE
        binding.miniTitle.text = song.name
        binding.miniArtist.text = song.artists
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .into(binding.miniCover)
        binding.miniPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun showAccountDialog() {
        val items = arrayOf(getString(R.string.logout))
        MaterialAlertDialogBuilder(this)
            .setTitle(Session.nickname.ifEmpty { "网易云用户" })
            .setItems(items) { _: DialogInterface?, which: Int ->
                if (which == 0) logout()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun logout() {
        PlayerEngine.stopAndClear()
        Session.clearLogin()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
