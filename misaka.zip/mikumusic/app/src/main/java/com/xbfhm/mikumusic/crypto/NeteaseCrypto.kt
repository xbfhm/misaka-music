package com.xbfhm.mikumusic.crypto

import android.util.Base64
import java.math.BigInteger
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 网易云音乐加密协议 (对齐 NeteaseCloudMusicApi 4.32.0 util/crypto.js)
 * weapi: params = AES-CBC(AES-CBC(json)) base64, encSecKey = RSA(逆序secKey) hex
 * eapi : params = AES-ECB(url-json-md5 拼接串) 大写 hex
 * 算法已用真实接口验证 (2026-08-26)
 */
object NeteaseCrypto {

    private const val IV = "0102030405060708"
    private const val PRESET_KEY = "0CoJUm6Qyw8W8jud"
    private const val EAPI_KEY = "e82ckenh8dichen8"
    private const val BASE62 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    private const val MODULUS_HEX =
        "00e0b509f6259df8642dbc35662901477df22677ec152b5ff68ace615bb7b725152b3ab17a876aea8a5aa76d2e417629ec4ee341f56135fccf695280104e0312ecbda92557c93870114af6c9d05c4f7f0c3685b7a46bee255932575cce10b424d813cfe4875d3e82047b97ddef52741d546b8e289dc6935b3ece0462db0a22b8e7"

    fun randomString(n: Int): String {
        val sb = StringBuilder()
        repeat(n) { sb.append(BASE62[(Math.random() * 62).toInt()]) }
        return sb.toString()
    }

    private fun aesEncrypt(text: String, mode: String, key: String, iv: String, toHex: Boolean): String {
        val cipher = Cipher.getInstance("AES/$mode/PKCS5Padding")
        val keySpec = SecretKeySpec(key.toByteArray(Charsets.UTF_8), "AES")
        if (mode == "CBC") {
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, IvParameterSpec(iv.toByteArray(Charsets.UTF_8)))
        } else {
            cipher.init(Cipher.ENCRYPT_MODE, keySpec)
        }
        val enc = cipher.doFinal(text.toByteArray(Charsets.UTF_8))
        return if (toHex) {
            enc.joinToString("") { "%02X".format(it) }
        } else {
            Base64.encodeToString(enc, Base64.NO_WRAP)
        }
    }

    fun md5(s: String): String {
        val md = MessageDigest.getInstance("MD5")
        return md.digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    /** RSA 无填充模幂: c = m^e mod n, m = 逆序secKey的字节大整数, 输出 256 位 hex */
    private fun rsaEncrypt(text: String): String {
        val m = BigInteger(1, text.reversed().toByteArray(Charsets.UTF_8))
        val e = BigInteger("010001", 16)
        val n = BigInteger(MODULUS_HEX, 16)
        var hex = m.modPow(e, n).toString(16)
        while (hex.length < 256) hex = "0$hex"
        return hex
    }

    /** weapi 加密, 返回 (params, encSecKey) */
    fun weapi(objectJson: String): Pair<String, String> {
        val secretKey = randomString(16)
        val enc1 = aesEncrypt(objectJson, "CBC", PRESET_KEY, IV, toHex = false)
        val params = aesEncrypt(enc1, "CBC", secretKey, IV, toHex = false)
        val encSecKey = rsaEncrypt(secretKey)
        return params to encSecKey
    }

    /** eapi 加密, 返回 params (大写 hex) */
    fun eapi(url: String, objectJson: String): String {
        val message = "nobody${url}use${objectJson}md5forencrypt"
        val digest = md5(message)
        val data = "${url}-36cd479b6b5-${objectJson}-36cd479b6b5-${digest}"
        return aesEncrypt(data, "ECB", EAPI_KEY, "", toHex = true)
    }
}
