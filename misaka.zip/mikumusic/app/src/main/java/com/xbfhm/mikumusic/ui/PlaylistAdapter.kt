package com.xbfhm.mikumusic.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.mikumusic.R
import com.xbfhm.mikumusic.databinding.ItemPlaylistBinding
import com.xbfhm.mikumusic.model.Playlist

class PlaylistAdapter(
    private val onClick: (Playlist) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.VH>() {

    private val items = mutableListOf<Playlist>()

    fun submit(list: List<Playlist>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemPlaylistBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.binding.tvName.text = p.name
        holder.binding.tvInfo.text = "${p.trackCount} 首"
        Glide.with(holder.binding.cover)
            .load(p.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(holder.binding.cover)
        holder.binding.root.setOnClickListener { onClick(p) }
    }

    class VH(val binding: ItemPlaylistBinding) : RecyclerView.ViewHolder(binding.root)
}
