package com.xbfhm.mikumusic

import android.app.Application
import com.xbfhm.mikumusic.net.NeteaseApi
import com.xbfhm.mikumusic.net.Session
import com.xbfhm.mikumusic.player.PlayerEngine

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Session.init(this)
        PlayerEngine.init(this)
        PlayerEngine.urlResolver = { id -> NeteaseApi.resolvePlayUrl(this, id) }
    }
}
