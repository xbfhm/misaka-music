# MisakaMusic 🎵

一款极简 **Material Design 3** 风格的安卓网易云音乐第三方客户端。

App 内部实现网易云 `weapi` / `eapi` 加密协议，**无需任何服务器**，设备直连网易云音乐 API。

应用图标为《某科学的超电磁炮》御坂美琴。

<div align="center">

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Android](https://img.shields.io/badge/Android-6.0%2B-brightgreen.svg)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9.24-7F52FF.svg)
![API](https://img.shields.io/badge/API-23%2B-orange.svg)
![Build](https://github.com/xbfhm/misaka-music/actions/workflows/build.yml/badge.svg)

</div>

---

## ✨ 功能

### 登录
- **扫码登录（默认）**：二维码为网易云**网页版登录二维码**（`music.163.com/login?codekey=...`），
  用手机网易云音乐 App 扫码确认后自动收下 `MUSIC_U` 完成登录；
  只有一部手机时可「**保存二维码到相册**」，再用网易云「扫一扫 › 相册」识别
- Cookie 登录（备用，从浏览器复制 `MUSIC_U`）
- **登录状态检测**：启动/回前台自动校验 Cookie 是否失效，失效时弹窗提示重新登录；设置页也可手动检测

### 歌单与搜索
- 「我喜欢的音乐」、我的全部歌单
- **本地歌单**（未登录也能新建 / 重命名 / 删除 / 加歌 / 播放）
- 搜索歌曲 / 搜索用户（搜索栏只在搜索页，首页不再有假搜索框）+ 热门关键词快捷搜索
- 收藏歌单、添加歌曲到歌单（本地歌单与网易云歌单一起选）

### 播放
- 内置 Media3 / ExoPlayer 硬解播放，支持后台播放
- 状态栏通知 / 锁屏控制 / 蓝牙耳机控制
- 五种音质选择：Hi-Res / 无损 FLAC / 极高 320k / 较高 192k / 标准 128k，自动逐级降级
- 三种播放模式：顺序 / 循环 / 随机（洗牌袋算法，不重复），支持上一首历史回退
- 波形进度条（Namida 风格）
- 歌词显示（原文 + 翻译，支持偏移校准）
- **定时关闭**：预设 / 自定义分钟数，可「播完当前歌曲后停止」，最后 10 秒音量渐弱
- **定时播放**：设定每天某个时间自动开始播放上次的歌单（闹钟实现，进程被回收也能拉起）

### 个性化（v3.6 Liquid Glass）
- **动态取色**：从封面提取种子色并归一化成一套完整配色（主色/容器色/前景色），
  状态栏、底部导航、进度条、播放键、歌词高亮、列表高亮全站统一，换歌 420ms 平滑过渡；
  可在设置中关闭动态取色或改用固定主题色（10 种预设）
- **玻璃拟态（Liquid Glass）**：顶栏 / 迷你播放条 / 底部导航 / 搜索框 / 播放页信息卡 /
  歌词页操作条统一为「半透明白 + 高光描边」的磨砂玻璃，且底色会轻微带上主色
- **自定义背景**：6 张内置二次元插画 + 从相册选图（持久化授权）、毛玻璃强度、背景暗度、
  背景缓慢呼吸微动效（自研三次盒式模糊，Android 6.0 起步都支持）
- **播放历史**：本地记录最近播放（最多 300 首，同一首歌去重置顶），一键清空
- **本地歌单**：不需要登录也能新建歌单、把歌加进去并播放
- **音质真的生效 + 音质自检**：切档后立即按新档位重解析并续播；
  自检会列出「请求档位 / 实际档位 / 实际码率 / 文件大小」，被降级时明确告警
- **歌词平滑跟随**：进歌词页立刻居中当前行，之后平滑滚动，不再硬跳
- 自动连播
- **听歌记录同步**：播放记录上报网易云（最近播放 / 听歌排行 / 累计听歌时长），
  weapi + eapi 双通道，可在设置中开关

## 🛠 技术栈

| 组件 | 技术 |
|------|------|
| 语言 | Kotlin |
| UI | ViewBinding + Material Components 3 |
| 播放 | Media3 / ExoPlayer |
| 后台 | MediaSessionService + 前台通知 |
| 网络 | OkHttp + 自实现 weapi / eapi 加密 |
| 图片 | Glide + Palette 取色 |
| 异步 | Kotlin Coroutines |

## 📱 系统要求

- Android 6.0（API 23）及以上
- 无需额外权限（除通知权限用于后台播放）

## 🚀 构建

### GitHub Actions（推荐，无需电脑）

1. Fork 本仓库
2. 上传 `misakamusic.zip` 到仓库根目录（覆盖已有文件）
3. 自动触发 Actions 构建
4. 在 Actions 页面下载 APK

### 本地构建

```bash
# 需要 JDK 17 + Android SDK
gradle assembleDebug
```

APK 输出：`app/build/outputs/apk/debug/app-debug.apk`

> 仓库内自带固定密钥库 `app/misaka-release.jks`（alias `misaka`），debug / release 都用它签名，
> 因此**每次构建出来的 APK 签名一致，新版本可以直接覆盖安装**，不需要先卸载旧版本。
> 该密钥仅用于个人项目签名，请勿用于正式上架。

## 📁 项目结构

```
app/src/main/
├── java/com/xbfhm/misakamusic/
│   ├── App.kt                    # Application 初始化
│   ├── crypto/NeteaseCrypto.kt   # weapi / eapi 加密实现
│   ├── model/Models.kt           # 数据模型
│   ├── net/
│   │   ├── Http.kt               # OkHttp 封装
│   │   ├── NeteaseApi.kt         # 网易云 API 客户端
│   │   ├── Session.kt            # 登录态 / Cookie 管理
│   │   └── Device.kt             # 设备信息模拟
│   ├── player/
│   │   ├── PlayerEngine.kt       # 播放引擎（切歌/模式/上报）
│   │   └── PlaybackService.kt    # 后台播放服务
│   ├── ui/                       # Activity / Fragment / Adapter
│   └── util/Logger.kt            # 内存日志（调试用）
└── res/
    ├── layout/                   # 布局文件
    ├── values/                   # 颜色/主题/字符串
    └── drawable/                 # 图标/形状
```

## 📜 更新日志

详见 [CHANGELOG.md](CHANGELOG.md)。

## 🔐 合规与隐私

### 隐私说明
- 本软件**不收集、不存储、不上传任何个人信息**，无任何服务器端。
- 登录 Cookie（`MUSIC_U`）仅保存在设备本地，仅用于登录**用户本人**的网易云账号，绝不外传。
- 所有请求均由设备直接发往网易云官方服务器，不经过任何第三方中转。
- 播放记录、收藏、歌单等操作均作用于用户本人账号。

### 版权声明
- 本软件**不存储、不缓存、不传播任何音乐文件**。所有音频、歌词、封面均通过网易云公开接口实时获取。
- 歌曲、歌词、封面等相关内容的著作权及其他权利均归**网易云音乐及相应权利人**所有。

### 付费与 VIP
- 本软件**不提供任何破解、绕过付费或 VIP 特权白嫖功能**。
- VIP / 付费歌曲需用户拥有**合法的网易云会员权限**方可正常播放。
- 请勿将本软件用于规避付费或侵害他人权益。

### 使用风险提示
- 本软件使用网易云**非公开接口**（weapi / eapi），接口可能随时变动、失效或触发风控。
- 使用本软件可能违反网易云音乐服务条款，**账号存在被限制的风险，用户需自行承担**。

## 📦 第三方开源许可

本项目使用了以下开源库（均为 Apache-2.0 等宽松许可）：

| 库 | 用途 | 许可 |
|------|------|------|
| AndroidX（core / appcompat / fragment / recyclerview / palette / constraintlayout / swiperefreshlayout） | 基础组件 | Apache-2.0 |
| Material Components for Android | Material 3 UI | Apache-2.0 |
| AndroidX Media3 / ExoPlayer | 播放引擎 | Apache-2.0 |
| OkHttp | 网络请求 | Apache-2.0 |
| Glide | 图片加载 | Apache-2.0 |
| ZXing | 二维码生成 | Apache-2.0 |
| Kotlinx Coroutines | 异步 | Apache-2.0 |

## 🙏 致谢

- [NeteaseCloudMusicApi](https://github.com/Binaryify/NeteaseCloudMusicApi) — 网易云音乐接口协议参考
- [MikuBeat](https://github.com/Pafonshaw/MikuBeat) — Material Design 3 界面设计参考
- [Namida](https://github.com/namidaco/namida) — 播放器视觉风格参考
- [yesplaymusic](https://github.com/qier222/YesPlayMusic) — scrobble 上报方案参考

## ⚖️ 免责声明

1. 本软件**仅用于个人学习与技术研究**，严禁用于任何商业用途或牟利行为。

2. 本软件与网易云音乐（杭州网易云音乐科技有限公司）**无任何关联、合作、代理、授权或隶属关系**。项目名称、图标及界面均不构成任何形式的官方暗示或背书。

3. 本软件**不存储、不提供、不传播任何音乐文件**。所有音频均通过网易云音乐公开接口实时获取，歌曲、歌词、封面等相关内容的著作权及其他权利均归网易云音乐及相应权利人所有。

4. 用户通过本软件登录的账号、产生的播放记录及收藏等行为，均作用于用户本人账号。请勿使用本软件从事任何侵害他人权利、规避付费或违反相关服务条款的行为。

5. 网易云音乐接口属其平台资源，若接口发生变动、失效、风控或依据法律要求，本软件可能随时停止维护，开发者不承担由此产生的任何损失。

6. 本软件为开源项目，任何人可查看、修改及分发源码，但须保留本声明。因第三方修改版本所引发的问题，与原作者无关。

## 📄 许可证

本项目基于 [MIT 许可证](LICENSE) 开源。

**注意**：MIT 许可证仅适用于本项目源代码。通过本软件访问的网易云音乐内容（歌曲、歌词、封面等）的版权归网易云音乐及相应权利人所有，不在本许可证覆盖范围内。

## 📮 联系

- 邮箱：2563805217@qq.com
- 仓库：[github.com/xbfhm/misaka-music](https://github.com/xbfhm/misaka-music)
