package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.xbfhm.misakamusic.databinding.ActivityPlaylistsBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 我的歌单列表 */
class PlaylistsActivity : BaseActivity() {

    private lateinit var binding: ActivityPlaylistsBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val adapter = PlaylistAdapter { p -> openPlaylist(p) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.rvPlaylists.layoutManager = LinearLayoutManager(this)
        binding.rvPlaylists.adapter = adapter

        loadPlaylists()
    }

    private fun loadPlaylists() {
        if (!Session.isLoggedIn()) {
            toast("请先在设置中登录")
            return
        }
        scope.launch {
            if (Session.uid <= 0) {
                val info = withContext(Dispatchers.IO) { NeteaseApi.accountInfo(this@PlaylistsActivity) }
                Session.uid = info.optJSONObject("profile")?.optLong("userId", 0) ?: 0
            }
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@PlaylistsActivity, Session.uid)
            }
            adapter.submit(playlists)
            if (playlists.isEmpty()) toast("未获取到歌单")
        }
    }

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(this, PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        openPage(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
