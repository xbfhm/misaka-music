package com.xbfhm.misakamusic.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ItemPlaylistBinding
import com.xbfhm.misakamusic.model.Playlist

class PlaylistAdapter(
    /** 长按: 用于本地歌单的重命名 / 删除 (可选) */
    private val onLongClick: ((Playlist) -> Unit)? = null,
    private val onClick: (Playlist) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.VH>() {

    private val items = mutableListOf<Playlist>()

    fun submit(list: List<Playlist>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemPlaylistBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.binding.tvName.text = p.name
        holder.binding.tvLocal.visibility = if (p.isLocal) View.VISIBLE else View.GONE
        holder.binding.tvInfo.text = if (p.isLocal)
            "${p.trackCount} 首 · 仅本机" else "${p.trackCount} 首"
        Glide.with(holder.binding.cover)
            .load(p.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(holder.binding.cover)
        UiFx.attachPressFeedback(holder.binding.root, 0.98f)
        holder.binding.root.setOnClickListener { onClick(p) }
        holder.binding.root.setOnLongClickListener {
            if (p.isLocal && onLongClick != null) {
                onLongClick.invoke(p)
                true
            } else false
        }
    }

    class VH(val binding: ItemPlaylistBinding) : RecyclerView.ViewHolder(binding.root)
}
