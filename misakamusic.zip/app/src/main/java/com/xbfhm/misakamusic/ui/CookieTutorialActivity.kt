package com.xbfhm.misakamusic.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.databinding.ActivityCookieTutorialBinding

/** Cookie 登录获取教程 (二级页面, 左上角返回) */
class CookieTutorialActivity : BaseActivity() {

    private lateinit var binding: ActivityCookieTutorialBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCookieTutorialBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
    }
}
