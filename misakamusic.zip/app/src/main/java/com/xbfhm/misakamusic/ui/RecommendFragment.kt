package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.FragmentRecommendBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.ThemeManager
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 推荐页: 分段加载 (下拉刷新 + 上拉加载更多) */
class RecommendFragment : Fragment() {

    private var _binding: FragmentRecommendBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val adapter = SongAdapter { index -> playSong(index) }
    private var displaySongs: List<Song> = emptyList()
    private var pool: List<Song> = emptyList()
    private var shown = 0
    private var poolLoaded = false
    private var loading = false
    private val PAGE = 20
    private val RECOMMEND_TAG = 0L

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecommendBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // 主题色应用到本页控件 (后续由 Activity 的主题监听统一刷新)
        ThemeManager.applyToTree(view)
        // 纵向歌曲列表 (原有效果)
        binding.rvSongs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSongs.adapter = adapter

        binding.btnRefreshHint.setOnClickListener { refresh() }
        binding.swipeRefresh.setOnRefreshListener { refresh() }
        binding.rvSongs.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val lm = rv.layoutManager as? LinearLayoutManager ?: return
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.itemCount - 3) {
                    loadMore()
                }
            }
        })

        showSkeleton(true)
        refresh()
    }

    /**
     * 骨架屏(6 条灰色占位行) 只在**首次加载、还没有任何数据**时显示。
     * ★ 之前这里从来没被隐藏过, 于是一直盖在列表上面, 看起来像"几条空白歌曲
     *   固定在中间不动"。数据到达/加载结束必须隐藏。
     */
    private fun showSkeleton(show: Boolean) {
        val sk = binding.skeleton
        if (show) {
            if (sk.visibility != View.VISIBLE) {
                sk.visibility = View.VISIBLE
                UiFx.pulseSkeleton(sk)
            }
        } else {
            if (sk.visibility == View.VISIBLE) {
                UiFx.stopPulse(sk)
                sk.visibility = View.GONE
            }
        }
    }

    private fun refresh() {
        showSkeleton(true)
        poolLoaded = false
        pool = emptyList()
        displaySongs = emptyList()
        shown = 0
        adapter.submit(emptyList())
        binding.footer.visibility = View.GONE
        loadMore()
    }

    private fun loadMore() {
        if (loading) return
        if (poolLoaded && shown >= pool.size) return
        loading = true
        binding.swipeRefresh.isRefreshing = !poolLoaded
        val ctx = requireContext()
        scope.launch {
            try {
                if (!poolLoaded) {
                    pool = withContext(Dispatchers.IO) { NeteaseApi.recommendPool(ctx, 200) }
                    poolLoaded = true
                    shown = 0
                    displaySongs = emptyList()
                }
                val next = (shown + PAGE).coerceAtMost(pool.size)
                if (next > shown) {
                    displaySongs = displaySongs + pool.subList(shown, next)
                    adapter.submit(displaySongs)
                    shown = next
                }
            } catch (t: Throwable) {
                // 任何异常(网络/解析)都要走到收尾, 否则骨架屏和 loading 状态会卡死
                Logger.log("Recommend", "加载失败: ${t.message}")
            } finally {
                loading = false
                // 加载结束: 隐藏骨架屏 (无论成功与否, 避免占位行一直挂在界面上)
                _binding?.let { b ->
                    b.swipeRefresh.isRefreshing = false
                    showSkeleton(false)
                    b.footer.visibility = if (poolLoaded && shown >= pool.size) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun playSong(index: Int) {
        if (index !in displaySongs.indices) return
        PlayerEngine.setPlaylist(RECOMMEND_TAG, displaySongs, index)
        adapter.currentIndex = PlayerEngine.currentIndex
        adapter.notifyDataSetChanged()
        // 全局主题色跟随当前封面
        ThemeManager.applyCover(requireContext(), displaySongs[index].cover)
        openPlayer(index)
    }

    /** 携带封面共享元素进入播放页 */
    private fun openPlayer(index: Int) {
        val intent = Intent(requireContext(), PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_COVER_TRANSITION, adapter.coverTransitionName(index))
        // 找到屏幕上对应位置的封面 View 作为共享元素
        val holder = binding.rvSongs.findViewHolderForAdapterPosition(index) as? SongAdapter.VH
        if (holder != null) {
            UiFx.startWithSharedCover(
                requireActivity(), intent, holder.binding.cover,
                adapter.coverTransitionName(index),
                R.anim.slide_in_bottom, R.anim.fade_out
            )
        } else {
            startActivity(intent)
            requireActivity().overridePendingTransition(R.anim.slide_in_bottom, R.anim.fade_out)
        }
    }

    override fun onResume() {
        super.onResume()
        updateHighlight()
    }

    private fun updateHighlight() {
        if (PlayerEngine.queueTag == RECOMMEND_TAG) {
            adapter.currentIndex = PlayerEngine.currentIndex
        } else {
            adapter.currentIndex = -1
        }
        adapter.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // 停掉骨架屏呼吸动画, 避免动画持有已销毁的视图
        _binding?.let { UiFx.stopPulse(it.skeleton) }
        _binding = null
    }
}
