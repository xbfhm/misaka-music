package com.xbfhm.misakamusic.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.theme.BackgroundPrefs
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 自定义背景宿主。
 *
 * 在每个 Activity 的 android.R.id.content 最底层插入
 *   [磨砂背景 ImageView] + [渐变遮罩 View]
 * 两个页面都不需要改布局: 只要根布局是透明的, 背景就会自然透上来。
 *
 * 动效:
 *  - 载入时 600ms 淡入 (避免切页闪一下)
 *  - 「呼吸」缓慢缩放 (scale 1.0 → 1.06, 20s 往复), 就是苹果壁纸那种微动效
 */
object BackgroundHost {

    private const val TAG_HOST = "misaka_bg_host"
    private const val TAG_IMAGE = "misaka_bg_image"
    private const val TAG_SCRIM = "misaka_bg_scrim"

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /** 位图缓存: 同一个背景 + 同一模糊半径只解码一次 (切页面秒开) */
    private var cacheKey = ""
    private var cacheBitmap: Bitmap? = null
    private var loadingKey = ""

    fun attach(activity: Activity) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val host = (content.findViewWithTag<View>(TAG_HOST) as? ViewGroup)
            ?: buildHost(activity, content)

        if (!BackgroundPrefs.enabled) {
            host.visibility = View.GONE
            stopMotion(host)
            return
        }
        host.visibility = View.VISIBLE
        applyDim(host)
        load(activity, host)
    }

    /** 设置变更后调用: 丢掉缓存并立刻重画 */
    fun refresh(activity: Activity) {
        cacheKey = ""
        cacheBitmap = null
        loadingKey = ""
        attach(activity)
    }

    fun clearCache() {
        cacheKey = ""
        cacheBitmap = null
        loadingKey = ""
    }

    /** 当前背景是否应当盖住播放页/歌词页的封面模糊背景 */
    fun coverPlayerBackground(): Boolean = BackgroundPrefs.enabled

    // ---------------------------------------------------------------- 构建

    private fun buildHost(activity: Activity, content: ViewGroup): ViewGroup {
        val host = FrameLayout(activity).apply {
            tag = TAG_HOST
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            isClickable = false
            isFocusable = false
        }
        val image = ImageView(activity).apply {
            tag = TAG_IMAGE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.BLACK)
            alpha = 0f
        }
        val scrim = View(activity).apply {
            tag = TAG_SCRIM
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundResource(R.drawable.bg_bg_scrim)
        }
        host.addView(image)
        host.addView(scrim)
        content.addView(host, 0)
        return host
    }

    private fun imageOf(host: ViewGroup): ImageView? = host.findViewWithTag(TAG_IMAGE)

    private fun scrimOf(host: ViewGroup): View? = host.findViewWithTag(TAG_SCRIM)

    private fun applyDim(host: ViewGroup) {
        scrimOf(host)?.alpha = BackgroundPrefs.dim / 100f
    }

    // ---------------------------------------------------------------- 载入

    private fun load(activity: Activity, host: ViewGroup) {
        val image = imageOf(host) ?: return
        val key = BackgroundPrefs.cacheKey()
        val hit = cacheBitmap
        if (key == cacheKey && hit != null && !hit.isRecycled) {
            image.setImageBitmap(hit)
            fadeIn(image)
            startMotion(host, image)
            return
        }
        if (loadingKey == key) return
        loadingKey = key
        val radius = BackgroundPrefs.blur
        val source = BackgroundPrefs.source
        val uriStr = BackgroundPrefs.customUri
        val presetId = BackgroundPrefs.presetRes()
        val appCtx = activity.applicationContext
        // 不模糊时保留更高分辨率 (内置插画 720x1280 就按原尺寸用)
        val reqEdge = if (radius > 0) 720 else 1280
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                if (source == "custom" && uriStr.isNotBlank()) {
                    BlurUtil.decodeStream(
                        open = { runCatching { appCtx.contentResolver.openInputStream(Uri.parse(uriStr)) }.getOrNull() },
                        radius = radius,
                        reqWidth = reqEdge
                    )
                } else {
                    BlurUtil.decodeResource(appCtx.resources, presetId, radius, reqEdge)
                }
            }
            if (bmp == null) {
                Logger.log("Background", "背景载入失败 source=$source uri=$uriStr")
                loadingKey = ""
                return@launch
            }
            cacheKey = key
            cacheBitmap = bmp
            loadingKey = ""
            if (activity.isFinishing || activity.isDestroyed) return@launch
            image.setImageBitmap(bmp)
            fadeIn(image)
            startMotion(host, image)
        }
    }

    private fun fadeIn(image: ImageView) {
        image.animate().cancel()
        image.alpha = 0f
        image.animate().alpha(1f).setDuration(600).start()
    }

    // ---------------------------------------------------------------- 微动效

    private fun startMotion(host: ViewGroup, image: ImageView) {
        if (!BackgroundPrefs.motion) {
            stopMotion(image)
            image.scaleX = 1.06f
            image.scaleY = 1.06f
            return
        }
        if (image.tag is ObjectAnimator) return
        val anim = ObjectAnimator.ofFloat(image, "scaleX", 1.02f, 1.10f).apply {
            duration = 20000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
        }
        ObjectAnimator.ofFloat(image, "scaleY", 1.02f, 1.10f).apply {
            duration = 20000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
        }.start()
        image.tag = anim
        anim.start()
    }

    private fun stopMotion(host: ViewGroup) {
        stopMotion(imageOf(host))
    }

    private fun stopMotion(image: ImageView?) {
        image ?: return
        (image.tag as? ObjectAnimator)?.cancel()
        image.tag = null
    }

    /** 预加载 (设置页点「应用」之后马上后台算好位图) */
    fun preload() {
        val key = BackgroundPrefs.cacheKey()
        if (key == cacheKey) return
        loadingKey = ""
    }

    fun detach(activity: Activity) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        (content.findViewWithTag<View>(TAG_HOST) as? ViewGroup)?.let { stopMotion(it) }
    }

    private val unusedJob: Job? = null
}
