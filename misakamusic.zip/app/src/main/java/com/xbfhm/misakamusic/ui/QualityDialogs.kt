package com.xbfhm.misakamusic.ui

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.model.PlayUrlInfo
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine

/**
 * 音质选择 (设置页 + 播放页 + 歌词页共用同一个入口)。
 *
 * ★ 关键修复: 以前切换音质只是改了一个偏好值, **正在播放的歌曲不会重新解析音源**,
 *   所以「改了音质听起来没变化」。现在切档之后立刻用新档位重新解析当前歌曲,
 *   并且从当前播放位置无缝续播, 真正做到「切了就是切了」。
 */
object QualityDialogs {

    val LEVELS = arrayOf("standard", "higher", "exhigh", "lossless", "hires")

    fun label(ctx: Context, level: String): String = when (level) {
        "standard" -> ctx.getString(R.string.quality_standard)
        "higher" -> ctx.getString(R.string.quality_higher)
        "exhigh" -> ctx.getString(R.string.quality_exhigh)
        "lossless" -> ctx.getString(R.string.quality_lossless)
        "hires" -> ctx.getString(R.string.quality_hires)
        else -> ctx.getString(R.string.quality_exhigh)
    }

    /** 短标签 (播放页药丸上显示) */
    fun shortLabel(level: String): String = when (level) {
        "standard" -> "标准"
        "higher" -> "较高"
        "exhigh" -> "极高"
        "lossless" -> "无损"
        "hires" -> "Hi-Res"
        else -> "极高"
    }

    /**
     * 播放页 / 歌词页的「当前实际音质」文字。
     * 会明确区分「服务器实际给的档位」与「请求的档位」, 降级时给出提示。
     */
    fun nowPlayingText(ctx: Context): String {
        val info = PlayerEngine.currentPlayInfo
        val req = Session.quality
        if (info == null) return label(ctx, req) + " · 解析中…"
        val br = info.actualBr(PlayerEngine.currentSong()?.duration ?: 0L)
        val actual = if (info.level.isNotBlank()) shortLabel(info.level) else shortLabel(req)
        val brText = if (br > 0) " ${br}kbps" else ""
        val mark = if (info.downgraded()) " ⚠️" else " ✓"
        return "$actual$brText$mark"
    }

    /** 打开选择器; [onChanged] 在音质真正改变后回调 (用于刷新界面) */
    fun show(activity: Activity, onChanged: (() -> Unit)? = null) {
        val labels = LEVELS.map { label(activity, it) }.toTypedArray()
        val current = LEVELS.indexOf(Session.quality).coerceAtLeast(0)
        MaterialAlertDialogBuilder(activity)
            .setTitle(activity.getString(R.string.quality_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                d.dismiss()
                apply(activity, LEVELS[which], onChanged)
            }
            .setNeutralButton(R.string.quality_verify) { _: DialogInterface?, _: Int ->
                verify(activity)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** 应用一个音质档位 */
    fun apply(activity: Activity, level: String, onChanged: (() -> Unit)? = null) {
        val changed = Session.quality != level
        Session.quality = level
        PlayerEngine.clearResolved()
        if (PlayerEngine.hasQueue()) {
            PlayerEngine.reloadCurrentQuality()
        }
        onChanged?.invoke()
        val tip = if (changed) R.string.quality_saved else R.string.quality_same
        Toast.makeText(activity, activity.getString(tip) + "：" + label(activity, level), Toast.LENGTH_SHORT).show()
    }

    /**
     * 音质自检: 对比「请求档位 / 实际档位 / 实际码率 / 文件大小」,
     * 用真实数据回答「改音质到底有没有用」。
     */
    fun verify(activity: Activity) {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            Toast.makeText(activity, activity.getString(R.string.quality_verify_need_song), Toast.LENGTH_SHORT).show()
            return
        }
        val info = PlayerEngine.currentPlayInfo
        if (info == null) {
            Toast.makeText(activity, activity.getString(R.string.quality_verify_wait), Toast.LENGTH_SHORT).show()
            PlayerEngine.reloadCurrentQuality()
            return
        }
        val br = info.actualBr(song.duration)
        val sb = StringBuilder()
        sb.append("歌曲：").append(song.name).append('\n')
        sb.append("请求档位：").append(label(activity, Session.quality)).append('\n')
        sb.append("实际档位：")
            .append(if (info.level.isBlank()) "未知" else label(activity, info.level))
            .append('\n')
        sb.append("实际码率：").append(if (br > 0) "${br} kbps" else "未知").append('\n')
        if (info.size > 0) {
            sb.append("文件大小：").append(String.format("%.2f MB", info.size / 1024.0 / 1024.0)).append('\n')
        }
        sb.append("播放源：").append(if (info.source == "gdstudio") "免费接口（GDStudio）" else "网易云原始接口").append('\n')
        sb.append('\n')
        sb.append(
            if (info.downgraded())
                "⚠️ 服务器只提供了「${if (info.level.isBlank()) "未知" else shortLabel(info.level)}」音质，当前歌曲没有你选择档位的资源（常见于 VIP 曲/版权限制），已自动回退到能给的最高音质。"
            else "✅ 与你选择的档位一致，音质设置已真实生效。"
        )
        MaterialAlertDialogBuilder(activity)
            .setTitle(R.string.quality_verify_title)
            .setMessage(sb.toString())
            .setPositiveButton(R.string.timer_ok, null)
            .show()
    }
}
