package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.FragmentRankBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.theme.ThemeManager
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 排行榜页: 网易云官方榜单 (飙升/新歌/热歌/原创…)。
 * 点榜单 = 进歌单页 (复用 PlaylistActivity); 点加号 = 收藏该榜单。
 */
class RankFragment : Fragment() {

    private var _binding: FragmentRankBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val adapter = UserPlaylistAdapter(
        onClick = { p -> openPlaylist(p) },
        onSubscribe = { p -> subscribe(p) }
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRankBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ThemeManager.applyToTree(view)
        binding.rvRank.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRank.adapter = adapter
        binding.btnRankRefresh.setOnClickListener { refresh() }
        binding.swipeRank.setOnRefreshListener { refresh() }
        refresh()
    }

    private fun showLoading(show: Boolean) {
        val sk = binding.rankSkeleton
        val sh = binding.rankShimmer
        if (show) {
            sk.visibility = View.VISIBLE
            sh.visibility = View.VISIBLE
            UiFx.pulseSkeleton(sk)
            sh.startShimmer()
        } else {
            UiFx.stopPulse(sk)
            sk.visibility = View.GONE
            sh.visibility = View.GONE
            sh.stopShimmer()
        }
    }

    private fun refresh() {
        if (adapter.itemCount == 0) showLoading(true)
        binding.swipeRank.isRefreshing = adapter.itemCount == 0
        val ctx = requireContext()
        scope.launch {
            try {
                val list = withContext(Dispatchers.IO) { NeteaseApi.topLists(ctx) }
                adapter.submit(list)
                binding.tvRankEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            } catch (t: Throwable) {
                Logger.log("Rank", "加载失败: ${t.message}")
                if (adapter.itemCount == 0) {
                    binding.tvRankEmpty.visibility = View.VISIBLE
                }
            } finally {
                _binding?.let {
                    it.swipeRank.isRefreshing = false
                    showLoading(false)
                }
            }
        }
    }

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(requireContext(), PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        intent.putExtra(PlaylistActivity.EXTRA_LOCAL, false)
        startActivity(intent)
        requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun subscribe(p: Playlist) {
        if (!Session.isLoggedIn()) {
            Toast.makeText(requireContext(), R.string.rank_login_first, Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.subscribePlaylist(requireContext(), p.id, true)
            }
            val ok = j.optInt("code", -1) == 200
            Toast.makeText(
                requireContext(),
                if (ok) R.string.rank_subscribe_ok else R.string.rank_subscribe_fail,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding?.let {
            UiFx.stopPulse(it.rankSkeleton)
            it.rankShimmer.stopShimmer()
        }
        _binding = null
    }
}
