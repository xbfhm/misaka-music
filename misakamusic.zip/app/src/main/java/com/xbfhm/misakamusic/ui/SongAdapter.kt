package com.xbfhm.misakamusic.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ItemSongBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.theme.ThemeManager

class SongAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.VH>() {

    private val items = mutableListOf<Song>()
    var currentIndex: Int = -1
    /** 正在播放的高亮色 (跟随全局配色) */
    private var accent: Int = ThemeManager.primary

    /**
     * 自定义副标题 (默认为「歌手 · 专辑」)。
     * 播放历史页用它显示「歌手 · 3 分钟前」。
     */
    var infoProvider: ((Song) -> String)? = null

    /** 长按回调 (位置), 例如本地歌单里「移出歌单」 */
    var onLongClick: ((Int) -> Unit)? = null

    /**
     * 主题监听: 只在颜色过渡动画结束时刷新列表 (动画中每帧 notifyDataSetChanged 会卡)。
     * 监听器被 ThemeManager 以弱引用持有, Adapter 回收后自动失效, 不会泄漏。
     */
    private val themeListener = ThemeManager.Listener { p, isFinal ->
        accent = p.primary
        if (isFinal) notifyDataSetChanged()
    }

    init {
        ThemeManager.addListener(themeListener)
    }

    fun submit(list: List<Song>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val playing = position == currentIndex
        val ctx = holder.binding.root.context

        // Namida 风格: 正在播放时用动态主色高亮歌名
        holder.binding.tvName.text = (if (playing) "♪ " else "") + s.name
        holder.binding.tvName.setTextColor(
            if (playing) accent else ContextCompat.getColor(ctx, R.color.namida_text_primary)
        )
        holder.binding.tvInfo.text = infoProvider?.invoke(s)
            ?: listOf(s.artists, s.album).filter { it.isNotBlank() }.joinToString(" · ")
        holder.binding.tvVip.visibility =
            if (s.fee > 0) View.VISIBLE else View.GONE
        holder.binding.tvDur.text = formatMs(s.duration)
        Glide.with(holder.binding.cover)
            .load(s.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(holder.binding.cover)

        // 共享元素过渡: 用「列表位置」作为唯一 transitionName，避免多条目同名冲突
        holder.binding.cover.transitionName = coverTransitionName(position)

        // 点击涟漪 + 按压缩放反馈
        UiFx.attachPressFeedback(holder.binding.root)
        holder.binding.root.setOnClickListener { onClick(position) }
        holder.binding.root.setOnLongClickListener {
            val cb = onLongClick
            if (cb != null) {
                cb(position)
                true
            } else false
        }
    }

    /** 生成该位置封面的共享元素名称 (播放页需要同样的名字) */
    fun coverTransitionName(position: Int): String = "song_cover_$position"

    private fun formatMs(ms: Long): String {
        if (ms <= 0) return "--:--"
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    class VH(val binding: ItemSongBinding) : RecyclerView.ViewHolder(binding.root)
}
