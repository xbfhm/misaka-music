package com.xbfhm.misakamusic.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityWebLoginBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 内置「网易云网页版登录」。
 *
 * 思路: 不做协议逆向, 直接把 **官方网页登录页** 装进 App 里的 WebView:
 *
 *   https://music.163.com/login?targetUrl=https%3A%2F%2Fmusic.163.com%2F
 *
 * 用户在网页里可以用 扫码 / 手机号验证码 / 邮箱密码 任意一种方式登录 ——
 * 都是网易云自己的页面、自己的风控, 不存在「二维码类型不对 / unikey 拿不到」的问题。
 *
 * 登录完成后页面会话会写到 WebView 的 CookieStore 里, 我们**轮询 MUSIC_U**:
 *   CookieManager.getCookie("https://music.163.com")
 * 一旦出现 MUSIC_U 就把它并进 [Session] (设备身份字段仍用本机 App 的),
 * 再用 eapi 校验一次账号信息, 通过就回到登录页完成登录。
 *
 * 安全设计 (对应 v4.0.0 安全审查):
 *  - 不注入任何 addJavascriptInterface —— 网页脚本无法调用 App 里的任何方法;
 *  - 关闭 file:// 与 content:// 访问, 禁止混合内容 (https 页面里的 http 资源也被拦);
 *  - 只允许在 *.163.com / *.126.net / *.127.net / *.netease.com 之间跳转,
 *    其它域名一律拦住 —— 防止被第三方页面钓鱼套走登录页上的 cookie;
 *  - 关闭 WebView 远程调试 (chrome://inspect), 避免 adb 直接读取网页 cookie;
 *  - Cookie 并入会话后由 SessionCrypto 加密落盘。
 */
class WebLoginActivity : BaseActivity() {

    private lateinit var binding: ActivityWebLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var pollJob: Job? = null

    /** 正在用抓到的 cookie 校验登录态 (避免重复触发) */
    private var logging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        binding.btnBack.setOnClickListener { finish() }
        binding.btnManual.setOnClickListener { manualCheck() }

        setupWebView()
        openLoginPage()
        startPoll()
    }

    // ================= WebView 配置 =================

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        // 关闭远程调试: 开着的话 adb / 同网段调试工具能直接读网页里的 cookie
        try {
            WebView.setWebContentsDebuggingEnabled(false)
        } catch (_: Throwable) {
        }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        try {
            cm.setAcceptThirdPartyCookies(binding.webView, true)
        } catch (_: Throwable) {
        }

        val s = binding.webView.settings
        s.javaScriptEnabled = true              // 网易云登录页是纯 JS 渲染, 必须开
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = false               // 禁止 file:// 读本地文件
        s.allowContentAccess = false            // 禁止 content:// 读其它 App 数据
        s.setGeolocationEnabled(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.saveFormData = false
        s.userAgentString = DESKTOP_UA          // 桌面版才有扫码登录框
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        // 注意: 这里**绝不**调用 addJavascriptInterface

        binding.webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val host = request.url.host
                if (!isAllowedHost(host)) {
                    Logger.log("WebLogin", "拦截跳转: $host")
                    toast(getString(R.string.web_login_blocked))
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                binding.pbWeb.visibility = View.GONE
                if (logging) return
                if (!checkCookie()) {
                    // 页面加载完还没有登录态 -> 正常状态, 把加载遮罩收起来
                    binding.layoutStatus.visibility = View.GONE
                }
            }
        }

        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                binding.pbWeb.progress = newProgress
                binding.pbWeb.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }

        // 网页里的下载一律不接 (防止网页把文件写到存储里)
        binding.webView.setDownloadListener { _, _, _, _, _ ->
            toast(getString(R.string.web_login_blocked))
        }
    }

    private fun isAllowedHost(host: String?): Boolean {
        if (host.isNullOrBlank()) return true // about:blank / data: 之类
        val h = host.lowercase()
        return ALLOWED_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun openLoginPage() {
        binding.layoutStatus.visibility = View.VISIBLE
        binding.pbLoading.visibility = View.VISIBLE
        binding.tvStatus.text = getString(R.string.web_login_loading)
        Logger.log("WebLogin", "打开网页登录页")
        binding.webView.loadUrl(LOGIN_URL)
    }

    // ================= 抓 cookie =================

    private fun startPoll() {
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                delay(800)
                if (logging) continue
                if (checkCookie()) return@launch
            }
        }
    }

    /** @return true = 已经拿到 MUSIC_U 并开始登录 */
    private fun checkCookie(): Boolean {
        if (logging) return true
        val raw = readWebCookies()
        if (!hasMusicU(raw)) return false
        Logger.log("WebLogin", "检测到 MUSIC_U, 开始校验登录态")
        beginLogin(raw)
        return true
    }

    /** 把 WebView 里几个网易云域名下的 cookie 合并成一个 cookie 串 */
    private fun readWebCookies(): String {
        val out = LinkedHashMap<String, String>()
        val cm = CookieManager.getInstance()
        for (url in COOKIE_URLS) {
            val c = try {
                cm.getCookie(url)
            } catch (_: Throwable) {
                null
            } ?: continue
            c.split(";").forEach { part ->
                val i = part.indexOf('=')
                if (i > 0) {
                    val k = part.substring(0, i).trim()
                    val v = part.substring(i + 1).trim()
                    if (k.isNotEmpty() && v.isNotEmpty() && !out.containsKey(k)) out[k] = v
                }
            }
        }
        return out.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    private fun hasMusicU(raw: String): Boolean =
        raw.split(";").any { p ->
            val t = p.trim()
            t.startsWith("MUSIC_U=") && t.substringAfter('=').trim().isNotEmpty()
        }

    private fun manualCheck() {
        if (logging) return
        val raw = readWebCookies()
        if (!hasMusicU(raw)) {
            toast(getString(R.string.web_login_no_cookie))
            return
        }
        beginLogin(raw)
    }

    private fun beginLogin(raw: String) {
        if (logging) return
        logging = true
        pollJob?.cancel()
        binding.layoutStatus.visibility = View.VISIBLE
        binding.pbLoading.visibility = View.VISIBLE
        binding.tvStatus.text = getString(R.string.web_login_verifying)

        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    // 1) 网页 cookie 并入会话 (设备身份字段换成本机 App 的)
                    Session.absorbWebCookies(raw)
                    // 2) 用 eapi 校验一次, 确认真的能拿到账号资料
                    NeteaseApi.afterLogin(this@WebLoginActivity)
                } catch (e: Exception) {
                    Logger.log("WebLogin", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            if (ok) {
                LoginChecker.reset()
                Session.clearLiked()
                try {
                    CookieManager.getInstance().flush()
                } catch (_: Throwable) {
                }
                Logger.log("WebLogin", "网页登录成功: ${Session.nickname} uid=${Session.uid}")
                toast(getString(R.string.web_login_success))
                setResult(Activity.RESULT_OK)
                finish()
            } else {
                Logger.log("WebLogin", "网页登录校验失败")
                logging = false
                binding.pbLoading.visibility = View.GONE
                binding.tvStatus.text = getString(R.string.web_login_failed)
                binding.layoutStatus.postDelayed({
                    binding.layoutStatus.visibility = View.GONE
                }, 2200)
                startPoll()
            }
        }
    }

    override fun onDestroy() {
        pollJob?.cancel()
        scope.cancel()
        try {
            CookieManager.getInstance().flush()
            binding.webView.stopLoading()
            binding.webView.loadUrl("about:blank")
            binding.webView.destroy()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        /** 官方网页登录页 (桌面 UA -> 有扫码/手机号/邮箱三种方式) */
        private const val LOGIN_URL =
            "https://music.163.com/login?targetUrl=https%3A%2F%2Fmusic.163.com%2F"

        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

        /** 只允许在这些域名内跳转 */
        private val ALLOWED_HOSTS = listOf(
            "music.163.com", "163.com", "126.net", "127.net", "netease.com"
        )

        /** 登录态可能落在这些域名的 cookie 上 */
        private val COOKIE_URLS = listOf(
            "https://music.163.com",
            "https://interface.music.163.com",
            "https://y.music.163.com"
        )
    }
}
