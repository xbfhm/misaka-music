package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.xbfhm.misakamusic.databinding.ActivityUserBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 用户详情页: 展示 TA 的歌单 + 收藏加号 */
class UserActivity : BaseActivity() {

    companion object {
        const val EXTRA_UID = "user_uid"
        const val EXTRA_NICKNAME = "user_nickname"
    }

    private lateinit var binding: ActivityUserBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val adapter = UserPlaylistAdapter(
        onClick = { p -> openPlaylist(p) },
        onSubscribe = { p -> subscribe(p) }
    )
    private var uid = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uid = intent.getLongExtra(EXTRA_UID, 0)
        val nickname = intent.getStringExtra(EXTRA_NICKNAME) ?: ""

        binding.btnBack.setOnClickListener { finish() }
        binding.tvTitle.text = nickname.ifBlank { "用户" }
        binding.rvPlaylists.layoutManager = LinearLayoutManager(this)
        binding.rvPlaylists.adapter = adapter

        loadPlaylists()
    }

    private fun loadPlaylists() {
        binding.tvEmpty.visibility = android.view.View.GONE
        scope.launch {
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@UserActivity, uid)
            }
            adapter.submit(playlists)
            binding.tvEmpty.visibility =
                if (playlists.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun subscribe(p: Playlist) {
        if (!Session.isLoggedIn()) {
            toast(getString(com.xbfhm.misakamusic.R.string.subscribe_need_login))
            return
        }
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.subscribePlaylist(this@UserActivity, p.id, true)
            }
            val code = j.optInt("code", -1)
            if (code == 200) {
                toast(getString(com.xbfhm.misakamusic.R.string.subscribe_success))
            } else {
                toast(getString(com.xbfhm.misakamusic.R.string.subscribe_fail))
            }
        }
    }

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(this, PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        openPage(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
