package com.xbfhm.misakamusic.net

import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.zip.GZIPOutputStream

/**
 * NCBL 客户端日志加密 (网易云桌面客户端 PLV/PLD 上报协议)。
 *
 * 逆向自 NeteaseCloudMusicApiEnhanced 的 util/ncbl.js (桌面客户端日志上报方式):
 *   - ChaCha20 (RFC 8439, 32bit counter / 96bit nonce) 流加密
 *   - RSA-256 Key Wrap: keyB = keyA^65537 mod N (256-bit 模数已被公开分解)
 *   - body 先 gzip, 再按 0x8000 分帧, 每帧独立 ChaCha20(keyA) 加密
 *   - meta (cookie 摘要) 用 ChaCha20(keyB) 加密
 *   - 70 字节固定头: MAGIC(NCBL) + version + headerLen + uuid + keyB + seq 区间 + 帧总长
 *
 * 用途: 上报「播放记录(PLV)」与「听歌时长(PLD)」到
 *       https://clientlog3.music.163.com/api/clientlog/encrypt/upload?multiupload=true
 */
object Ncbl {

    private val rng = SecureRandom()

    // ChaCha20 常量 "expand 32-byte k"
    private val SIGMA = intArrayOf(0x61707865, 0x3320646e, 0x79622d32, 0x6b206574)

    // RSA 模数 (256-bit, 网易 NCBL 专用; 已被公开因式分解)
    private val RSA_N = java.math.BigInteger(
        "FD90BD466FF9BC8A3FEC2FBCF263B90D5C564879FA5D7AAB89B31C1D5CB4139D", 16
    )
    private val RSA_E = java.math.BigInteger.valueOf(65537L)

    private const val META_BLOCK_TYPE = 0x4343
    private const val HEADER_FIXED_LEN = 70
    private const val DEFAULT_MAX_FRAME = 0x8000

    private fun rotl(x: Int, n: Int): Int = ((x shl n) or (x ushr (32 - n)))

    private fun qr(s: IntArray, a: Int, b: Int, c: Int, d: Int) {
        s[a] += s[b]; s[d] = s[d] xor s[a]; s[d] = rotl(s[d], 16)
        s[c] += s[d]; s[b] = s[b] xor s[c]; s[b] = rotl(s[b], 12)
        s[a] += s[b]; s[d] = s[d] xor s[a]; s[d] = rotl(s[d], 8)
        s[c] += s[d]; s[b] = s[b] xor s[c]; s[b] = rotl(s[b], 7)
    }

    private fun chachaBlock(key: ByteArray, counter: Int, nonce: ByteArray): ByteArray {
        val state = IntArray(16)
        for (i in 0..3) state[i] = SIGMA[i]
        for (i in 0..7) state[4 + i] = le32(key, i * 4)
        state[12] = counter
        state[13] = le32(nonce, 0)
        state[14] = le32(nonce, 4)
        state[15] = le32(nonce, 8)
        val work = state.copyOf()
        for (r in 0 until 10) {
            qr(work, 0, 4, 8, 12); qr(work, 1, 5, 9, 13)
            qr(work, 2, 6, 10, 14); qr(work, 3, 7, 11, 15)
            qr(work, 0, 5, 10, 15); qr(work, 1, 6, 11, 12)
            qr(work, 2, 7, 8, 13); qr(work, 3, 4, 9, 14)
        }
        val out = ByteArray(64)
        for (i in 0..15) putLe32(out, i * 4, work[i] + state[i])
        return out
    }

    private fun chacha20(key: ByteArray, counter: Int, nonce: ByteArray, data: ByteArray): ByteArray {
        val out = ByteArray(data.size)
        var off = 0
        while (off < data.size) {
            val ks = chachaBlock(key, counter + (off ushr 6), nonce)
            val end = minOf(off + 64, data.size)
            for (i in off until end) out[i] = (data[i].toInt() xor ks[i - off].toInt()).toByte()
            off = end
        }
        return out
    }

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or
            ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or
            ((b[o + 3].toInt() and 0xFF) shl 24)

    private fun putLe32(b: ByteArray, o: Int, v: Int) {
        b[o] = (v and 0xFF).toByte()
        b[o + 1] = ((v ushr 8) and 0xFF).toByte()
        b[o + 2] = ((v ushr 16) and 0xFF).toByte()
        b[o + 3] = ((v ushr 24) and 0xFF).toByte()
    }

    private fun putLe16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v and 0xFF).toByte()
        b[o + 1] = ((v ushr 8) and 0xFF).toByte()
    }

    /** keyB = keyA^65537 mod N, 输出 32 字节大端 */
    private fun rsaWrap(keyA: ByteArray): ByteArray {
        val base = java.math.BigInteger(1, keyA)
        val enc = base.modPow(RSA_E, RSA_N)
        val be = enc.toByteArray() // 大端, 可能带符号前导 0
        val out = ByteArray(32)
        val src = if (be.size > 32) be.copyOfRange(be.size - 32, be.size) else be
        System.arraycopy(src, 0, out, 32 - src.size, src.size)
        return out
    }

    fun gzip(data: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        val gz = GZIPOutputStream(bos)
        gz.write(data)
        gz.close()
        return bos.toByteArray()
    }

    /** 32 位随机 hex (multipart boundary 用) */
    fun randomHex32(): String {
        val b = ByteArray(16).also { rng.nextBytes(it) }
        return b.joinToString("") { "%02x".format(it) }
    }

    /**
     * NCBL 加密封装。
     * @param meta cookie 摘要 JSON 字节
     * @param body 日志记录 ("time\u0001action\u0001json")
     * @return 完整加密 payload (header + metaBlock + frames)
     */
    fun encrypt(meta: ByteArray, body: ByteArray): ByteArray {
        val keyA = ByteArray(32).also { rng.nextBytes(it) }
        if ((keyA[0].toInt() and 0xFF) >= 0xA3) keyA[0] = 0xA2.toByte()
        val keyB = rsaWrap(keyA)

        val uuid = ByteArray(16).also { rng.nextBytes(it) }
        uuid[6] = ((uuid[6].toInt() and 0x0F) or 0x40).toByte()
        uuid[8] = ((uuid[8].toInt() and 0x3F) or 0x80).toByte()
        val nonce = uuid.copyOfRange(0, 12)
        val counter = le32(uuid, 12) ushr 2
        val baseSeq = rng.nextInt(65536)

        // meta 块
        val metaCipher = chacha20(keyB, counter, nonce, meta)
        val metaBlock = ByteArray(4 + metaCipher.size)
        putLe16(metaBlock, 0, META_BLOCK_TYPE)
        putLe16(metaBlock, 2, metaCipher.size)
        System.arraycopy(metaCipher, 0, metaBlock, 4, metaCipher.size)
        val headerLen = HEADER_FIXED_LEN + metaBlock.size

        // body 帧 (gzip + 分帧)
        val compressed = gzip(body)
        val frames = ByteArrayOutputStream()
        var seq = baseSeq
        var off = 0
        while (off < compressed.size || off == 0) {
            val end = minOf(off + DEFAULT_MAX_FRAME, compressed.size)
            val slice = compressed.copyOfRange(off, end)
            val cipher = chacha20(keyA, counter, nonce, slice)
            val head = ByteArray(6)
            putLe16(head, 0, cipher.size)
            putLe32(head, 2, seq)
            frames.write(head)
            frames.write(cipher)
            seq++
            if (compressed.isEmpty()) break
            off = end
        }
        val trailing = frames.toByteArray()
        val frameCount = seq - baseSeq

        val header = ByteArray(HEADER_FIXED_LEN)
        System.arraycopy("NCBL".toByteArray(Charsets.US_ASCII), 0, header, 0, 4)
        putLe32(header, 4, 3) // version
        putLe16(header, 8, headerLen)
        System.arraycopy(uuid, 0, header, 10, 16)
        System.arraycopy(keyB, 0, header, 26, 32)
        putLe32(header, 58, baseSeq)
        putLe32(header, 62, baseSeq + frameCount - 1)
        putLe32(header, 66, trailing.size)

        val out = ByteArrayOutputStream()
        out.write(header)
        out.write(metaBlock)
        out.write(trailing)
        return out.toByteArray()
    }

    /**
     * 测试钩子: 暴露 ChaCha20 供与参考实现 (Python ncbl_ref.py) 逐字节对照。
     * 生产代码不使用。
     */
    fun chacha20Test(key: ByteArray, counter: Int, nonce: ByteArray, data: ByteArray): ByteArray =
        chacha20(key, counter, nonce, data)

    fun rsaWrapTest(keyA: ByteArray): ByteArray = rsaWrap(keyA)

    /**
     * 测试/复现用: 固定随机源 (keyA/uuid/baseSeq), 与参考实现逐字节对照。
     * 生产代码一律走 [encrypt] (SecureRandom)。
     */
    fun encryptWith(meta: ByteArray, body: ByteArray, keyA: ByteArray, uuid: ByteArray, baseSeq: Int): ByteArray {
        val ka = keyA.copyOf()
        if ((ka[0].toInt() and 0xFF) >= 0xA3) ka[0] = 0xA2.toByte()
        val keyB = rsaWrap(ka)
        val nonce = uuid.copyOfRange(0, 12)
        val counter = le32(uuid, 12) ushr 2

        val metaCipher = chacha20(keyB, counter, nonce, meta)
        val metaBlock = ByteArray(4 + metaCipher.size)
        putLe16(metaBlock, 0, META_BLOCK_TYPE)
        putLe16(metaBlock, 2, metaCipher.size)
        System.arraycopy(metaCipher, 0, metaBlock, 4, metaCipher.size)
        val headerLen = HEADER_FIXED_LEN + metaBlock.size

        val compressed = gzip(body)
        val frames = ByteArrayOutputStream()
        var seq = baseSeq
        var off = 0
        while (off < compressed.size || off == 0) {
            val end = minOf(off + DEFAULT_MAX_FRAME, compressed.size)
            val slice = compressed.copyOfRange(off, end)
            val cipher = chacha20(ka, counter, nonce, slice)
            val head = ByteArray(6)
            putLe16(head, 0, cipher.size)
            putLe32(head, 2, seq)
            frames.write(head)
            frames.write(cipher)
            seq++
            if (compressed.isEmpty()) break
            off = end
        }
        val trailing = frames.toByteArray()
        val frameCount = seq - baseSeq

        val header = ByteArray(HEADER_FIXED_LEN)
        System.arraycopy("NCBL".toByteArray(Charsets.US_ASCII), 0, header, 0, 4)
        putLe32(header, 4, 3)
        putLe16(header, 8, headerLen)
        System.arraycopy(uuid, 0, header, 10, 16)
        System.arraycopy(keyB, 0, header, 26, 32)
        putLe32(header, 58, baseSeq)
        putLe32(header, 62, baseSeq + frameCount - 1)
        putLe32(header, 66, trailing.size)

        val out = ByteArrayOutputStream()
        out.write(header)
        out.write(metaBlock)
        out.write(trailing)
        return out.toByteArray()
    }
}
