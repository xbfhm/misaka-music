package com.xbfhm.misakamusic.ui

import android.app.Activity
import android.content.DialogInterface
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.data.LocalPlaylistStore
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 「添加到歌单」选择器。
 *
 * ★ 修复: 以前未登录时这个入口直接不可用, 现在**本地歌单始终可选**,
 *   并且可以现场新建一个歌单再添加歌曲, 完全不需要登录。
 *   已登录时网易云歌单会一起列出来。
 */
object PlaylistPicker {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    fun show(activity: Activity, song: Song, onDone: (() -> Unit)? = null) {
        val logged = Session.isLoggedIn()
        scope.launch {
            val remote = if (logged && Session.uid > 0) {
                withContext(Dispatchers.IO) {
                    runCatching { NeteaseApi.userPlaylists(activity, Session.uid) }.getOrDefault(emptyList())
                }
            } else emptyList()

            val locals = LocalPlaylistStore.all()
            val labels = ArrayList<String>()
            labels.add(activity.getString(R.string.pl_new))
            locals.forEach { labels.add("🎧 ${it.name}（${it.songs.size} 首）") }
            remote.forEach { labels.add("☁ ${it.name}（${it.trackCount} 首）") }

            MaterialAlertDialogBuilder(activity)
                .setTitle(activity.getString(R.string.pl_pick_title, song.name))
                .setItems(labels.toTypedArray()) { _: DialogInterface?, which: Int ->
                    when {
                        which == 0 -> createThenAdd(activity, song, onDone)
                        which - 1 < locals.size -> {
                            val pl = locals[which - 1]
                            val added = LocalPlaylistStore.addSong(pl.id, song)
                            toast(activity, if (added) "已添加到本地歌单「${pl.name}」" else "「${pl.name}」里已经有这首歌了")
                            onDone?.invoke()
                        }
                        else -> {
                            val pl = remote[which - 1 - locals.size]
                            addRemote(activity, song, pl.id, pl.name, onDone)
                        }
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun createThenAdd(activity: Activity, song: Song, onDone: (() -> Unit)?) {
        val input = EditText(activity).apply {
            hint = "歌单名称"
            setSingleLine(true)
            setBackgroundResource(R.drawable.bg_glass_field)
            setPadding(
                (18 * resources.displayMetrics.density).toInt(),
                (14 * resources.displayMetrics.density).toInt(),
                (18 * resources.displayMetrics.density).toInt(),
                (14 * resources.displayMetrics.density).toInt()
            )
            setTextColor(0xFFEDEFF5.toInt())
            setHintTextColor(0xFF767C8C.toInt())
        }
        val wrap = android.widget.FrameLayout(activity).apply {
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, 0)
            addView(input, android.widget.FrameLayout.LayoutParams(-1, -2))
        }
        MaterialAlertDialogBuilder(activity)
            .setTitle(R.string.pl_new)
            .setView(wrap)
            .setPositiveButton(R.string.timer_ok) { _: DialogInterface?, _: Int ->
                val name = input.text?.toString()?.trim().orEmpty()
                val id = LocalPlaylistStore.create(name)
                val added = LocalPlaylistStore.addSong(id, song)
                toast(
                    activity,
                    if (added) "已新建「${name.ifEmpty { "新建歌单" }}」并添加这首歌"
                    else "已新建歌单"
                )
                onDone?.invoke()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun addRemote(
        activity: Activity, song: Song, pid: Long, name: String, onDone: (() -> Unit)?
    ) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                runCatching { NeteaseApi.addSongToPlaylist(activity, pid, listOf(song.id)) }.getOrNull()
            }
            val ok = j?.optInt("code", -1) == 200
            toast(activity, if (ok) "已添加到「$name」" else activity.getString(R.string.fav_fail))
            onDone?.invoke()
        }
    }

    private fun toast(activity: Activity, msg: String) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }
}
