package com.xbfhm.misakamusic.net

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object Http {

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    data class Resp(val httpCode: Int, val body: String, val setCookies: List<String>)

    fun postForm(url: String, form: Map<String, String>, cookie: String?, headers: Map<String, String>): Resp {
        val fb = FormBody.Builder()
        for ((k, v) in form) fb.add(k, v)
        val builder = Request.Builder().url(url).post(fb.build())
        cookie?.let { builder.header("Cookie", it) }
        for ((k, v) in headers) builder.header(k, v)
        val call = client.newCall(builder.build())
        val resp = call.execute()
        try {
            val setCookies: List<String> = resp.headers("Set-Cookie")
            val body = resp.body?.string() ?: ""
            return Resp(resp.code, body, setCookies)
        } finally {
            resp.close()
        }
    }

    fun get(url: String, cookie: String?, headers: Map<String, String>): Resp {
        val builder = Request.Builder().url(url).get()
        cookie?.let { builder.header("Cookie", it) }
        for ((k, v) in headers) builder.header(k, v)
        val call = client.newCall(builder.build())
        val resp = call.execute()
        try {
            val setCookies: List<String> = resp.headers("Set-Cookie")
            val body = resp.body?.string() ?: ""
            return Resp(resp.code, body, setCookies)
        } finally {
            resp.close()
        }
    }

    /** 原始字节体 POST (multipart 等) —— NCBL 日志上传用 */
    fun postRaw(url: String, body: ByteArray, contentType: String?, cookie: String?, headers: Map<String, String>): Resp {
        val builder = Request.Builder().url(url)
        val reqBody = object : okhttp3.RequestBody() {
            override fun contentType(): okhttp3.MediaType? =
                contentType?.toMediaTypeOrNull()
            override fun writeTo(sink: okio.BufferedSink) {
                sink.write(body)
            }
        }
        builder.post(reqBody)
        cookie?.let { builder.header("Cookie", it) }
        for ((k, v) in headers) builder.header(k, v)
        val call = client.newCall(builder.build())
        val resp = call.execute()
        try {
            val setCookies: List<String> = resp.headers("Set-Cookie")
            val bodyStr = resp.body?.string() ?: ""
            return Resp(resp.code, bodyStr, setCookies)
        } finally {
            resp.close()
        }
    }
}
