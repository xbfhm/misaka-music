package com.xbfhm.misakamusic.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * 骨架屏「流光」加载动效: 一道斜向高光带从左向右循环扫过。
 * 盖在骨架占位行上方 (半透明), 让加载界面有通透的玻璃反光感。
 */
class ShimmerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var animator: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    /** 开始流光动画 */
    fun startShimmer() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                phase = a.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    /** 停止并复位 */
    fun stopShimmer() {
        animator?.cancel()
        animator = null
        phase = 0f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        canvas.save()
        // 斜向 -18°, 模拟玻璃反光扫过
        canvas.rotate(-18f, w / 2f, h / 2f)
        // 光带宽度约屏宽 0.34, 相位从左到右循环 (留出两侧余量, 保证平滑衔接)
        val bandW = w * 0.34f
        val travel = (w + bandW * 2f) * phase - bandW
        paint.shader = LinearGradient(
            travel - bandW, 0f, travel + bandW, 0f,
            intArrayOf(
                0x00FFFFFF.toInt(),
                0x14FFFFFF.toInt(),
                0x2EFFFFFF.toInt(),
                0x14FFFFFF.toInt(),
                0x00FFFFFF.toInt()
            ),
            floatArrayOf(0f, 0.3f, 0.5f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.FILL
        canvas.drawRect(-w, -h, w * 2f, h * 2f, paint)
        paint.shader = null
        canvas.restore()
    }
}
