package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.data.PlayHistoryStore
import com.xbfhm.misakamusic.databinding.ActivityHistoryBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.ThemeManager
import com.xbfhm.misakamusic.ui.SongAdapter

/**
 * 播放历史。
 *
 * ★ 之前 App 里压根没有「播放历史」这个页面 —— 用户问「播放历史在哪里」。
 *   现在: 首页右上角时钟图标 / 我的歌单页「播放历史」卡片 / 设置页 三个入口都能进。
 */
class HistoryActivity : BaseActivity() {

    companion object {
        /** 播放历史队列标记 (和歌单/推荐/搜索的 id 区分开) */
        const val TAG_HISTORY = -3L
    }

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var adapter: SongAdapter
    private var entries: List<PlayHistoryStore.Entry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        adapter = SongAdapter { index -> play(index) }
        adapter.infoProvider = { song -> historyInfo(song) }
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnClear.setOnClickListener { confirmClear() }
        load()
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        entries = PlayHistoryStore.list()
        adapter.submit(entries.map { it.song })
        binding.emptyBox.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        binding.tvTitle.text = if (entries.isEmpty()) getString(R.string.history_title)
        else "${getString(R.string.history_title)}（${entries.size}）"
        if (PlayerEngine.queueTag == TAG_HISTORY) {
            adapter.currentIndex = PlayerEngine.currentIndex
            adapter.notifyDataSetChanged()
        }
    }

    private fun historyInfo(song: Song): String {
        val ts = entries.firstOrNull { it.song.id == song.id }?.playedAt ?: 0L
        val rel = PlayHistoryStore.relativeTime(ts)
        return listOf(song.artists, rel).filter { it.isNotBlank() }.joinToString(" · ")
    }

    private fun play(index: Int) {
        val songs = entries.map { it.song }
        if (index !in songs.indices) return
        PlayerEngine.setPlaylist(TAG_HISTORY, songs, index)
        adapter.currentIndex = PlayerEngine.currentIndex
        adapter.notifyDataSetChanged()
        ThemeManager.applyCover(this, songs[index].cover)
        openPageUp(Intent(this, PlayerActivity::class.java), singleTop = true)
    }

    private fun confirmClear() {
        if (entries.isEmpty()) {
            toast(getString(R.string.history_empty))
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.history_clear)
            .setMessage(R.string.history_clear_confirm)
            .setPositiveButton(R.string.timer_ok) { _, _ ->
                PlayHistoryStore.clear()
                load()
                toast(getString(R.string.history_cleared))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
