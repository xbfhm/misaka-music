package com.xbfhm.misakamusic.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.util.AttributeSet

/**
 * 液态玻璃导航胶囊背景 (移动端 Liquid Glass)。
 *
 * 分层绘制 (从下到上):
 *  1. 半透明白玻璃底 (磨砂感) + 圆角
 *  2. 顶部斜向高光渐变 (通透感)
 *  3. 彩虹色散描边 (SweepGradient 沿圆角环流动, 模拟光的折射色散)
 *     双层: 内层窄高亮 + 外层宽低亮辉光, 形成「色散 + 泛光」效果
 *  4. 1dp 高光描边收边 (玻璃边缘)
 *
 * 全部矢量绘制, 任意分辨率下都保持 9:16 高清锐利。
 */
class GlassNavBackground : Drawable {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val density: Float
    private var cornerRadiusPx: Float
    private var rainbowAlpha: Float

    constructor(context: Context) : this(context, null)

    constructor(context: Context, attrs: AttributeSet?) : super() {
        density = context.resources.displayMetrics.density
        // 设计规格: 胶囊高 62dp / 圆角 30dp (Figma 382×60px @1x 等比放大), 固定值保证一致
        cornerRadiusPx = 30f * density
        rainbowAlpha = 0.5f
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        rect.set(b)
        val rad = cornerRadiusPx.coerceAtMost(rect.height() / 2f)
        path.reset()
        path.addRoundRect(rect, rad, rad, Path.Direction.CW)

        val cx = rect.centerX()
        val cy = rect.centerY()

        // 1. 玻璃底
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = 0x1FFFFFFF.toInt() // glass_surface_strong ≈ 12% 白
        canvas.drawPath(path, paint)

        // 2. 顶部高光 (上 55% 高光渐变)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            0f, rect.top, 0f, rect.top + rect.height() * 0.55f,
            0x26FFFFFF.toInt(), 0x00FFFFFF.toInt(), Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, paint)
        paint.shader = null

        // 3. 彩虹色散描边 (色散折射)
        val rainbow = intArrayOf(
            0xFFEF5350.toInt(), // 红
            0xFFFFB74D.toInt(), // 橙
            0xFFFFEE58.toInt(), // 黄
            0xFF66BB6A.toInt(), // 绿
            0xFF42A5F5.toInt(), // 蓝
            0xFFAB47BC.toInt(), // 紫
            0xFFEF5350.toInt()  // 回到红, 闭环
        )
        val positions = FloatArray(rainbow.size) { i -> i / (rainbow.size - 1).toFloat() }
        val sweep = SweepGradient(cx, cy, rainbow, positions)
        paint.style = Paint.Style.STROKE

        // 3a. 外层辉光 (宽 + 低透明度, 制造泛光/色散感)
        paint.strokeWidth = 3.2f * density
        paint.color = 0xFFFFFFFF.toInt()
        paint.alpha = (rainbowAlpha * 0.22f * 255).toInt()
        paint.shader = sweep
        canvas.drawPath(path, paint)

        // 3b. 主彩虹环 (细, 较亮)
        paint.strokeWidth = 1.3f * density
        paint.alpha = (rainbowAlpha * 0.85f * 255).toInt()
        canvas.drawPath(path, paint)
        paint.shader = null
        paint.alpha = 255

        // 4. 玻璃高光描边收边
        paint.strokeWidth = 0.8f * density
        paint.color = 0x30FFFFFF.toInt()
        canvas.drawPath(path, paint)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
