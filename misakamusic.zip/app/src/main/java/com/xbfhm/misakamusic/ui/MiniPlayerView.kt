package com.xbfhm.misakamusic.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ViewMiniPlayerBinding
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 常驻迷你播放条 (跨页面显示)
 * 用独立轮询更新, 不占用 PlayerEngine.listener (与 MainActivity/PlayerActivity 互不冲突)
 */
class MiniPlayerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val binding: ViewMiniPlayerBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null

    init {
        binding = ViewMiniPlayerBinding.inflate(LayoutInflater.from(context), this, true)

        binding.btnPrev.setOnClickListener {
            PlayerEngine.prev()
            refresh()
        }
        binding.btnPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            refresh()
        }
        binding.btnNext.setOnClickListener {
            PlayerEngine.next()
            refresh()
        }
        setOnClickListener {
            val act = context as? Activity
            act?.startActivity(Intent(act, PlayerActivity::class.java))
            act?.overridePendingTransition(R.anim.slide_in_bottom, R.anim.slide_out_bottom)
        }

        refresh()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startTicker()
        refresh()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        ticker?.cancel()
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                refresh()
            }
        }
    }

    private fun refresh() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            visibility = View.GONE
            return
        }
        visibility = View.VISIBLE
        binding.title.text = song.name
        binding.artist.text = song.artists
        Glide.with(context)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(binding.cover)
        binding.btnPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
        val dur = song.duration.toInt().coerceAtLeast(1)
        binding.progress.max = dur
        binding.progress.setProgressCompat(
            PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
            true
        )
    }
}
