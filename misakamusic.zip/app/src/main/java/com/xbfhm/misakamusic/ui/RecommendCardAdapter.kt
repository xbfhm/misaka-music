package com.xbfhm.misakamusic.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ItemSongCardBinding
import com.xbfhm.misakamusic.model.Song

/** namida 风格横向大卡片适配器 (推荐横廊) */
class RecommendCardAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<RecommendCardAdapter.VH>() {

    private val items = mutableListOf<Song>()
    var currentIndex: Int = -1

    fun submit(list: List<Song>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val playing = position == currentIndex
        val ctx = holder.binding.root.context
        holder.binding.tvName.text = (if (playing) "♪ " else "") + s.name
        holder.binding.tvArtist.text = s.artists
        holder.binding.tvVip.visibility = if (s.fee > 0) View.VISIBLE else View.GONE
        if (playing) {
            holder.binding.tvName.setTextColor(ContextCompat.getColor(ctx, R.color.namida_primary))
        } else {
            val ta = ctx.obtainStyledAttributes(intArrayOf(android.R.attr.textColorPrimary))
            holder.binding.tvName.setTextColor(ta.getColor(0, 0xFF000000.toInt()))
            ta.recycle()
        }
        Glide.with(holder.binding.cover)
            .load(s.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(holder.binding.cover)
        holder.binding.root.setOnClickListener { onClick(position) }
    }

    class VH(val binding: ItemSongCardBinding) : RecyclerView.ViewHolder(binding.root)
}
