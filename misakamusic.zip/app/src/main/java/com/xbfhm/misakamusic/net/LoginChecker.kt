package com.xbfhm.misakamusic.net

import android.content.Context
import com.xbfhm.misakamusic.util.Logger

/**
 * 登录状态检测。
 *
 * 场景: Cookie(或扫码)登录后, 网易云的登录态可能因为
 *  - 在别处退出登录 / 改密码 / 主动踢出
 *  - Cookie 过期 (网页 Cookie 有效期有限)
 *  - 服务端风控失效
 * 而失效, 此时如果 App 不检测, 会出现「界面显示已登录, 但歌单/收藏/播放全部失败」。
 *
 * 这里统一做一次轻量校验 (账号信息接口), 明确区分三种结果:
 *  - [State.VALID]        登录有效 (顺带刷新昵称/头像/uid)
 *  - [State.INVALID]      Cookie 已失效, 已清空本地登录态, 需要重新登录
 *  - [State.OFFLINE]      网络异常, 无法判断, **保留**登录态 (避免误踢)
 */
object LoginChecker {

    enum class State { UNKNOWN, NOT_LOGGED_IN, VALID, INVALID, OFFLINE }

    /** 上次检测间隔: 10 分钟内不重复检测 (force=true 可跳过) */
    private const val THROTTLE_MS = 10 * 60 * 1000L

    @Volatile
    var state: State = State.UNKNOWN
        private set

    /** 最近一次检测的说明文字 (用于设置页展示/日志) */
    @Volatile
    var lastMessage: String = ""
        private set

    @Volatile
    var lastCheckAt: Long = 0L
        private set

    /** 检测到失效时的回调 (主线程外的调用方负责切主线程) */
    @Volatile
    var onInvalid: (() -> Unit)? = null

    /** 是否已经因为失效提示过用户 (避免重复弹窗) */
    @Volatile
    var notifiedInvalid: Boolean = false
        private set

    suspend fun check(ctx: Context, force: Boolean = false): State {
        if (!Session.isLoggedIn()) {
            state = State.NOT_LOGGED_IN
            lastMessage = "未登录"
            return state
        }
        val now = System.currentTimeMillis()
        if (!force && now - lastCheckAt < THROTTLE_MS && state != State.UNKNOWN) {
            return state
        }
        lastCheckAt = now

        val r = try {
            NeteaseApi.accountState(ctx)
        } catch (e: Exception) {
            Logger.log("LoginCheck", "检测异常: ${e.message}")
            NeteaseApi.AccountState(false, offline = true, message = "网络异常: ${e.message}")
        }

        state = when {
            r.offline -> State.OFFLINE
            r.valid -> State.VALID
            else -> State.INVALID
        }
        lastMessage = r.message
        Logger.log("LoginCheck", "结果=$state, $lastMessage")

        if (state == State.VALID) {
            notifiedInvalid = false
            Session.nickname = r.nickname.ifBlank { Session.nickname }
            Session.avatar = r.avatar.ifBlank { Session.avatar }
            Session.uid = r.uid
        } else if (state == State.INVALID) {
            // 明确失效: 清空本地登录态, 保证界面与真实状态一致
            Session.clearLogin()
            Session.clearLiked()
            if (!notifiedInvalid) {
                notifiedInvalid = true
                onInvalid?.invoke()
            }
        }
        return state
    }

    /** 触发放开检测的节流 (例如刚登录成功后) */
    fun reset() {
        lastCheckAt = 0L
        state = State.UNKNOWN
        notifiedInvalid = false
    }
}
