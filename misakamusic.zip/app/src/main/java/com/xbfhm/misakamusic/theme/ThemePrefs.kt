package com.xbfhm.misakamusic.theme

import android.content.Context
import android.content.SharedPreferences

/**
 * 主题偏好: 动态取色开关 + 固定主题色。
 * 放在 ThemeManager 之外, 避免 ThemeManager 反向依赖 Context。
 */
object ThemePrefs {

    private const val PREFS = "theme_prefs"

    /** 可选固定主题色 (名称 -> 颜色) */
    val PRESETS: List<Pair<String, Int>> = listOf(
        "绯红" to 0xFFFF6B6B.toInt(),
        "御坂蓝" to 0xFF4EA8FF.toInt(),
        "初音绿" to 0xFF39C5BB.toInt(),
        "星野紫" to 0xFFB18CFF.toInt(),
        "落日橙" to 0xFFFF9557.toInt(),
        "樱粉" to 0xFFFF8FC7.toInt(),
        "青柠" to 0xFF7ED957.toInt(),
        "蔚蓝" to 0xFF5B8DEF.toInt()
    )

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    private fun p(): SharedPreferences? = prefs

    /** 动态取色: 跟随封面 (默认开) */
    var dynamicColor: Boolean
        get() = p()?.getBoolean("dynamic", true) ?: true
        set(v) {
            p()?.edit()?.putBoolean("dynamic", v)?.apply()
        }

    /** 固定主题色种子 */
    var fixedSeed: Int
        get() = p()?.getInt("fixed_seed", ThemeManager.DEFAULT_PRIMARY) ?: ThemeManager.DEFAULT_PRIMARY
        set(v) {
            p()?.edit()?.putInt("fixed_seed", v)?.apply()
        }

    /** 应用当前设置到 ThemeManager */
    fun apply(animate: Boolean = true) {
        if (dynamicColor) {
            ThemeManager.reset(animate)
        } else {
            ThemeManager.applySeed(fixedSeed, animate)
        }
    }
}
