package com.xbfhm.misakamusic.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.BuildConfig
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityAboutBinding

class AboutActivity : BaseActivity() {

    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.tvVersion.text =
            "${getString(R.string.version_label)} ${BuildConfig.VERSION_NAME}"
    }
}
