package com.xbfhm.misakamusic.player

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.xbfhm.misakamusic.util.Logger
import java.util.Calendar

/**
 * 定时播放 (到点自动开始播放上次的歌单)。
 *
 * 实现: AlarmManager 定时 -> [PlayAlarmReceiver] -> 恢复本地队列快照并开始播放。
 * 由于闹钟会在 App 被杀后重新拉起进程, Application.onCreate 会先把
 * Session / PlayerEngine / URL 解析器初始化好, 因此可以直接播放。
 */
object PlayScheduler {

    private const val PREFS = "play_scheduler"
    private const val RC = 20261003

    /** 是否已开启定时播放 */
    fun isEnabled(ctx: Context): Boolean = p(ctx).getBoolean("enabled", false)

    fun hour(ctx: Context): Int = p(ctx).getInt("hour", 7)

    fun minute(ctx: Context): Int = p(ctx).getInt("minute", 30)

    /** 是否每天重复 */
    fun repeatDaily(ctx: Context): Boolean = p(ctx).getBoolean("repeat", false)

    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 设置定时播放 (hour:minute), [repeatDaily] 为 true 时每天重复 */
    fun schedule(ctx: Context, hour: Int, minute: Int, repeatDaily: Boolean) {
        p(ctx).edit()
            .putBoolean("enabled", true)
            .putInt("hour", hour)
            .putInt("minute", minute)
            .putBoolean("repeat", repeatDaily)
            .apply()
        val at = nextTriggerAt(ctx)
        setAlarm(ctx, at)
        Logger.log("Timer", "定时播放已设置: ${label(ctx)} (${if (repeatDaily) "每天" else "仅一次"}), 触发时间=$at")
    }

    fun cancel(ctx: Context) {
        p(ctx).edit().putBoolean("enabled", false).apply()
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        am?.cancel(pending(ctx))
        Logger.log("Timer", "定时播放已取消")
    }

    /** 最近一次触发时间戳 (0 = 未开启) */
    fun nextTriggerAt(ctx: Context): Long {
        if (!isEnabled(ctx)) return 0L
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour(ctx))
            set(Calendar.MINUTE, minute(ctx))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun label(ctx: Context): String =
        "%02d:%02d".format(hour(ctx), minute(ctx)) + if (repeatDaily(ctx)) " 每天" else " 仅一次"

    private fun pending(ctx: Context): PendingIntent {
        val i = Intent(ctx, PlayAlarmReceiver::class.java).setAction("com.xbfhm.misakamusic.PLAY_ALARM")
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(ctx, RC, i, flags)
    }

    private fun setAlarm(ctx: Context, at: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pi = pending(ctx)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (t: Throwable) {
            // Android 12+ 没有精确闹钟权限时退化为非精确闹钟
            Logger.log("Timer", "精确闹钟不可用(${t.message}), 退化为普通闹钟")
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (t2: Throwable) {
                Logger.log("Timer", "设置闹钟失败: ${t2.message}")
            }
        }
    }

    /** 闹钟触发后的收尾: 非重复模式关闭, 重复模式安排下一次 */
    internal fun rescheduleAfterFire(ctx: Context) {
        if (!isEnabled(ctx)) return
        if (repeatDaily(ctx)) {
            setAlarm(ctx, nextTriggerAt(ctx))
            Logger.log("Timer", "定时播放(每天)已安排下一次")
        } else {
            p(ctx).edit().putBoolean("enabled", false).apply()
            Logger.log("Timer", "定时播放(仅一次)已完成, 自动关闭")
        }
    }
}

/** 定时播放闹钟接收器 (同时处理开机后重新排程) */
class PlayAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: ""
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            // 重启后闹钟会被系统清空, 需要重新排一次
            if (PlayScheduler.isEnabled(context)) {
                Logger.log("Timer", "开机完成, 重新排程定时播放")
                PlayScheduler.schedule(context, PlayScheduler.hour(context), PlayScheduler.minute(context), PlayScheduler.repeatDaily(context))
            }
            return
        }
        Logger.log("Timer", "定时播放闹钟触发")
        if (!PlayScheduler.isEnabled(context)) {
            Logger.log("Timer", "定时播放已被取消, 忽略")
            return
        }
        val snap = PlayQueueStore.load(context)
        if (snap.isEmpty()) {
            Logger.log("Timer", "本地没有可播放的队列, 定时播放跳过")
        } else {
            val start = snap.index.coerceIn(0, snap.songs.size - 1)
            Logger.log("Timer", "开始定时播放: ${snap.songs.size} 首, 从第 ${start + 1} 首开始")
            try {
                PlayerEngine.setPlaylist(snap.tag, snap.songs, start)
            } catch (e: Exception) {
                Logger.log("Timer", "定时播放失败: ${e.message}")
            }
        }
        PlayScheduler.rescheduleAfterFire(context)
    }
}
