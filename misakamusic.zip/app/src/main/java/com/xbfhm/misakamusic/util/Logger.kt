package com.xbfhm.misakamusic.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 全局日志: 内存环形缓冲, 保留最近 500 行。
 * 用于定位「播放几秒后中断/返回主界面」等疑难问题。
 * 日志页 (LogActivity) 可一键复制全部缓冲。
 *
 * ★ 安全审查 v4.0.0: 所有日志**统一打码**敏感字段。
 *   MUSIC_U / __csrf 等价于账号密码, 一旦被截进日志再被用户复制粘贴到群里,
 *   等于把账号送人。这里在入库前就把这些值替换成 `abcd***`。
 */
object Logger {

    private const val MAX_LINES = 500
    private val buffer = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    /** 需要打码的 key=value 字段 (登录凭据 / 会话 token) */
    private val SECRET_RE = Regex(
        "(?i)\\b(MUSIC_U|MUSIC_A|__csrf|SESSDATA|bili_jct|access_token|refresh_token)=([^;\\s,&]{0,4})[^;\\s,&]*"
    )

    @Synchronized
    fun log(tag: String, msg: String) {
        val safe = redact(msg)
        val line = "${fmt.format(Date())} [$tag] $safe"
        buffer.addLast(line)
        while (buffer.size > MAX_LINES) buffer.removeFirst()
        Log.d("Misaka/$tag", safe)
    }

    /** 把 cookie / token 值打码, 只保留前 4 位便于确认「有没有值」 */
    fun redact(msg: String): String =
        SECRET_RE.replace(msg) { m -> "${m.groupValues[1]}=${m.groupValues[2]}***" }

    /** 最近 N 行 (默认 500), 拼接成字符串 */
    @Synchronized
    fun recent(): String = buffer.joinToString("\n")

    @Synchronized
    fun recentLines(): List<String> = buffer.toList()

    @Synchronized
    fun clear() = buffer.clear()
}
