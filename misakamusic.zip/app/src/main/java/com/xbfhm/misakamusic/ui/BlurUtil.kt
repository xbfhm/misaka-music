package com.xbfhm.misakamusic.ui

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import java.io.InputStream

/**
 * 轻量高斯模糊 (三次盒式模糊近似), 不依赖 RenderScript / RenderEffect,
 * 因此在 Android 5.1 (API 22) 的老电视 / 老手机上同样可用。
 *
 * 做法: 先把原图缩小到最长边 [MAX_EDGE], 再做模糊 —— 一方面极快,
 * 另一方面天然带来「磨砂玻璃」的柔和过渡, 正是玻璃拟态要的效果。
 */
object BlurUtil {

    /** 背景位图最长边 (够 1080p 铺满, 内存友好) */
    private const val MAX_EDGE = 720

    /** 从资源解码 + 缩放 +（可选）模糊 */
    fun decodeResource(res: Resources, resId: Int, radius: Int, reqWidth: Int = MAX_EDGE): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeResource(res, resId, bounds)
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, reqWidth)
            }
            val bmp = BitmapFactory.decodeResource(res, resId, opts) ?: return null
            val scaled = scaleDown(bmp, reqWidth)
            if (radius > 0) blur(scaled, radius) else scaled
        } catch (t: Throwable) {
            null
        }
    }

    /** 从输入流解码 (相册图片) + 缩放 +（可选）模糊 */
    fun decodeStream(open: () -> InputStream?, radius: Int, reqWidth: Int = MAX_EDGE): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, reqWidth)
            }
            val bmp = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val scaled = scaleDown(bmp, reqWidth)
            if (radius > 0) blur(scaled, radius) else scaled
        } catch (t: Throwable) {
            null
        }
    }

    private fun sampleSize(w: Int, h: Int, req: Int): Int {
        var s = 1
        if (w <= 0 || h <= 0) return s
        var maxDim = maxOf(w, h)
        while (maxDim / 2 >= req) {
            maxDim /= 2
            s *= 2
        }
        return s
    }

    private fun scaleDown(src: Bitmap, req: Int): Bitmap {
        val maxDim = maxOf(src.width, src.height)
        if (maxDim <= req) return src
        val ratio = req.toFloat() / maxDim
        val w = (src.width * ratio).toInt().coerceAtLeast(1)
        val h = (src.height * ratio).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            src,
            Rect(0, 0, src.width, src.height),
            Rect(0, 0, w, h),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )
        if (out != src) src.recycle()
        return out
    }

    /** 三次盒式模糊 ≈ 高斯模糊 */
    fun blur(src: Bitmap, radius: Int): Bitmap {
        if (radius < 1 || src.width < 2 || src.height < 2) return src
        val w = src.width
        val h = src.height
        val pix = IntArray(w * h)
        src.getPixels(pix, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        repeat(3) {
            boxH(pix, tmp, w, h, radius)
            boxV(tmp, pix, w, h, radius)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(pix, 0, w, 0, 0, w, h)
        if (out != src) src.recycle()
        return out
    }

    private fun boxH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val base = y * w
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = src[base + i.coerceIn(0, w - 1)]
                sr += (c ushr 16) and 0xFF
                sg += (c ushr 8) and 0xFF
                sb += c and 0xFF
            }
            for (x in 0 until w) {
                dst[base + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val outC = src[base + (x - r).coerceIn(0, w - 1)]
                val inC = src[base + (x + r + 1).coerceIn(0, w - 1)]
                sr += ((inC ushr 16) and 0xFF) - ((outC ushr 16) and 0xFF)
                sg += ((inC ushr 8) and 0xFF) - ((outC ushr 8) and 0xFF)
                sb += (inC and 0xFF) - (outC and 0xFF)
            }
        }
    }

    private fun boxV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = src[i.coerceIn(0, h - 1) * w + x]
                sr += (c ushr 16) and 0xFF
                sg += (c ushr 8) and 0xFF
                sb += c and 0xFF
            }
            for (y in 0 until h) {
                dst[y * w + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val outC = src[(y - r).coerceIn(0, h - 1) * w + x]
                val inC = src[(y + r + 1).coerceIn(0, h - 1) * w + x]
                sr += ((inC ushr 16) and 0xFF) - ((outC ushr 16) and 0xFF)
                sg += ((inC ushr 8) and 0xFF) - ((outC ushr 8) and 0xFF)
                sb += (inC and 0xFF) - (outC and 0xFF)
            }
        }
    }
}
