package com.xbfhm.misakamusic.net

import android.content.Context
import android.os.Build
import com.xbfhm.misakamusic.crypto.NeteaseCrypto
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.model.User
import com.xbfhm.misakamusic.util.Logger
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * 网易云音乐 API 客户端 (独立实现, 无需服务器)
 * 加密/接口路径 对齐 NeteaseCloudMusicApi 4.32.0
 */
object NeteaseApi {

    private const val DOMAIN = "https://music.163.com"
    private const val API_DOMAIN = "https://interface.music.163.com"
    private const val UA_WEAPI = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"

    private fun uaApi(): String {
        return "NeteaseMusic/${Device.APPV}(${Device.VERSION_CODE});Dalvik/2.1.0 (Linux; U; Android ${Device.OSVER}; ${Device.MOBILE_NAME} Build/${Build.DISPLAY ?: "UKQ1.230804.001"})"
    }

    // ================= 加密请求底层 =================

    private fun buildEapiHeader(ctx: Context): JSONObject {
        val h = JSONObject()
        h.put("osver", Device.OSVER)
        h.put("deviceId", Device.id(ctx))
        h.put("os", Device.OS)
        h.put("appver", Device.APPV)
        h.put("versioncode", Device.VERSION_CODE)
        h.put("mobilename", Device.MOBILE_NAME)
        h.put("buildver", System.currentTimeMillis().toString().substring(0, 10))
        h.put("resolution", Device.RESOLUTION)
        h.put("__csrf", Session.get("__csrf") ?: "")
        h.put("channel", Device.CHANNEL)
        h.put("requestId", System.currentTimeMillis().toString() + "_" + (Math.random() * 1000).toInt().toString().padStart(4, '0'))
        Session.get("MUSIC_U")?.takeIf { it.isNotEmpty() }?.let { h.put("MUSIC_U", it) }
        Session.get("MUSIC_A")?.takeIf { it.isNotEmpty() }?.let { h.put("MUSIC_A", it) }
        return h
    }

    private fun eapiCookie(ctx: Context): String {
        val h = buildEapiHeader(ctx)
        val parts = ArrayList<String>()
        val it = h.keys()
        while (it.hasNext()) {
            val k = it.next()
            parts.add(URLEncoder.encode(k, "UTF-8") + "=" + URLEncoder.encode(h.getString(k), "UTF-8"))
        }
        return parts.joinToString("; ")
    }

    private fun handleSetCookies(resp: Http.Resp) {
        resp.setCookies.forEach { sc ->
            val i = sc.indexOf(';')
            val pair = if (i > 0) sc.substring(0, i) else sc
            val eq = pair.indexOf('=')
            if (eq > 0) {
                val k = pair.substring(0, eq).trim()
                val v = pair.substring(eq + 1).trim()
                if (k.isNotEmpty() && v.isNotEmpty()) Session.put(k, v)
            }
        }
    }

    private fun parseObj(resp: Http.Resp): JSONObject {
        handleSetCookies(resp)
        return try {
            JSONObject(resp.body)
        } catch (e: Exception) {
            JSONObject().put("code", -1).put("message", "网络异常: ${resp.body.take(120)}")
        }
    }

    private fun callWeapi(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        Session.get("__csrf")?.takeIf { it.isNotEmpty() }?.let { payload.put("csrf_token", it) }
        val (params, encSecKey) = NeteaseCrypto.weapi(payload.toString())
        val resp = Http.postForm(
            DOMAIN + "/weapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params, "encSecKey" to encSecKey),
            Session.cookieHeader(),
            mapOf("Referer" to DOMAIN, "User-Agent" to UA_WEAPI)
        )
        return parseObj(resp)
    }

    private fun callEapi(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        payload.put("header", buildEapiHeader(ctx))
        val params = NeteaseCrypto.eapi(uri, payload.toString())
        val resp = Http.postForm(
            API_DOMAIN + "/eapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params),
            eapiCookie(ctx),
            mapOf("User-Agent" to uaApi())
        )
        return parseObj(resp)
    }

    // ================= 登录 =================

    private fun cloudmusicDllEncodeId(id: String): String {
        val key = "3go8&\$8*3*3h0k(2)2"
        val sb = StringBuilder()
        for (i in id.indices) {
            sb.append((id[i].code xor key[i % key.length].code).toChar())
        }
        val md = java.security.MessageDigest.getInstance("MD5")
        return android.util.Base64.encodeToString(
            md.digest(sb.toString().toByteArray(Charsets.UTF_8)),
            android.util.Base64.NO_WRAP
        )
    }

    fun registerAnonymous(ctx: Context): Boolean {
        return try {
            val deviceId = Device.id(ctx)
            val encoded = android.util.Base64.encodeToString(
                "$deviceId ${cloudmusicDllEncodeId(deviceId)}".toByteArray(Charsets.UTF_8),
                android.util.Base64.NO_WRAP
            )
            val j = callWeapi(ctx, "/api/register/anonimous", JSONObject().put("username", encoded))
            if (!Session.has("MUSIC_A")) {
                j.optString("token", "").takeIf { it.isNotBlank() }?.let { Session.put("MUSIC_A", it) }
            }
            Session.has("MUSIC_A")
        } catch (_: Exception) {
            false
        }
    }

    fun ensureAnonymous(ctx: Context) {
        if (Session.isLoggedIn()) return
        if (Session.has("MUSIC_A")) return
        registerAnonymous(ctx)
    }

    fun qrKey(ctx: Context): String {
        ensureAnonymous(ctx)
        val j = callEapi(ctx, "/api/login/qrcode/unikey", JSONObject().put("type", 3))
        val inner = j.optJSONObject("data")
        val key = inner?.optString("unikey", "")?.takeIf { it.isNotEmpty() } ?: j.optString("unikey", "")
        return key
    }

    fun qrCheck(ctx: Context, key: String): JSONObject {
        return callEapi(ctx, "/api/login/qrcode/client/login", JSONObject().put("key", key).put("type", 3))
    }

    fun sendCaptcha(ctx: Context, phone: String, ctcode: String = "86"): JSONObject {
        return callWeapi(ctx, "/api/sms/captcha/sent", JSONObject()
            .put("ctcode", ctcode)
            .put("secrete", "music_middleuser_pclogin")
            .put("cellphone", phone))
    }

    fun verifyCaptcha(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        return callWeapi(ctx, "/api/sms/captcha/verify", JSONObject()
            .put("ctcode", ctcode)
            .put("cellphone", phone)
            .put("captcha", captcha))
    }

    fun loginByCaptcha(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callWeapi(ctx, "/api/login/cellphone", JSONObject()
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("rememberLogin", "true"))
    }

    fun loginByCaptchaEapi(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callEapi(ctx, "/api/login/cellphone", JSONObject()
            .put("type", "1")
            .put("https", "true")
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("remember", "true"))
    }

    fun loginByCaptchaOldWeapi(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callWeapi(ctx, "/api/login/cellphone", JSONObject()
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("rememberLogin", "true"))
    }

    fun refreshLogin(ctx: Context): JSONObject {
        return callEapi(ctx, "/api/login/token/refresh", JSONObject())
    }

    fun accountInfo(ctx: Context): JSONObject {
        return callWeapi(ctx, "/api/w/nuser/account/get", JSONObject())
    }

    /**
     * Cookie 登录后: 拉取资料并严格校验登录态
     * @return true=有效真实登录; false=Cookie 无效/匿名
     */
    fun afterLogin(ctx: Context): Boolean {
        // 1) 尝试刷新登录态
        try {
            val refresh = refreshLogin(ctx)
            Logger.log("Login", "refreshLogin code=${refresh.optInt("code")}")
        } catch (e: Exception) {
            Logger.log("Login", "refreshLogin 异常: ${e.message}")
        }

        // 2) 拉取账号信息
        val info = accountInfo(ctx)
        val code = info.optInt("code", -1)
        Logger.log("Login", "accountInfo code=$code")

        val profile = info.optJSONObject("profile")
        val account = info.optJSONObject("account")
        val uid = profile?.optLong("userId", 0) ?: 0L
        val nickname = profile?.optString("nickname", "") ?: ""
        val vipType = account?.optInt("vipType", 0) ?: 0

        Logger.log("Login", "profile=$profile, uid=$uid, nickname=$nickname, vipType=$vipType")

        // 3) 严格校验: 必须有真实 profile 且 uid > 1 且有昵称
        //    uid=0 或 uid=1 通常是匿名/无效 cookie
        //    profile=null 说明 cookie 无效或已过期
        if (profile == null) {
            Logger.log("Login", "校验失败: profile 为 null, Cookie 可能无效")
            Session.clearLogin()
            return false
        }
        if (uid <= 1L) {
            Logger.log("Login", "校验失败: uid=$uid <= 1, 匿名或无效 Cookie")
            Session.clearLogin()
            return false
        }
        if (nickname.isBlank()) {
            Logger.log("Login", "校验失败: nickname 为空")
            Session.clearLogin()
            return false
        }

        // 4) 校验通过, 保存用户信息
        Session.nickname = nickname
        Session.avatar = profile.optString("avatarUrl", "")
        Session.uid = uid
        Logger.log("Login", "登录成功: $nickname (uid=$uid, vipType=$vipType)")
        return true
    }

    // ================= 歌单 =================

    fun userPlaylists(ctx: Context, uid: Long, limit: Int = 100): List<Playlist> {
        if (uid <= 0) {
            Logger.log("API", "userPlaylists: uid=$uid <= 0, 返回空")
            return emptyList()
        }
        Logger.log("API", "userPlaylists: uid=$uid")
        val j = callWeapi(ctx, "/api/user/playlist", JSONObject()
            .put("uid", uid)
            .put("limit", limit)
            .put("offset", 0)
            .put("includeVideo", true))
        val arr = j.optJSONArray("playlist")
        Logger.log("API", "userPlaylists: code=${j.optInt("code")}, playlist=${arr?.length() ?: 0}个")
        if (arr == null) return emptyList()
        val list = ArrayList<Playlist>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val creatorUid = o.optJSONObject("creator")?.optLong("userId", 0) ?: 0L
            list.add(Playlist(
                id = o.optLong("id"),
                name = o.optString("name"),
                cover = o.optString("coverImgUrl"),
                trackCount = o.optInt("trackCount"),
                playCount = o.optLong("playCount"),
                isLiked = o.optString("name").contains("我喜欢的音乐") && creatorUid == uid
            ))
        }
        return list
    }

    // ================= 歌曲 =================

    fun playlistTracks(ctx: Context, id: Long, limit: Int = 1000): List<Song> {
        val detail = callEapi(ctx, "/api/v6/playlist/detail", JSONObject()
            .put("id", id).put("n", 100000).put("s", 8))
        val trackIds = detail.optJSONObject("playlist")?.optJSONArray("trackIds") ?: return emptyList()
        val ids = ArrayList<Long>()
        for (i in 0 until trackIds.length()) {
            val tid = trackIds.optJSONObject(i)?.optLong("id") ?: continue
            ids.add(tid)
            if (ids.size >= limit) break
        }
        return songDetails(ctx, ids)
    }

    fun songDetails(ctx: Context, ids: List<Long>): List<Song> {
        if (ids.isEmpty()) return emptyList()
        val result = ArrayList<Song>()
        ids.chunked(200).forEach { chunk ->
            val c = chunk.joinToString(",", prefix = "[", postfix = "]") { "{\"id\":$it}" }
            val j = callEapi(ctx, "/api/v3/song/detail", JSONObject().put("c", c))
            val arr = j.optJSONArray("songs") ?: return@forEach
            for (i in 0 until arr.length()) {
                arr.optJSONObject(i)?.let { result.add(parseSong(it)) }
            }
        }
        return result
    }

    private fun parseSong(o: JSONObject): Song {
        val ar = o.optJSONArray("ar") ?: o.optJSONArray("artists")
        val artists = if (ar == null) "" else
            (0 until ar.length()).joinToString(" / ") { idx ->
                ar.optJSONObject(idx)?.optString("name", "") ?: ""
            }
        val al = o.optJSONObject("al") ?: o.optJSONObject("album")
        var dt = o.optLong("dt", 0)
        if (dt <= 0) dt = o.optLong("duration", 0)
        val tns = o.optJSONArray("tns")
        var alias = if (tns != null && tns.length() > 0) tns.optString(0, "") else ""
        var displayName = o.optString("name")
        if (alias.isNotBlank() && alias != displayName) {
            val nameIsCjk = containsCJK(displayName)
            val aliasIsCjk = containsCJK(alias)
            if (!nameIsCjk && aliasIsCjk) {
                val tmp = displayName
                displayName = alias
                alias = tmp
            }
        }
        return Song(
            id = o.optLong("id"),
            name = displayName,
            artists = artists,
            album = al?.optString("name", "") ?: "",
            duration = dt,
            cover = al?.optString("picUrl", "") ?: "",
            fee = o.optInt("fee", 0),
            alias = alias
        )
    }

    private fun containsCJK(s: String): Boolean {
        if (s.isBlank()) return false
        for (c in s) {
            if (c in '\u4e00'..'\u9fff' || c in '\u3400'..'\u4dbf') return true
        }
        return false
    }

    fun search(ctx: Context, keyword: String, limit: Int = 30): List<Song> {
        if (keyword.isBlank()) return emptyList()
        val j = callWeapi(ctx, "/api/search/get", JSONObject()
            .put("s", keyword)
            .put("type", 1)
            .put("limit", limit)
            .put("offset", 0))
        val arr = j.optJSONObject("result")?.optJSONArray("songs") ?: return emptyList()
        val result = ArrayList<Song>()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { result.add(parseSong(it)) }
        }
        if (result.isNotEmpty()) {
            try {
                val details = songDetails(ctx, result.map { it.id })
                val map = details.associateBy { it.id }
                return result.map { s -> map[s.id] ?: s }
            } catch (_: Exception) {}
        }
        return result
    }

    fun searchUser(ctx: Context, keyword: String, limit: Int = 20): List<User> {
        if (keyword.isBlank()) return emptyList()
        val j = callWeapi(ctx, "/api/search/get", JSONObject()
            .put("s", keyword)
            .put("type", 1002)
            .put("limit", limit)
            .put("offset", 0))
        val arr = j.optJSONObject("result")?.optJSONArray("userprofiles") ?: return emptyList()
        val list = ArrayList<User>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list.add(User(
                id = o.optLong("userId"),
                nickname = o.optString("nickname"),
                avatar = o.optString("avatarUrl"),
                signature = o.optString("signature", "")
            ))
        }
        return list
    }

    fun subscribePlaylist(ctx: Context, id: Long, subscribed: Boolean): JSONObject {
        val action = if (subscribed) "subscribe" else "unsubscribe"
        return callWeapi(ctx, "/api/playlist/$action", JSONObject().put("id", id))
    }

    fun likeSong(ctx: Context, id: Long, like: Boolean): JSONObject {
        return callWeapi(ctx, "/api/radio/like", JSONObject()
            .put("trackId", id)
            .put("like", like))
    }

    fun addSongToPlaylist(ctx: Context, pid: Long, songIds: List<Long>): JSONObject {
        val tracks = songIds.joinToString(",", prefix = "[", postfix = "]")
        return callWeapi(ctx, "/api/playlist/manipulate/tracks", JSONObject()
            .put("op", "add")
            .put("pid", pid)
            .put("trackIds", tracks))
    }

    fun recommendAnime(ctx: Context, count: Int = 20): List<Song> {
        try {
            val j = callWeapi(ctx, "/api/playlist/list", JSONObject()
                .put("cat", "ACG")
                .put("order", "hot")
                .put("limit", 50)
                .put("offset", 0)
                .put("total", true))
            val arr = j.optJSONArray("playlists")
            if (arr != null && arr.length() > 0) {
                val idx = (Math.random() * arr.length()).toInt()
                val id = arr.optJSONObject(idx)?.optLong("id") ?: 0L
                if (id > 0) {
                    val songs = playlistTracks(ctx, id, 50)
                    if (songs.size >= 5) return songs.shuffled().take(count)
                }
            }
        } catch (_: Exception) {}
        return fallbackSearch(ctx)
    }

    fun recommendPool(ctx: Context, target: Int = 200): List<Song> {
        val result = mutableListOf<Song>()
        try {
            val j = callWeapi(ctx, "/api/playlist/list", JSONObject()
                .put("cat", "ACG")
                .put("order", "hot")
                .put("limit", 50)
                .put("offset", 0)
                .put("total", true))
            val arr = j.optJSONArray("playlists")
            if (arr != null && arr.length() > 0) {
                val indices = (0 until arr.length()).shuffled().take(6)
                for (idx in indices) {
                    val id = arr.optJSONObject(idx)?.optLong("id") ?: continue
                    if (id <= 0) continue
                    val songs = try { playlistTracks(ctx, id, 60) } catch (_: Exception) { emptyList() }
                    for (song in songs) {
                        if (result.none { it.id == song.id }) result.add(song)
                        if (result.size >= target) break
                    }
                    if (result.size >= target) break
                }
            }
        } catch (_: Exception) {}
        if (result.size < 10) result.addAll(fallbackSearch(ctx))
        return result.shuffled()
    }

    private fun fallbackSearch(ctx: Context): List<Song> {
        val pool = listOf(
            "初音未来", "孤独摇滚", "鬼灭之刃", "我推的孩子", "进击的巨人",
            "泽野弘之", "四月是你的谎言", "紫罗兰永恒花园", "未闻花名", "你的名字",
            "间谍过家家", "咒术回战", "海贼王", "数码宝贝", "灌篮高手", "东方project"
        )
        val kw = pool[(Math.random() * pool.size).toInt()]
        return try { search(ctx, kw, 20).take(10) } catch (_: Exception) { emptyList() }
    }

    fun songUrl(ctx: Context, id: Long, level: String): String {
        val j = callEapi(ctx, "/api/song/enhance/player/url/v1", JSONObject()
            .put("ids", "[$id]")
            .put("level", level)
            .put("encodeType", "aac"))
        val arr = j.optJSONArray("data") ?: return ""
        return arr.optJSONObject(0)?.optString("url", "") ?: ""
    }

    fun resolvePlayUrl(ctx: Context, id: Long): String? {
        val order = listOf("hires", "lossless", "exhigh", "higher", "standard")
        val start = order.indexOf(Session.quality).coerceAtLeast(0)
        for (i in start until order.size) {
            try {
                val url = songUrl(ctx, id, order[i])
                if (url.isNotBlank()) return url
            } catch (_: Exception) {}
        }
        return null
    }

    // ================= 歌词 / 收藏 =================

    fun lyric(ctx: Context, id: Long): JSONObject {
        val url = DOMAIN + "/api/song/lyric?id=$id&lv=-1&kv=-1&tv=-1"
        val resp = Http.get(url, Session.cookieHeader(), mapOf(
            "Referer" to DOMAIN,
            "User-Agent" to UA_WEAPI
        ))
        return parseObj(resp)
    }

    fun likelist(ctx: Context, uid: Long): Set<Long> {
        if (uid <= 0) return emptySet()
        try {
            val j = callEapi(ctx, "/api/song/like/get", JSONObject().put("uid", uid))
            val arr = j.optJSONArray("ids") ?: return emptySet()
            val set = HashSet<Long>()
            for (i in 0 until arr.length()) {
                val id = arr.optLong(i, 0)
                if (id > 0) set.add(id)
            }
            return set
        } catch (_: Exception) {
            return emptySet()
        }
    }

    // ================= VIP 信息 =================

    data class VipInfo(
        val isVip: Boolean,
        val level: String,
        val expireTime: String
    )

    fun vipInfo(ctx: Context, uid: Long): VipInfo {
        try {
            val j = callEapi(ctx, "/api/music-vip-membership/client/vip/info", JSONObject().put("userId", uid))
            if (j.optInt("code", -1) == 200) {
                val d = j.optJSONObject("data") ?: return VipInfo(false, "", "")
                val level = d.optInt("redVipLevel", 0)
                val pkg = d.optJSONObject("musicPackage")
                var expire = pkg?.optLong("expireTime", 0) ?: 0L
                if (expire <= 0) expire = d.optLong("expireTime", d.optLong("redVipExpireTime", 0))
                val annual = d.optInt("redVipAnnualCount", 0)
                return VipInfo(
                    isVip = level > 0,
                    level = if (level > 0) "Lv.$level" else "",
                    expireTime = if (expire > 0) formatTime(expire)
                                 else if (annual > 0) "年费 · 累计 $annual 年" else ""
                )
            }
        } catch (_: Exception) {}
        try {
            val j = callEapi(ctx, "/api/music-vip-membership/front/vip/info", JSONObject().put("userId", uid))
            if (j.optInt("code", -1) == 200) {
                val d = j.optJSONObject("data") ?: return VipInfo(false, "", "")
                val level = d.optString("redVipLevel", "0")
                val lvl = level.toIntOrNull() ?: 0
                val annual = d.optInt("redVipAnnualCount", 0)
                return VipInfo(
                    isVip = lvl > 0,
                    level = if (lvl > 0) "Lv.$lvl" else "",
                    expireTime = if (annual > 0) "年费 · 累计 $annual 年" else ""
                )
            }
        } catch (_: Exception) {}
        return VipInfo(false, "", "")
    }

    // ================= 播放记录上报 =================

    fun scrobble(ctx: Context, songId: Long, sourceId: Long, timeSec: Int): Boolean {
        if (!Session.isLoggedIn()) {
            Logger.log("Scrobble", "未登录, 跳过上报")
            return false
        }
        if (songId <= 0 || timeSec <= 0) return false
        return try {
            val entry = JSONObject()
                .put("action", "play")
                .put("json", JSONObject()
                    .put("download", 0)
                    .put("end", "playend")
                    .put("id", songId)
                    .put("sourceId", sourceId)
                    .put("time", timeSec)
                    .put("type", "song")
                    .put("wifi", 0))
            val logs = JSONArray().put(entry).toString()
            val j = callWeapi(ctx, "/api/feedback/weblog", JSONObject().put("logs", logs))
            val code = j.optInt("code", -1)
            Logger.log("Scrobble", "weblog code=$code, songId=$songId, time=${timeSec}s")
            code == 200
        } catch (e: Exception) {
            Logger.log("Scrobble", "上报异常: ${e.message}")
            false
        }
    }

    private fun formatTime(ms: Long): String {
        return try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.CHINA)
            sdf.format(java.util.Date(ms))
        } catch (_: Exception) {
            ms.toString()
        }
    }
}
