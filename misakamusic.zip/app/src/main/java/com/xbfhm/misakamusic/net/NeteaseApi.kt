package com.xbfhm.misakamusic.net

import android.content.Context
import android.os.Build
import com.xbfhm.misakamusic.crypto.NeteaseCrypto
import com.xbfhm.misakamusic.model.PlayRecordSummary
import com.xbfhm.misakamusic.model.PlayUrlInfo
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.model.User
import com.xbfhm.misakamusic.util.Logger
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * 网易云音乐 API 客户端 (独立实现, 无需服务器)
 * 加密/接口路径 对齐 NeteaseCloudMusicApi 4.32.0
 */
object NeteaseApi {

    private const val DOMAIN = "https://music.163.com"
    private const val API_DOMAIN = "https://interface.music.163.com"
    private const val UA_WEAPI = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"

    private fun uaApi(): String {
        return "NeteaseMusic/${Device.APPV}(${Device.VERSION_CODE});Dalvik/2.1.0 (Linux; U; Android ${Device.OSVER}; ${Device.MOBILE_NAME} Build/${Build.DISPLAY ?: "UKQ1.230804.001"})"
    }

    // ================= 加密请求底层 =================

    private fun buildEapiHeader(ctx: Context): JSONObject {
        val h = JSONObject()
        h.put("osver", Device.OSVER)
        h.put("deviceId", Device.id(ctx))
        h.put("os", Device.OS)
        h.put("appver", Device.APPV)
        h.put("versioncode", Device.VERSION_CODE)
        h.put("mobilename", Device.MOBILE_NAME)
        h.put("buildver", System.currentTimeMillis().toString().substring(0, 10))
        h.put("resolution", Device.RESOLUTION)
        h.put("__csrf", Session.get("__csrf") ?: "")
        h.put("channel", Device.CHANNEL)
        h.put("requestId", System.currentTimeMillis().toString() + "_" + (Math.random() * 1000).toInt().toString().padStart(4, '0'))
        Session.get("MUSIC_U")?.takeIf { it.isNotEmpty() }?.let { h.put("MUSIC_U", it) }
        Session.get("MUSIC_A")?.takeIf { it.isNotEmpty() }?.let { h.put("MUSIC_A", it) }
        return h
    }

    private fun eapiCookie(ctx: Context): String {
        val h = buildEapiHeader(ctx)
        val parts = ArrayList<String>()
        val it = h.keys()
        while (it.hasNext()) {
            val k = it.next()
            parts.add(URLEncoder.encode(k, "UTF-8") + "=" + URLEncoder.encode(h.getString(k), "UTF-8"))
        }
        return parts.joinToString("; ")
    }

    private fun handleSetCookies(resp: Http.Resp) {
        resp.setCookies.forEach { sc ->
            val i = sc.indexOf(';')
            val pair = if (i > 0) sc.substring(0, i) else sc
            val eq = pair.indexOf('=')
            if (eq > 0) {
                val k = pair.substring(0, eq).trim()
                val v = pair.substring(eq + 1).trim()
                if (k.isNotEmpty() && v.isNotEmpty()) Session.put(k, v)
            }
        }
    }

    private fun parseObj(resp: Http.Resp): JSONObject {
        handleSetCookies(resp)
        return try {
            JSONObject(resp.body)
        } catch (e: Exception) {
            JSONObject().put("code", -1).put("message", "网络异常: ${resp.body.take(120)}")
        }
    }

    private fun callWeapi(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        Session.get("__csrf")?.takeIf { it.isNotEmpty() }?.let { payload.put("csrf_token", it) }
        val (params, encSecKey) = NeteaseCrypto.weapi(payload.toString())
        val resp = Http.postForm(
            DOMAIN + "/weapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params, "encSecKey" to encSecKey),
            Session.cookieHeader(),
            mapOf("Referer" to DOMAIN, "User-Agent" to UA_WEAPI)
        )
        return parseObj(resp)
    }

    private fun callEapi(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        payload.put("header", buildEapiHeader(ctx))
        val params = NeteaseCrypto.eapi(uri, payload.toString())
        val resp = Http.postForm(
            API_DOMAIN + "/eapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params),
            eapiCookie(ctx),
            mapOf("User-Agent" to uaApi())
        )
        return parseObj(resp)
    }

    // ================= 登录 =================

    private fun cloudmusicDllEncodeId(id: String): String {
        val key = "3go8&\$8*3*3h0k(2)2"
        val sb = StringBuilder()
        for (i in id.indices) {
            sb.append((id[i].code xor key[i % key.length].code).toChar())
        }
        val md = java.security.MessageDigest.getInstance("MD5")
        return android.util.Base64.encodeToString(
            md.digest(sb.toString().toByteArray(Charsets.UTF_8)),
            android.util.Base64.NO_WRAP
        )
    }

    fun registerAnonymous(ctx: Context): Boolean {
        return try {
            val deviceId = Device.id(ctx)
            val encoded = android.util.Base64.encodeToString(
                "$deviceId ${cloudmusicDllEncodeId(deviceId)}".toByteArray(Charsets.UTF_8),
                android.util.Base64.NO_WRAP
            )
            val j = callWeapi(ctx, "/api/register/anonimous", JSONObject().put("username", encoded))
            if (!Session.has("MUSIC_A")) {
                j.optString("token", "").takeIf { it.isNotBlank() }?.let { Session.put("MUSIC_A", it) }
            }
            Session.has("MUSIC_A")
        } catch (_: Exception) {
            false
        }
    }

    fun ensureAnonymous(ctx: Context) {
        if (Session.isLoggedIn()) return
        if (Session.has("MUSIC_A")) return
        registerAnonymous(ctx)
    }

    /**
     * 获取网页版扫码登录的 unikey。
     *
     * 二维码内容固定为 `https://music.163.com/login?codekey=<unikey>` —— 也就是网页版
     * 登录页展示的那张二维码，手机网易云音乐 App（扫一扫 / 相册识别）扫码后确认即可登录。
     *
     * @param type 3 = 网页版扫码登录 (官方网页/PC 客户端同源), 1 为兼容回退
     */
    fun qrKey(ctx: Context, type: Int = 3): String {
        ensureAnonymous(ctx)
        val j = callEapi(ctx, "/api/login/qrcode/unikey", JSONObject().put("type", type))
        val inner = j.optJSONObject("data")
        val key = inner?.optString("unikey", "")?.takeIf { it.isNotEmpty() }
            ?: j.optString("unikey", "")
        Logger.log("Login", "qrKey(type=$type) code=${j.optInt("code")} key=${if (key.isEmpty()) "空" else "OK"}")
        return key
    }

    /** 轮询扫码状态: 800 过期 / 801 等待扫码 / 802 已扫码待确认 / 803 成功(回传 MUSIC_U) */
    fun qrCheck(ctx: Context, key: String, type: Int = 3): JSONObject {
        return callEapi(ctx, "/api/login/qrcode/client/login",
            JSONObject().put("key", key).put("type", type))
    }

    fun sendCaptcha(ctx: Context, phone: String, ctcode: String = "86"): JSONObject {
        return callWeapi(ctx, "/api/sms/captcha/sent", JSONObject()
            .put("ctcode", ctcode)
            .put("secrete", "music_middleuser_pclogin")
            .put("cellphone", phone))
    }

    fun verifyCaptcha(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        return callWeapi(ctx, "/api/sms/captcha/verify", JSONObject()
            .put("ctcode", ctcode)
            .put("cellphone", phone)
            .put("captcha", captcha))
    }

    fun loginByCaptcha(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callWeapi(ctx, "/api/login/cellphone", JSONObject()
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("rememberLogin", "true"))
    }

    fun loginByCaptchaEapi(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callEapi(ctx, "/api/login/cellphone", JSONObject()
            .put("type", "1")
            .put("https", "true")
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("remember", "true"))
    }

    fun loginByCaptchaOldWeapi(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callWeapi(ctx, "/api/login/cellphone", JSONObject()
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("rememberLogin", "true"))
    }

    fun refreshLogin(ctx: Context): JSONObject {
        return callEapi(ctx, "/api/login/token/refresh", JSONObject())
    }

    fun accountInfo(ctx: Context): JSONObject {
        return callWeapi(ctx, "/api/w/nuser/account/get", JSONObject())
    }

    /** 账号检测结果 */
    data class AccountState(
        val valid: Boolean,
        val offline: Boolean,
        val uid: Long = 0,
        val nickname: String = "",
        val avatar: String = "",
        val message: String = ""
    )

    /**
     * 轻量校验登录态 (用于「Cookie 是否还有效」的检测)。
     *
     * - weapi 失败时回退 eapi (两种加密通道的登录态判定一致)
     * - profile 为空 / uid<=1 -> 明确失效 (INVALID)
     * - 网络异常 -> offline=true, 调用方**不要**清理登录态
     */
    fun accountState(ctx: Context): AccountState {
        var lastErr = ""
        val tries = listOf<() -> JSONObject>(
            { accountInfo(ctx) },
            { callEapi(ctx, "/api/w/nuser/account/get", JSONObject()) }
        )
        tries.forEachIndexed { idx, call ->
            try {
                val j = call()
                val code = j.optInt("code", -1)
                val profile = j.optJSONObject("profile")
                val uid = profile?.optLong("userId", 0L) ?: 0L
                Logger.log("LoginCheck", "accountState[$idx] code=$code profile=${profile != null} uid=$uid")
                if (profile != null && uid > 1L) {
                    return AccountState(
                        valid = true, offline = false, uid = uid,
                        nickname = profile.optString("nickname", ""),
                        avatar = profile.optString("avatarUrl", ""),
                        message = "登录有效"
                    )
                }
                if (code == 200) {
                    // 服务器明确回答「没有登录」-> 失效
                    return AccountState(
                        valid = false, offline = false,
                        message = "Cookie 已失效（服务器返回未登录）"
                    )
                }
                lastErr = "code=$code"
            } catch (e: Exception) {
                lastErr = e.message ?: "网络异常"
                Logger.log("LoginCheck", "accountState[$idx] 异常: $lastErr")
            }
        }
        return AccountState(false, offline = true, message = "无法连接网易云：$lastErr")
    }

    /**
     * Cookie 登录后: 拉取资料并严格校验登录态
     * @return true=有效真实登录; false=Cookie 无效/匿名
     */
    fun afterLogin(ctx: Context): Boolean {
        // 1) 尝试刷新登录态
        try {
            val refresh = refreshLogin(ctx)
            Logger.log("Login", "refreshLogin code=${refresh.optInt("code")}")
        } catch (e: Exception) {
            Logger.log("Login", "refreshLogin 异常: ${e.message}")
        }

        // 2) 拉取账号信息
        val info = accountInfo(ctx)
        val code = info.optInt("code", -1)
        Logger.log("Login", "accountInfo code=$code")

        val profile = info.optJSONObject("profile")
        val account = info.optJSONObject("account")
        val uid = profile?.optLong("userId", 0) ?: 0L
        val nickname = profile?.optString("nickname", "") ?: ""
        val vipType = account?.optInt("vipType", 0) ?: 0

        Logger.log("Login", "profile=$profile, uid=$uid, nickname=$nickname, vipType=$vipType")

        // 3) 严格校验: 必须有真实 profile 且 uid > 1 且有昵称
        //    uid=0 或 uid=1 通常是匿名/无效 cookie
        //    profile=null 说明 cookie 无效或已过期
        if (profile == null) {
            Logger.log("Login", "校验失败: profile 为 null, Cookie 可能无效")
            Session.clearLogin()
            return false
        }
        if (uid <= 1L) {
            Logger.log("Login", "校验失败: uid=$uid <= 1, 匿名或无效 Cookie")
            Session.clearLogin()
            return false
        }
        if (nickname.isBlank()) {
            Logger.log("Login", "校验失败: nickname 为空")
            Session.clearLogin()
            return false
        }

        // 4) 校验通过, 保存用户信息
        Session.nickname = nickname
        Session.avatar = profile.optString("avatarUrl", "")
        Session.uid = uid
        Logger.log("Login", "登录成功: $nickname (uid=$uid, vipType=$vipType)")
        return true
    }

    // ================= 歌单 =================

    fun userPlaylists(ctx: Context, uid: Long, limit: Int = 100): List<Playlist> {
        if (uid <= 0) {
            Logger.log("API", "userPlaylists: uid=$uid <= 0, 返回空")
            return emptyList()
        }
        Logger.log("API", "userPlaylists: uid=$uid")
        val j = callWeapi(ctx, "/api/user/playlist", JSONObject()
            .put("uid", uid)
            .put("limit", limit)
            .put("offset", 0)
            .put("includeVideo", true))
        val arr = j.optJSONArray("playlist")
        Logger.log("API", "userPlaylists: code=${j.optInt("code")}, playlist=${arr?.length() ?: 0}个")
        if (arr == null) return emptyList()
        val list = ArrayList<Playlist>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val creatorUid = o.optJSONObject("creator")?.optLong("userId", 0) ?: 0L
            list.add(Playlist(
                id = o.optLong("id"),
                name = o.optString("name"),
                cover = o.optString("coverImgUrl"),
                trackCount = o.optInt("trackCount"),
                playCount = o.optLong("playCount"),
                isLiked = o.optString("name").contains("我喜欢的音乐") && creatorUid == uid
            ))
        }
        return list
    }

    // ================= 歌曲 =================

    fun playlistTracks(ctx: Context, id: Long, limit: Int = 1000): List<Song> {
        val detail = callEapi(ctx, "/api/v6/playlist/detail", JSONObject()
            .put("id", id).put("n", 100000).put("s", 8))
        val trackIds = detail.optJSONObject("playlist")?.optJSONArray("trackIds") ?: return emptyList()
        val ids = ArrayList<Long>()
        for (i in 0 until trackIds.length()) {
            val tid = trackIds.optJSONObject(i)?.optLong("id") ?: continue
            ids.add(tid)
            if (ids.size >= limit) break
        }
        return songDetails(ctx, ids)
    }

    fun songDetails(ctx: Context, ids: List<Long>): List<Song> {
        if (ids.isEmpty()) return emptyList()
        val result = ArrayList<Song>()
        ids.chunked(200).forEach { chunk ->
            val c = chunk.joinToString(",", prefix = "[", postfix = "]") { "{\"id\":$it}" }
            val j = callEapi(ctx, "/api/v3/song/detail", JSONObject().put("c", c))
            val arr = j.optJSONArray("songs") ?: return@forEach
            for (i in 0 until arr.length()) {
                arr.optJSONObject(i)?.let { result.add(parseSong(it)) }
            }
        }
        return result
    }

    private fun parseSong(o: JSONObject): Song {
        val ar = o.optJSONArray("ar") ?: o.optJSONArray("artists")
        val artists = if (ar == null) "" else
            (0 until ar.length()).joinToString(" / ") { idx ->
                ar.optJSONObject(idx)?.optString("name", "") ?: ""
            }
        val al = o.optJSONObject("al") ?: o.optJSONObject("album")
        var dt = o.optLong("dt", 0)
        if (dt <= 0) dt = o.optLong("duration", 0)
        val tns = o.optJSONArray("tns")
        var alias = if (tns != null && tns.length() > 0) tns.optString(0, "") else ""
        var displayName = o.optString("name")
        if (alias.isNotBlank() && alias != displayName) {
            val nameIsCjk = containsCJK(displayName)
            val aliasIsCjk = containsCJK(alias)
            if (!nameIsCjk && aliasIsCjk) {
                val tmp = displayName
                displayName = alias
                alias = tmp
            }
        }
        return Song(
            id = o.optLong("id"),
            name = displayName,
            artists = artists,
            album = al?.optString("name", "") ?: "",
            duration = dt,
            cover = al?.optString("picUrl", "") ?: "",
            fee = o.optInt("fee", 0),
            alias = alias
        )
    }

    private fun containsCJK(s: String): Boolean {
        if (s.isBlank()) return false
        for (c in s) {
            if (c in '\u4e00'..'\u9fff' || c in '\u3400'..'\u4dbf') return true
        }
        return false
    }

    fun search(ctx: Context, keyword: String, limit: Int = 30): List<Song> {
        if (keyword.isBlank()) return emptyList()
        val j = callWeapi(ctx, "/api/search/get", JSONObject()
            .put("s", keyword)
            .put("type", 1)
            .put("limit", limit)
            .put("offset", 0))
        val arr = j.optJSONObject("result")?.optJSONArray("songs") ?: return emptyList()
        val result = ArrayList<Song>()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { result.add(parseSong(it)) }
        }
        if (result.isNotEmpty()) {
            try {
                val details = songDetails(ctx, result.map { it.id })
                val map = details.associateBy { it.id }
                return result.map { s -> map[s.id] ?: s }
            } catch (_: Exception) {}
        }
        return result
    }

    fun searchUser(ctx: Context, keyword: String, limit: Int = 20): List<User> {
        if (keyword.isBlank()) return emptyList()
        val j = callWeapi(ctx, "/api/search/get", JSONObject()
            .put("s", keyword)
            .put("type", 1002)
            .put("limit", limit)
            .put("offset", 0))
        val arr = j.optJSONObject("result")?.optJSONArray("userprofiles") ?: return emptyList()
        val list = ArrayList<User>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list.add(User(
                id = o.optLong("userId"),
                nickname = o.optString("nickname"),
                avatar = o.optString("avatarUrl"),
                signature = o.optString("signature", "")
            ))
        }
        return list
    }

    fun subscribePlaylist(ctx: Context, id: Long, subscribed: Boolean): JSONObject {
        val action = if (subscribed) "subscribe" else "unsubscribe"
        return callWeapi(ctx, "/api/playlist/$action", JSONObject().put("id", id))
    }

    fun likeSong(ctx: Context, id: Long, like: Boolean): JSONObject {
        return callWeapi(ctx, "/api/radio/like", JSONObject()
            .put("alg", "itembased")
            .put("trackId", id)
            .put("like", like)
            .put("time", "3"))
    }

    fun addSongToPlaylist(ctx: Context, pid: Long, songIds: List<Long>): JSONObject {
        val tracks = songIds.joinToString(",", prefix = "[", postfix = "]")
        return callWeapi(ctx, "/api/playlist/manipulate/tracks", JSONObject()
            .put("op", "add")
            .put("pid", pid)
            .put("trackIds", tracks))
    }

    fun recommendAnime(ctx: Context, count: Int = 20): List<Song> {
        try {
            val j = callWeapi(ctx, "/api/playlist/list", JSONObject()
                .put("cat", "ACG")
                .put("order", "hot")
                .put("limit", 50)
                .put("offset", 0)
                .put("total", true))
            val arr = j.optJSONArray("playlists")
            if (arr != null && arr.length() > 0) {
                val idx = (Math.random() * arr.length()).toInt()
                val id = arr.optJSONObject(idx)?.optLong("id") ?: 0L
                if (id > 0) {
                    val songs = playlistTracks(ctx, id, 50)
                    if (songs.size >= 5) return songs.shuffled().take(count)
                }
            }
        } catch (_: Exception) {}
        return fallbackSearch(ctx)
    }

    fun recommendPool(ctx: Context, target: Int = 200): List<Song> {
        val result = mutableListOf<Song>()
        try {
            val j = callWeapi(ctx, "/api/playlist/list", JSONObject()
                .put("cat", "ACG")
                .put("order", "hot")
                .put("limit", 50)
                .put("offset", 0)
                .put("total", true))
            val arr = j.optJSONArray("playlists")
            if (arr != null && arr.length() > 0) {
                val indices = (0 until arr.length()).shuffled().take(6)
                for (idx in indices) {
                    val id = arr.optJSONObject(idx)?.optLong("id") ?: continue
                    if (id <= 0) continue
                    val songs = try { playlistTracks(ctx, id, 60) } catch (_: Exception) { emptyList() }
                    for (song in songs) {
                        if (result.none { it.id == song.id }) result.add(song)
                        if (result.size >= target) break
                    }
                    if (result.size >= target) break
                }
            }
        } catch (_: Exception) {}
        if (result.size < 10) result.addAll(fallbackSearch(ctx))
        return result.shuffled()
    }

    private fun fallbackSearch(ctx: Context): List<Song> {
        val pool = listOf(
            "初音未来", "孤独摇滚", "鬼灭之刃", "我推的孩子", "进击的巨人",
            "泽野弘之", "四月是你的谎言", "紫罗兰永恒花园", "未闻花名", "你的名字",
            "间谍过家家", "咒术回战", "海贼王", "数码宝贝", "灌篮高手", "东方project"
        )
        val kw = pool[(Math.random() * pool.size).toInt()]
        return try { search(ctx, kw, 20).take(10) } catch (_: Exception) { emptyList() }
    }

    /**
     * 单次音源请求。
     *
     * ★ 关键: 返回值里带上服务器**实际**给的 level / br / size。
     *   level 参数是「上限」而不是「保证」, 例如请求 hires 但该曲只有 exhigh 时,
     *   服务器会返回 exhigh 的地址 —— 我们把它如实记录下来, 就能告诉用户
     *   「你选了 Hi-Res, 但这首歌只有 320k」, 而不是假装设置生效了。
     */
    fun songUrlInfo(ctx: Context, id: Long, level: String): PlayUrlInfo? {
        // 无损档位必须用 flac 编码, 否则会拿到打着 lossless 标签的 AAC
        val encode = if (level == "lossless" || level == "hires") "flac" else "aac"
        val j = callEapi(ctx, "/api/song/enhance/player/url/v1", JSONObject()
            .put("ids", "[$id]")
            .put("level", level)
            .put("encodeType", encode))
        val arr = j.optJSONArray("data") ?: return null
        val d = arr.optJSONObject(0) ?: return null
        val url = d.optString("url", "")
        if (url.isBlank()) return null
        return PlayUrlInfo(
            url = url,
            level = d.optString("level", ""),
            br = d.optInt("br", 0),
            size = d.optLong("size", 0L),
            source = "netease",
            requested = level
        )
    }

    /** 兼容旧调用: 只要 URL 字符串 */
    fun songUrl(ctx: Context, id: Long, level: String): String =
        songUrlInfo(ctx, id, level)?.url ?: ""

    /**
     * 按用户选择的音质解析音源。
     * 先按所选档位请求一次 (服务器会给出不高于该档位的最佳资源),
     * 失败(无版权/接口报错)时逐档降级重试。
     */
    fun resolvePlayUrl(ctx: Context, id: Long): PlayUrlInfo? {
        val order = listOf("hires", "lossless", "exhigh", "higher", "standard")
        val start = order.indexOf(Session.quality).coerceAtLeast(0)
        for (i in start until order.size) {
            try {
                val info = songUrlInfo(ctx, id, order[i])
                if (info != null) {
                    Logger.log(
                        "NeteaseApi",
                        "音源 id=$id 请求=${order[i]} 实际=${info.level} br=${info.br} size=${info.size}"
                    )
                    return info
                }
            } catch (e: Exception) {
                Logger.log("NeteaseApi", "音源 id=$id 档位=${order[i]} 失败: ${e.message}")
            }
        }
        return null
    }

    // ================= 歌词 / 收藏 =================

    fun lyric(ctx: Context, id: Long): JSONObject {
        val url = DOMAIN + "/api/song/lyric?id=$id&lv=-1&kv=-1&tv=-1"
        val resp = Http.get(url, Session.cookieHeader(), mapOf(
            "Referer" to DOMAIN,
            "User-Agent" to UA_WEAPI
        ))
        return parseObj(resp)
    }

    fun likelist(ctx: Context, uid: Long): Set<Long> {
        if (uid <= 0) return emptySet()
        try {
            val j = callEapi(ctx, "/api/song/like/get", JSONObject().put("uid", uid))
            val arr = j.optJSONArray("ids") ?: return emptySet()
            val set = HashSet<Long>()
            for (i in 0 until arr.length()) {
                val id = arr.optLong(i, 0)
                if (id > 0) set.add(id)
            }
            return set
        } catch (_: Exception) {
            return emptySet()
        }
    }

    // ================= VIP 信息 =================

    data class VipInfo(
        val isVip: Boolean,
        val level: String,
        val expireTime: String
    )

    fun vipInfo(ctx: Context, uid: Long): VipInfo {
        try {
            val j = callEapi(ctx, "/api/music-vip-membership/client/vip/info", JSONObject().put("userId", uid))
            if (j.optInt("code", -1) == 200) {
                val d = j.optJSONObject("data") ?: return VipInfo(false, "", "")
                val level = d.optInt("redVipLevel", 0)
                val pkg = d.optJSONObject("musicPackage")
                var expire = pkg?.optLong("expireTime", 0) ?: 0L
                if (expire <= 0) expire = d.optLong("expireTime", d.optLong("redVipExpireTime", 0))
                val annual = d.optInt("redVipAnnualCount", 0)
                return VipInfo(
                    isVip = level > 0,
                    level = if (level > 0) "Lv.$level" else "",
                    expireTime = if (expire > 0) formatTime(expire)
                                 else if (annual > 0) "年费 · 累计 $annual 年" else ""
                )
            }
        } catch (_: Exception) {}
        try {
            val j = callEapi(ctx, "/api/music-vip-membership/front/vip/info", JSONObject().put("userId", uid))
            if (j.optInt("code", -1) == 200) {
                val d = j.optJSONObject("data") ?: return VipInfo(false, "", "")
                val level = d.optString("redVipLevel", "0")
                val lvl = level.toIntOrNull() ?: 0
                val annual = d.optInt("redVipAnnualCount", 0)
                return VipInfo(
                    isVip = lvl > 0,
                    level = if (lvl > 0) "Lv.$lvl" else "",
                    expireTime = if (annual > 0) "年费 · 累计 $annual 年" else ""
                )
            }
        } catch (_: Exception) {}
        return VipInfo(false, "", "")
    }

    // ================= 排行榜 / 听歌排行 =================

    /**
     * 网易云官方排行榜 (飙升/新歌/热歌/原创…)。
     * weapi /api/toplist, 返回的 list 元素结构与歌单一致, 可直接进 PlaylistActivity。
     */
    fun topLists(ctx: Context, limit: Int = 60): List<Playlist> {
        val j = callWeapi(ctx, "/api/toplist", JSONObject()
            .put("limit", limit)
            .put("offset", 0))
        val arr = j.optJSONArray("list") ?: return emptyList()
        Logger.log("API", "topLists: code=${j.optInt("code")}, 榜单=${arr.length()}个")
        val list = ArrayList<Playlist>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optLong("id")
            if (id <= 0) continue
            list.add(Playlist(
                id = id,
                name = o.optString("name"),
                cover = o.optString("coverImgUrl"),
                trackCount = o.optInt("trackCount"),
                playCount = o.optLong("playCount")
            ))
        }
        return list
    }

    /**
     * 读取「近一周听歌排行」(网易云 /api/v1/play/record, type=1)。
     * 登录后用于「我的」页展示: 近一周听歌次数 / 听过几首 / 最爱曲目。
     * ★ 与上报 (scrobble) 形成闭环: 播完一首歌 → weblog 上报 → 这里次数上涨。
     */
    fun weekRecord(ctx: Context): PlayRecordSummary {
        val uid = Session.uid
        if (uid <= 0) return PlayRecordSummary(0, 0, emptyList())
        return try {
            val j = callWeapi(ctx, "/api/v1/play/record", JSONObject()
                .put("uid", uid).put("type", 1))
            if (j.optInt("code", -1) != 200) return PlayRecordSummary(0, 0, emptyList())
            val arr = j.optJSONArray("allData") ?: j.optJSONArray("weekData")
                ?: return PlayRecordSummary(0, 0, emptyList())
            var totalPlays = 0
            val top = ArrayList<Song>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                totalPlays += o.optInt("playCount", 0)
                if (top.size < 5) {
                    o.optJSONObject("song")?.let { top.add(parseSong(it)) }
                }
            }
            PlayRecordSummary(totalPlays, arr.length(), top)
        } catch (e: Exception) {
            Logger.log("API", "weekRecord 异常: ${e.message}")
            PlayRecordSummary(0, 0, emptyList())
        }
    }

    // ================= 播放记录上报 (听歌时长同步) =================

    /**
     * eapi 通道 (os=osx 网页播放器身份): 听歌记录上报专用。
     * 与 [callEapi] 唯一区别是 cookie 里的 os 强制为 osx, 让服务端按网页口径统计。
     */
    private fun callEapiWeb(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        val header = buildEapiHeader(ctx)
        header.put("os", "osx") // ★ 网页播放器身份
        payload.put("header", header)
        val params = NeteaseCrypto.eapi(uri, payload.toString())
        val parts = ArrayList<String>()
        val it = header.keys()
        while (it.hasNext()) {
            val k = it.next()
            parts.add(URLEncoder.encode(k, "UTF-8") + "=" + URLEncoder.encode(header.getString(k), "UTF-8"))
        }
        val resp = Http.postForm(
            API_DOMAIN + "/eapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params),
            parts.joinToString("; "),
            mapOf("User-Agent" to uaApi())
        )
        return parseObj(resp)
    }

    /**
     * 播放开始上报 (startplay): 歌曲进入网易云「最近播放」。
     * ★ 必须与 [scrobblePlay] 成对上报, 官方网页播放器就是两条日志。
     */
    fun scrobbleStart(ctx: Context, songId: Long, sourceId: Long): Boolean {
        if (!Session.isLoggedIn()) {
            Logger.log("Scrobble", "未登录, 跳过 startplay 上报")
            return false
        }
        if (!Session.syncPlayRecord) return false
        if (songId <= 0) return false
        val src = if (sourceId > 0) sourceId else 0L
        val logs = JSONArray().put(
            JSONObject().put("action", "startplay").put("json", JSONObject()
                .put("id", songId)
                .put("type", "song")
                .put("mainsite", "1")
                .put("mainsiteWeb", "1")
                .put("content", "id=$src"))
        ).toString()
        return postWeblog(ctx, logs, songId, "startplay")
    }

    /**
     * 播放结算上报 (play): 涨「听歌排行」次数 + 累计「听歌时长」。
     *
     * ★ 与官方网页播放器完全对齐 (2026 最新版 NeteaseCloudMusicApi scrobble):
     *   - end=playend / mainsite=1 / mainsiteWeb=1 / content=id=<sourceId>
     *   - cookie 必须 os=osx (网页口径), 否则服务端不计入听歌排行/时长
     *   - eapi 通道优先, weapi 兜底
     */
    fun scrobblePlay(ctx: Context, songId: Long, sourceId: Long, timeSec: Int): Boolean {
        if (!Session.isLoggedIn()) {
            Logger.log("Scrobble", "未登录, 跳过上报")
            return false
        }
        if (!Session.syncPlayRecord) {
            Logger.log("Scrobble", "设置中已关闭听歌记录同步, 跳过")
            return false
        }
        if (songId <= 0 || timeSec <= 0) return false
        val src = if (sourceId > 0) sourceId else 0L
        val logs = JSONArray().put(
            JSONObject().put("action", "play").put("json", JSONObject()
                .put("download", 0)
                .put("end", "playend")
                .put("id", songId)
                .put("sourceId", src)
                .put("time", timeSec)
                .put("type", "song")
                .put("wifi", 0)
                .put("source", "list")
                .put("mainsite", "1")
                .put("mainsiteWeb", "1")
                .put("content", "id=$src"))
        ).toString()
        return postWeblog(ctx, logs, songId, "play")
    }

    /** weblog 双通道发送 (eapi 优先, weapi 兜底), 均带 os=osx 网页身份 */
    private fun postWeblog(ctx: Context, logs: String, songId: Long, tag: String): Boolean {
        var code = -1
        try {
            code = callEapiWeb(ctx, "/api/feedback/weblog", JSONObject().put("logs", logs))
                .optInt("code", -1)
            Logger.log("Scrobble", "weblog[$tag](eapi) code=$code songId=$songId")
            if (code == 200) {
                Session.lastSyncAuthFail = false
                return true
            }
            if (code == 301) {
                Logger.log("Scrobble", "weblog[$tag] 返回 301: 登录态失效")
                Session.lastSyncAuthFail = true
                return false
            }
        } catch (e: Exception) {
            Logger.log("Scrobble", "weblog[$tag](eapi) 异常: ${e.message}")
        }
        try {
            val payload = JSONObject().put("logs", logs)
            Session.get("__csrf")?.takeIf { it.isNotEmpty() }?.let { payload.put("csrf_token", it) }
            val (params, encSecKey) = NeteaseCrypto.weapi(payload.toString())
            val resp = Http.postForm(
                DOMAIN + "/weapi/feedback/weblog",
                mapOf("params" to params, "encSecKey" to encSecKey),
                Session.cookieHeaderWeb(), // ★ os=osx 网页身份
                mapOf("Referer" to DOMAIN, "User-Agent" to UA_WEAPI)
            )
            code = parseObj(resp).optInt("code", -1)
            Logger.log("Scrobble", "weblog[$tag](weapi) code=$code songId=$songId")
            if (code == 200) {
                Session.lastSyncAuthFail = false
                return true
            }
            if (code == 301) Session.lastSyncAuthFail = true
        } catch (e: Exception) {
            Logger.log("Scrobble", "weblog[$tag](weapi) 异常: ${e.message}")
        }
        return false
    }

    // ================= NCBL 客户端日志上报 (听歌时长: PLV 播放记录 / PLD 时长) =================

    private const val NCBL_DOMAIN = "https://clientlog3.music.163.com"
    private const val NCBL_APP_VERSION = "3.1.35"      // 桌面客户端版本号
    private const val NCBL_APP_VERSION_CODE = "205293"
    private const val NCBL_OSVER = "Microsoft-Windows-10-Professional-build-19045-64bit"

    /** cookie 摘要 (meta): 随 payload 一起加密上传 */
    private fun ncblMeta(): JSONObject {
        val meta = JSONObject()
        meta.put("JSESSIONID-WYYY", "")
        meta.put("MUSIC_U", Session.cookieValue("MUSIC_U"))
        meta.put("NMTID", Session.cookieValue("NMTID"))
        meta.put("WEVNSM", Session.cookieValue("WEVNSM").ifEmpty { "1.0.0" })
        meta.put("WNMCID", Session.cookieValue("WNMCID"))
        meta.put("__csrf", Session.cookieValue("__csrf"))
        meta.put("_iuqxldmzr_", "33")
        meta.put("_ntes_nnid", ",")
        meta.put("_ntes_nuid", Session.cookieValue("_ntes_nuid"))
        meta.put("appver", "$NCBL_APP_VERSION.$NCBL_APP_VERSION_CODE")
        meta.put("channel", Session.cookieValue("channel").ifEmpty { "netease" })
        meta.put("clientSign", "")
        meta.put("deviceId", Session.cookieValue("deviceId"))
        meta.put("mode", "")
        meta.put("ntes_kaola_ad", "1")
        meta.put("os", "pc")
        meta.put("osver", NCBL_OSVER)
        return meta
    }

    /** 上传请求头 cookie (桌面客户端口径) */
    private fun ncblCookie(): String = arrayOf(
        "JSESSIONID-WYYY=",
        "MUSIC_U=${Session.cookieValue("MUSIC_U")}",
        "NMTID=${Session.cookieValue("NMTID")}",
        "WEVNSM=${Session.cookieValue("WEVNSM").ifEmpty { "1.0.0" }}",
        "WNMCID=${Session.cookieValue("WNMCID")}",
        "__csrf=${Session.cookieValue("__csrf")}",
        "__remember_me=true",
        "_iuqxldmzr_=33",
        "_ntes_nnid=,",
        "_ntes_nuid=${Session.cookieValue("_ntes_nuid")}",
        "appver=$NCBL_APP_VERSION.$NCBL_APP_VERSION_CODE",
        "channel=${Session.cookieValue("channel").ifEmpty { "netease" }}",
        "clientSign=",
        "deviceId=${Session.cookieValue("deviceId")}",
        "mode=",
        "ntes_kaola_ad=1",
        "os=pc",
        "osver=$NCBL_OSVER"
    ).joinToString("; ")

    private fun srcId(sourceId: Long, songId: Long): String =
        if (sourceId > 0) sourceId.toString() else songId.toString()

    /** 组装 multipart 并上传一条 NCBL 记录 */
    private fun ncblUpload(action: String, recordJson: JSONObject): Boolean {
        if (!Session.isLoggedIn()) {
            Logger.log("Ncbl", "未登录, 跳过 $action 上报")
            return false
        }
        return try {
            val ts = System.currentTimeMillis() / 1000
            val bodyStr = "$ts\u0001$action\u0001" + recordJson.toString()
            val payload = Ncbl.encrypt(
                ncblMeta().toString().toByteArray(Charsets.UTF_8),
                bodyStr.toByteArray(Charsets.UTF_8)
            )
            val boundary = Ncbl.randomHex32()
            val fileName = "op_${10000 + (Math.random() * 90000).toInt()}_0_" +
                (1 + (Math.random() * 4294967295.0).toLong())
            val CRLF = "\r\n"
            val head = (
                "--$boundary$CRLF" +
                    "Content-Disposition: form-data; name=\"file\"; filename=\"$fileName\"$CRLF" +
                    "Content-Type: multipart/form-data$CRLF" +
                    "$CRLF$CRLF"
                ).toByteArray(Charsets.UTF_8)
            val foot = ("$CRLF--$boundary--$CRLF").toByteArray(Charsets.UTF_8)
            val multipart = head + payload + foot
            val resp = Http.postRaw(
                "$NCBL_DOMAIN/api/clientlog/encrypt/upload?multiupload=true",
                multipart,
                "multipart/form-data; boundary=$boundary",
                ncblCookie(),
                mapOf(
                    "Referer" to "https://music.163.com/di",
                    "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Safari/537.36 Chrome/91.0.4472.164 " +
                        "NeteaseMusicDesktop/$NCBL_APP_VERSION"
                )
            )
            val j = JSONObject(resp.body)
            val successFiles = j.optJSONObject("data")?.optJSONArray("successfiles")
            val ok = j.optInt("code", -1) == 200 &&
                (successFiles?.toString()?.contains(fileName) == true)
            Logger.log("Ncbl", "$action 上传: code=${j.optInt("code")} ok=$ok resp=${resp.body.take(150)}")
            ok
        } catch (e: Exception) {
            Logger.log("Ncbl", "$action 上传异常: ${e.message}")
            false
        }
    }

    /**
     * PLV 上报: 播放开始 (进「最近播放」+ 播放记录)。
     * 与 [ncblUploadPld] 成对, 官方桌面客户端同款 NCBL 通道。
     */
    fun ncblUploadPlv(ctx: Context, songId: Long, sourceId: Long, durationSec: Long): Boolean {
        if (songId <= 0) return false
        val now = System.currentTimeMillis()
        val addRefer = "[F:63][${now}#933#$NCBL_APP_VERSION#$NCBL_APP_VERSION_CODE#c9156c3]" +
            "[e][2][23][cell_pc_songlist_song:2|page_pc_songlist_songflow|page_mine_like_music]" +
            "[$songId:song:x:x|:::|${srcId(sourceId, songId)}:list::]"
        val multiRefers = JSONArray()
            .put("[F:26][s][18][_ai]")
            .put("[F:26][s][12][_ai]")
            .put("[F:63][${now}#933#$NCBL_APP_VERSION#$NCBL_APP_VERSION_CODE#c9156c3]" +
                "[e][2][8][cell_pc_main_tab_entrance:6|page_pc_main_tab][我喜欢的音乐:spm::|:::]")
            .put("[F:26][s][5][_ai]")
            .put("[F:26][s][0][_ai]")
        val data = JSONObject()
        data.put("mode", "circulation")
        data.put("download", 0)
        data.put("alg", "")
        data.put("status", "front")
        data.put("id", songId.toString())
        data.put("bitrate", 320)
        data.put("type", "song")
        data.put("is_listentogether", 0)
        data.put("source", "list")
        data.put("is_heart", 0)
        data.put("resource_ratio", "")
        data.put("resource_time", durationSec.coerceAtLeast(1))
        data.put("musiceffect_id", "")
        data.put("app_mode", 2)
        data.put("bitrate_level", "exhigh")
        data.put("_addrefer", addRefer)
        data.put("_multirefers", multiRefers)
        data.put("vipType", "")
        data.put("fee", 1)
        data.put("file", 4)
        data.put("rightSource", 0)
        data.put("sourceId", srcId(sourceId, songId))
        data.put("sourcetype", "track")
        data.put("libra_abt", "")
        data.put("channel", Session.cookieValue("channel").ifEmpty { "netease" })
        data.put("curStartChannel", "")
        return ncblUpload("_plv", data)
    }

    /**
     * PLD 上报: 播放时长结算 (涨「听歌时长」)。
     * ★ 这是网易云客户端「听歌时长」的正式上报通道 (NCBL 加密日志)。
     */
    fun ncblUploadPld(ctx: Context, songId: Long, sourceId: Long, timeSec: Int, durationSec: Long): Boolean {
        if (songId <= 0 || timeSec <= 0) return false
        val now = System.currentTimeMillis()
        val addRefer = "[F:63][${now}#616#$NCBL_APP_VERSION#$NCBL_APP_VERSION_CODE#c9156c3]" +
            "[e][2][92][btn_pc_cover_play|cell_pc_songlist_song:6|page_pc_songlist_songflow|page_mine_like_music]" +
            "[:::|$songId:song:x:x|:::|${srcId(sourceId, songId)}:list::]"
        val multiRefers = JSONArray()
            .put("[F:26][s][87][_ai]")
            .put("[F:26][s][81][_ai]")
            .put("[F:26][s][75][_ai]")
            .put("[F:26][s][69][_ai]")
            .put("[F:26][s][63][_ai]")
        val data = JSONObject()
        data.put("mode", "circulation")
        data.put("download", 0)
        data.put("alg", "")
        data.put("status", "front")
        data.put("id", songId.toString())
        data.put("time", timeSec)
        data.put("type", "song")
        data.put("is_listentogether", 0)
        data.put("source", "list")
        data.put("is_heart", 0)
        data.put("realtime", timeSec)
        data.put("resource_ratio", "")
        data.put("resource_time", durationSec.coerceAtLeast(1))
        data.put("musiceffect_id", "1001")
        data.put("app_mode", 1)
        data.put("lyriceffect", "default")
        data.put("displayMode", "classic")
        data.put("bitrate", 320)
        data.put("bitrate_level", "exhigh")
        data.put("_addrefer", addRefer)
        data.put("_multirefers", multiRefers)
        data.put("vipType", "")
        data.put("fee", 8)
        data.put("file", 4)
        data.put("rightSource", 0)
        data.put("sourceId", srcId(sourceId, songId))
        data.put("sourcetype", "track")
        data.put("end", "interrupt")
        data.put("libra_abt", "")
        data.put("channel", Session.cookieValue("channel").ifEmpty { "netease" })
        data.put("curStartChannel", "")
        return ncblUpload("_pld", data)
    }

    /**
     * 读取「听歌排行」中某首歌的累计播放次数。
     * 用于上报后自检: 次数上涨 = 网易云确实收到了这次播放 (听歌记录/听歌时长随之更新)。
     * @return 次数, -1 表示查询失败
     */
    fun playCount(ctx: Context, uid: Long, songId: Long): Int {
        if (uid <= 0 || songId <= 0) return -1
        return try {
            val j = callWeapi(ctx, "/api/v1/play/record", JSONObject()
                .put("uid", uid).put("type", 0))
            if (j.optInt("code", -1) != 200) return -1
            val arr = j.optJSONArray("allData") ?: return -1
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optJSONObject("song")?.optLong("id", 0) ?: o.optLong("songId", 0)
                if (id == songId) return o.optInt("playCount", 0)
            }
            0
        } catch (e: Exception) {
            Logger.log("Scrobble", "playCount 查询异常: ${e.message}")
            -1
        }
    }

    private fun formatTime(ms: Long): String {
        return try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.CHINA)
            sdf.format(java.util.Date(ms))
        } catch (_: Exception) {
            ms.toString()
        }
    }
}
