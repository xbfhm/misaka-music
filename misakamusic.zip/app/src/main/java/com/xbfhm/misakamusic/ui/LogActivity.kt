package com.xbfhm.misakamusic.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.databinding.ActivityLogBinding
import com.xbfhm.misakamusic.util.Logger

/**
 * 日志查看页: 用于定位「播放几秒后中断/返回主界面」等问题。
 * 展示最近 500 行日志, 支持一键复制。
 */
class LogActivity : BaseActivity() {

    private lateinit var binding: ActivityLogBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnCopy.setOnClickListener { copyLogs() }
        binding.btnRefresh.setOnClickListener { refresh() }
        refresh()
    }

    private fun refresh() {
        val logs = Logger.recentLines()
        binding.tvLog.text = logs.joinToString("\n").ifEmpty { "(暂无日志)" }
        binding.tvCount.text = "共 ${logs.size} 行"
    }

    private fun copyLogs() {
        val text = Logger.recent()
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("misaka_log", text))
        Toast.makeText(this, "已复制 ${Logger.recentLines().size} 行日志", Toast.LENGTH_SHORT).show()
    }
}
