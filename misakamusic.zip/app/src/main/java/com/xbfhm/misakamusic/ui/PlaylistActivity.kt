package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.data.LocalPlaylistStore
import com.xbfhm.misakamusic.databinding.ActivityPlaylistBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 歌单详情页。同时支持:
 *  · 网易云歌单 (id > 0)
 *  · 本地歌单 (id < 0, 未登录也能用; 长按歌曲可从歌单移除)
 */
class PlaylistActivity : BaseActivity() {

    companion object {
        const val EXTRA_ID = "playlist_id"
        const val EXTRA_NAME = "playlist_name"
        const val EXTRA_LOCAL = "playlist_local"
    }

    private lateinit var binding: ActivityPlaylistBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var adapter: SongAdapter
    private var playlistId = 0L
    private var playlistName = ""
    private var isLocal = false
    private var songs: List<Song> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        playlistId = intent.getLongExtra(EXTRA_ID, 0)
        playlistName = intent.getStringExtra(EXTRA_NAME) ?: ""
        isLocal = intent.getBooleanExtra(EXTRA_LOCAL, false) || playlistId < 0
        binding.tvTitle.text = playlistName

        adapter = SongAdapter { index -> playSong(index) }
        // 本地歌单: 长按歌曲可移出歌单
        adapter.onLongClick = { index -> onSongLongPress(index) }
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnPlayAll.setOnClickListener {
            if (songs.isNotEmpty()) playFromQueue(0, PlayerEngine.mode == PlayMode.SHUFFLE)
            else toast(getString(R.string.playlist_empty))
        }

        loadTracks()
    }

    override fun onResume() {
        super.onResume()
        if (isLocal) loadTracks()
        updateHighlight()
    }

    private fun loadTracks() {
        if (isLocal) {
            val list = LocalPlaylistStore.get(playlistId)?.songs ?: emptyList()
            songs = list
            adapter.submit(list)
            binding.tvTitle.text = "$playlistName（${list.size} 首）"
            emptyCheck()
            updateHighlight()
            return
        }
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                NeteaseApi.playlistTracks(this@PlaylistActivity, playlistId)
            }
            songs = list
            adapter.submit(list)
            binding.tvTitle.text = "$playlistName（${list.size} 首）"
            emptyCheck()
            updateHighlight()
        }
    }

    private fun emptyCheck() {
        if (songs.isEmpty()) toast(getString(R.string.playlist_empty))
    }

    /** 本地歌单里长按一首歌 -> 移除 */
    fun onSongLongPress(index: Int) {
        if (!isLocal || index !in songs.indices) return
        val song = songs[index]
        MaterialAlertDialogBuilder(this)
            .setTitle(song.name)
            .setItems(arrayOf(getString(R.string.pl_remove_song))) { _: DialogInterface?, _: Int ->
                LocalPlaylistStore.removeSong(playlistId, song.id)
                loadTracks()
                toast(getString(R.string.pl_removed))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun playSong(index: Int) {
        playFromQueue(index)
    }

    private fun playFromQueue(startIndex: Int, randomStart: Boolean = false) {
        PlayerEngine.setPlaylist(playlistId, songs, startIndex, randomStart)
        adapter.currentIndex = PlayerEngine.currentIndex
        adapter.notifyDataSetChanged()
        openPageUp(Intent(this, PlayerActivity::class.java), singleTop = true)
    }

    private fun updateHighlight() {
        if (PlayerEngine.queueTag == playlistId) {
            adapter.currentIndex = PlayerEngine.currentIndex
        } else {
            adapter.currentIndex = -1
        }
        adapter.notifyDataSetChanged()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
