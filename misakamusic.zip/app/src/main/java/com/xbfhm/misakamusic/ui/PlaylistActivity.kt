package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityPlaylistBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaylistActivity : BaseActivity() {

    companion object {
        const val EXTRA_ID = "playlist_id"
        const val EXTRA_NAME = "playlist_name"
    }

    private lateinit var binding: ActivityPlaylistBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var adapter: SongAdapter
    private var playlistId = 0L
    private var playlistName = ""
    private var songs: List<Song> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playlistId = intent.getLongExtra(EXTRA_ID, 0)
        playlistName = intent.getStringExtra(EXTRA_NAME) ?: ""
        binding.tvTitle.text = playlistName

        adapter = SongAdapter { index -> playSong(index) }
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnPlayAll.setOnClickListener {
            if (songs.isNotEmpty()) playFromQueue(0, PlayerEngine.mode == PlayMode.SHUFFLE)
            else toast("歌单为空")
        }

        loadTracks()
    }

    override fun onResume() {
        super.onResume()
        updateHighlight()
    }

    private fun loadTracks() {
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                NeteaseApi.playlistTracks(this@PlaylistActivity, playlistId)
            }
            songs = list
            adapter.submit(list)
            binding.tvTitle.text = "${playlistName}（${list.size} 首）"
            if (list.isEmpty()) toast("歌单为空或获取失败")
            updateHighlight()
        }
    }

    private fun playSong(index: Int) {
        playFromQueue(index)
    }

    private fun playFromQueue(startIndex: Int, randomStart: Boolean = false) {
        PlayerEngine.setPlaylist(playlistId, songs, startIndex, randomStart)
        adapter.currentIndex = PlayerEngine.currentIndex
        adapter.notifyDataSetChanged()
        openPageUp(Intent(this, PlayerActivity::class.java))
    }

    private fun updateHighlight() {
        if (PlayerEngine.queueTag == playlistId) {
            adapter.currentIndex = PlayerEngine.currentIndex
        } else {
            adapter.currentIndex = -1
        }
        adapter.notifyDataSetChanged()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
