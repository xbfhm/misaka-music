package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.data.ListenStatsStore
import com.xbfhm.misakamusic.databinding.FragmentMineBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.theme.ThemeManager
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 我的页: 账号状态 + 听歌统计 + 入口。
 *
 * 听歌统计三栏:
 *  - 今日听歌 (本地按真实播放段落累计, 与上报网易云同源)
 *  - 累计听歌 (本地总时长)
 *  - 近一周听歌 (网易云 /api/v1/play/record 周排行次数, 登录后可见)
 * 下方显示「最近同步」时间 (weblog scrobble 成功上报即刷新)。
 */
class MineFragment : Fragment() {

    private var _binding: FragmentMineBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMineBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ThemeManager.applyToTree(view)

        binding.btnLoginState.setOnClickListener {
            if (Session.isLoggedIn()) confirmLogout() else openLogin()
        }
        binding.rowHistory.setOnClickListener {
            startActivity(Intent(requireContext(), HistoryActivity::class.java))
            requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        binding.rowSettings.setOnClickListener {
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
            requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        binding.rowAbout.setOnClickListener {
            startActivity(Intent(requireContext(), AboutActivity::class.java))
            requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val logged = Session.isLoggedIn()
        // 用户卡片
        if (logged) {
            binding.tvMineName.text = Session.nickname.ifEmpty { "网易云用户" }
            binding.tvMineUid.text = "UID ${Session.uid}"
            binding.btnLoginState.setText(R.string.mine_logout)
            Glide.with(this)
                .load(Session.avatar)
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .into(binding.imgAvatar)
        } else {
            binding.tvMineName.setText(R.string.mine_not_login)
            binding.tvMineUid.setText(R.string.mine_not_login_hint)
            binding.btnLoginState.setText(R.string.mine_login)
            binding.imgAvatar.setImageResource(R.drawable.ic_account)
        }

        // 本地听歌时长 (实时)
        binding.tvTodayTime.text = ListenStatsStore.format(ListenStatsStore.todaySec())
        binding.tvTotalTime.text = ListenStatsStore.format(ListenStatsStore.totalSec())

        // 最近同步时间
        val last = Session.lastSyncTime
        binding.tvLastSync.text = when {
            Session.lastSyncAuthFail -> getString(R.string.mine_sync_auth_fail)
            last <= 0 -> getString(R.string.mine_never_sync)
            else -> getString(R.string.mine_last_sync, relativeTime(last))
        }

        // 网易云近一周听歌排行 (登录后异步拉取)
        if (logged) {
            binding.tvWeekCount.text = "…"
            val ctx = requireContext()
            scope.launch {
                val summary = try {
                    withContext(Dispatchers.IO) { NeteaseApi.weekRecord(ctx) }
                } catch (e: Exception) {
                    Logger.log("Mine", "周排行加载失败: ${e.message}")
                    null
                }
                if (summary != null && _binding != null) {
                    binding.tvWeekCount.text = if (summary.totalPlays > 0)
                        "${summary.totalPlays} 次" else "0 次"
                } else if (_binding != null) {
                    binding.tvWeekCount.text = "—"
                }
            }
        } else {
            binding.tvWeekCount.text = "—"
        }
    }

    private fun openLogin() {
        startActivity(Intent(requireContext(), LoginActivity::class.java))
        requireActivity().overridePendingTransition(R.anim.slide_in_bottom, R.anim.fade_out)
    }

    private fun confirmLogout() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.mine_logout_confirm_title)
            .setMessage(R.string.mine_logout_confirm_msg)
            .setPositiveButton(R.string.logout) { _, _ ->
                Session.clearLiked()
                Session.clearLogin()
                refresh()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun relativeTime(ts: Long): String {
        val diff = System.currentTimeMillis() - ts
        val min = diff / 60000
        return when {
            min < 1 -> "刚刚"
            min < 60 -> "${min} 分钟前"
            min < 60 * 24 -> "${min / 60} 小时前"
            else -> "${min / 60 / 24} 天前"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
