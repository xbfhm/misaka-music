package com.xbfhm.misakamusic.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * 本地听歌时长统计 (与网易云同步的「听歌时长」功能)。
 *
 * 每次播放段落结算 (暂停/切歌/播完) 都会累加真实聆听秒数;
 * 同一时刻网易云上报 (weblog scrobble) 也在进行, 两边保持一致。
 * 数据按天分桶, 保留最近 120 天。
 */
object ListenStatsStore {

    private const val PREFS = "listen_stats"
    private const val KEY_TOTAL = "total_sec"
    private const val KEY_DAYS = "days"

    private var prefs: SharedPreferences? = null
    private var initialized = false

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        initialized = true
    }

    /** 累加 [sec] 秒 (由 PlayerEngine 在每段播放结算时调用) */
    @Synchronized
    fun add(sec: Int) {
        val p = prefs ?: return
        if (sec <= 0) return
        val total = p.getLong(KEY_TOTAL, 0L) + sec
        val days = loadDays().apply {
            val today = todayKey()
            put(today, optLong(today, 0L) + sec)
        }
        prune(days)
        p.edit()
            .putLong(KEY_TOTAL, total)
            .putString(KEY_DAYS, days.toString())
            .apply()
    }

    /** 今日听歌秒数 */
    fun todaySec(): Long {
        val p = prefs ?: return 0
        return loadDays().optLong(todayKey(), 0L)
    }

    /** 累计听歌秒数 */
    fun totalSec(): Long = prefs?.getLong(KEY_TOTAL, 0L) ?: 0L

    /** 累计听歌的天数 (按天有记录) */
    fun daysCount(): Int = loadDays().length()

    private fun loadDays(): JSONObject {
        val p = prefs ?: return JSONObject()
        val raw = p.getString(KEY_DAYS, null) ?: return JSONObject()
        return try {
            JSONObject(raw)
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun prune(days: JSONObject) {
        val keys = ArrayList<String>()
        val it = days.keys()
        while (it.hasNext()) keys.add(it.next())
        keys.sorted().dropLast(120).forEach { days.remove(it) }
    }

    private fun todayKey(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.CHINA)
            .format(java.util.Date())

    /** 秒 → "X小时Y分" / "X分Y秒" / "X秒" */
    fun format(sec: Long): String {
        if (sec < 60) return "${sec}秒"
        val m = sec / 60
        val s = sec % 60
        return if (m < 60) "${m}分${if (s > 0) "${s}秒" else ""}"
        else {
            val h = m / 60
            "${h}小时${m % 60}分"
        }
    }
}
