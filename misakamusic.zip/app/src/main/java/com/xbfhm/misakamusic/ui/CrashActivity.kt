package com.xbfhm.misakamusic.ui

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

/**
 * 崩溃详情页 (用于排查, 无需电脑即可截图反馈)
 *
 * 刻意不使用任何自定义主题与布局资源:
 *  - 主题用系统 @android:style/Theme.DeviceDefault (见 AndroidManifest)
 *  - UI 全部用代码构建
 * 这样即使 App 自定义主题或资源存在问题, 本页依然能正常显示。
 */
class CrashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val stack = intent?.getStringExtra(EXTRA_STACK).orEmpty().ifEmpty { "(无堆栈信息)" }

        val textView = TextView(this).apply {
            text = "MisakaMusic 出错了\n请把本页截图发给开发者\n\n$stack"
            setTextColor(Color.rgb(0xEE, 0xEE, 0xEE))
            textSize = 11f
            setPadding(32, 48, 32, 48)
            setTextIsSelectable(true)
        }
        val scrollView = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(0x1A, 0x1A, 0x1A))
            addView(textView)
        }
        setContentView(scrollView)
    }

    companion object {
        const val EXTRA_STACK = "stack"
    }
}
