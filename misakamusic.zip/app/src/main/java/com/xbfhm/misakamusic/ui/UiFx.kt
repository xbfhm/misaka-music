package com.xbfhm.misakamusic.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.app.ActivityOptionsCompat

/**
 * 统一的交互动效工具集。
 *
 * 1. [attachPressFeedback] 列表项点击涟漪 + 按压缩放反馈
 * 2. [slideInBottom] / [slideOutBottom] 迷你播放条滑入滑出
 * 3. [startWithSharedCover] 封面共享元素过渡 (列表 → 播放页)
 * 4. [pulseSkeleton] 骨架屏呼吸动画
 */
object UiFx {

    /**
     * 给列表项绑定按压反馈:
     *  - 按下时轻微缩小 (0.97)，抬起/取消时回弹
     *  - 涟漪由背景的 ?attr/selectableItemBackground 提供，此处只做缩放
     */
    fun attachPressFeedback(view: View, scale: Float = 0.97f) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(scale).scaleY(scale)
                        .setDuration(90)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f)
                        .setDuration(140)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                }
            }
            false // 不消费事件，保证 onClick / 涟漪正常工作
        }
    }

    /** 迷你播放条滑入 (从下方) */
    fun slideInBottom(view: View) {
        if (view.visibility == View.VISIBLE && view.translationY == 0f) return
        view.visibility = View.VISIBLE
        view.translationY = view.height.coerceAtLeast(120).toFloat()
        view.alpha = 0f
        view.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(260)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    /** 迷你播放条滑出 (向下) */
    fun slideOutBottom(view: View, endAction: (() -> Unit)? = null) {
        if (view.visibility != View.VISIBLE) return
        view.animate()
            .translationY(view.height.coerceAtLeast(120).toFloat())
            .alpha(0f)
            .setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                view.visibility = View.GONE
                view.translationY = 0f
                view.alpha = 1f
                endAction?.invoke()
            }
            .start()
    }

    /**
     * 携带封面共享元素启动 Activity。
     * [sharedView] 是列表里的封面 ImageView，其 transitionName 需与目标页封面一致。
     * Android 5.0+ 生效，低版本自动退化为普通跳转。
     */
    fun startWithSharedCover(
        activity: Activity,
        intent: Intent,
        sharedView: View,
        transitionName: String,
        enterAnim: Int,
        exitAnim: Int
    ) {
        sharedView.transitionName = transitionName
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val opts = ActivityOptionsCompat.makeSceneTransitionAnimation(
                activity, sharedView, transitionName
            )
            activity.startActivity(intent, opts.toBundle())
        } else {
            activity.startActivity(intent)
        }
        activity.overridePendingTransition(enterAnim, exitAnim)
    }

    /** 骨架屏呼吸动画: 透明度在 0.35~0.85 之间循环 */
    fun pulseSkeleton(view: View) {
        val anim = ObjectAnimator.ofFloat(view, View.ALPHA, 0.35f, 0.85f).apply {
            duration = 700
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator()
        }
        view.tag = anim
        anim.start()
    }

    /** 停止骨架屏动画 */
    fun stopPulse(view: View) {
        (view.tag as? ObjectAnimator)?.cancel()
        view.tag = null
        view.alpha = 1f
    }

    /** 淡入 (用于底部导航切换内容) */
    fun fadeIn(view: View, duration: Long = 200) {
        view.alpha = 0f
        view.animate().alpha(1f).setDuration(duration).start()
    }
}
