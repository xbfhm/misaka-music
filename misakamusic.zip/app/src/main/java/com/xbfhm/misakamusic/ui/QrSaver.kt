package com.xbfhm.misakamusic.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.xbfhm.misakamusic.util.Logger
import java.io.File
import java.io.FileOutputStream

/**
 * 把二维码保存到相册。
 *
 * 为什么需要它: 用户手里只有一部手机 —— 二维码显示在同一块屏幕上时无法用相机互扫,
 * 但网易云音乐 App 的扫一扫支持「从相册选择图片」, 所以先截图/保存再识别是最实用的路径。
 */
object QrSaver {

    /** @return 保存成功返回展示给用户的路径, 失败返回 null */
    fun saveToGallery(ctx: Context, bmp: Bitmap, name: String = "misaka_qr_${System.currentTimeMillis()}.png"): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MisakaMusic")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = ctx.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                resolver.openOutputStream(uri)?.use { out ->
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                Logger.log("Login", "二维码已保存到相册(MediaStore): $name")
                "Pictures/MisakaMusic/$name"
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "MisakaMusic"
                )
                if (!dir.exists()) dir.mkdirs()
                val f = File(dir, name)
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf("image/png"), null)
                Logger.log("Login", "二维码已保存到相册: ${f.absolutePath}")
                f.absolutePath
            }
        } catch (e: Exception) {
            Logger.log("Login", "保存二维码失败: ${e.message}")
            null
        }
    }
}
