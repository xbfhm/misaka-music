package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.R

/**
 * 基础 Activity: Namida 风格沉浸式
 *  - 深色状态栏/导航栏, 白色系统图标
 *  - 前进: 右侧滑入
 *  - 返回: 左侧滑入
 *  - 播放页: 底部滑入
 */
open class BaseActivity : AppCompatActivity() {

    protected var backAnimIn: Int = R.anim.slide_in_left
    protected var backAnimOut: Int = R.anim.slide_out_right

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 深色状态栏/导航栏 + 白色系统图标
        window.statusBarColor = android.graphics.Color.parseColor("#1A1A1A")
        window.navigationBarColor = android.graphics.Color.parseColor("#000000")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility and android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        }
    }

    protected fun openPage(intent: Intent) {
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    protected fun openPageUp(intent: Intent) {
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_bottom, R.anim.slide_out_bottom)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(backAnimIn, backAnimOut)
    }
}
