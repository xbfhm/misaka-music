package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.theme.ThemeManager

/**
 * 基础 Activity: Namida 风格沉浸式
 *  - 深色状态栏/导航栏, 白色系统图标
 *  - 状态栏/导航栏跟随全局动态主色 (ThemeManager)
 *  - 整个界面树按标签自动着色 (theme_tint / theme_bg / theme_text ...)
 *  - 前进: 右侧滑入 / 返回: 左侧滑入 / 播放页: 底部滑入
 */
open class BaseActivity : AppCompatActivity() {

    protected var backAnimIn: Int = R.anim.slide_in_left
    protected var backAnimOut: Int = R.anim.slide_out_right

    /** 由子类覆盖: 是否让系统栏跟随动态主色 (播放页用透明状态栏, 覆盖为 false) */
    protected open fun tintSystemBars(): Boolean = true

    private var themeListener: ThemeManager.Listener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (tintSystemBars()) {
            applySystemBars(ThemeManager.palette)
        } else {
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = SURFACE
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        }
        // 整个界面树跟随主题色 (含 Fragment 视图)
        val l = ThemeManager.Listener { p, _ ->
            if (tintSystemBars()) applySystemBars(p)
            ThemeManager.applyToTree(window.decorView, p)
        }
        themeListener = l
        ThemeManager.addListener(l)
    }

    /** 子类在 setContentView 之后调用, 立刻把当前主题色刷到界面上 */
    protected fun bindTheme() {
        ThemeManager.applyToTree(window.decorView)
    }

    /**
     * 系统栏配色。
     *
     * ★ 之前状态栏用「主色容器色 55%」、导航栏用纯黑, 和内容区的 #1A1A1A 形成三条
     *   明显色带 (截图里上方发蓝、下方发黑), 很突兀。
     *   现在统一到内容区表面色, 只保留 5% 的主题色做极淡的层次, 视觉上完全连贯。
     */
    private fun applySystemBars(p: ThemeManager.Palette) {
        val surface = SURFACE
        window.statusBarColor = ThemeManager.blend(p.primary, 0.05f, surface)
        window.navigationBarColor = surface
    }

    override fun onDestroy() {
        ThemeManager.unbind(themeListener)
        themeListener = null
        super.onDestroy()
    }

    /**
     * 打开新页面。
     * [singleTop] = true 时复用栈顶同名 Activity, 避免「重复页面」堆叠
     * (设置 / 关于 / 播放页 / 歌词页 这类全局页面都用它)。
     */
    companion object {
        /** 内容区表面色 (与 colors.xml 的 namida_surface 保持一致) */
        const val SURFACE = 0xFF1A1A1A.toInt()
    }

    protected fun openPage(intent: Intent, singleTop: Boolean = false) {
        if (singleTop) intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    protected fun openPageUp(intent: Intent, singleTop: Boolean = false) {
        if (singleTop) intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_bottom, R.anim.slide_out_bottom)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(backAnimIn, backAnimOut)
    }
}
