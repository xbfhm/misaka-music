package com.xbfhm.misakamusic.player

import android.content.Context
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.util.Logger
import org.json.JSONArray
import org.json.JSONObject

/**
 * 上次播放队列的本地快照。
 *
 * 用途: 「定时播放」在 App 被杀掉之后由闹钟把进程拉起来时, 需要知道该播哪一队歌,
 * 因此把队列(最多 100 首, 只存必要字段)落盘。
 */
object PlayQueueStore {

    private const val PREFS = "play_queue"
    private const val KEY = "queue"
    private const val MAX = 100

    data class Snapshot(val tag: Long, val index: Int, val songs: List<Song>) {
        fun isEmpty() = songs.isEmpty()
    }

    fun save(ctx: Context, tag: Long, songs: List<Song>, index: Int) {
        try {
            val arr = JSONArray()
            songs.take(MAX).forEach { s ->
                arr.put(JSONObject()
                    .put("id", s.id)
                    .put("name", s.name)
                    .put("artists", s.artists)
                    .put("album", s.album)
                    .put("duration", s.duration)
                    .put("cover", s.cover)
                    .put("fee", s.fee)
                    .put("alias", s.alias))
            }
            ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong("tag", tag).putInt("index", index).putString(KEY, arr.toString()).apply()
        } catch (e: Exception) {
            Logger.log("Queue", "保存队列失败: ${e.message}")
        }
    }

    fun load(ctx: Context): Snapshot {
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = p.getString(KEY, null) ?: return Snapshot(-1, 0, emptyList())
        return try {
            val arr = JSONArray(raw)
            val list = ArrayList<Song>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(Song(
                    id = o.optLong("id"),
                    name = o.optString("name"),
                    artists = o.optString("artists"),
                    album = o.optString("album", ""),
                    duration = o.optLong("duration", 0),
                    cover = o.optString("cover", ""),
                    fee = o.optInt("fee", 0),
                    alias = o.optString("alias", "")
                ))
            }
            Snapshot(p.getLong("tag", -1), p.getInt("index", 0), list)
        } catch (e: Exception) {
            Logger.log("Queue", "读取队列失败: ${e.message}")
            Snapshot(-1, 0, emptyList())
        }
    }
}
