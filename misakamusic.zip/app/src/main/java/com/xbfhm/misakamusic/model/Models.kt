package com.xbfhm.misakamusic.model

import org.json.JSONObject

data class Song(
    val id: Long,
    val name: String,
    val artists: String,
    val album: String,
    val duration: Long,
    val cover: String,
    val fee: Int = 0,   // 0=免费, 1=VIP
    val alias: String = ""  // 翻译名/别名 (如日文歌的中文译名)
)

data class Playlist(
    val id: Long,
    val name: String,
    val cover: String,
    val trackCount: Int,
    val playCount: Long,
    val isLiked: Boolean = false,
    /** 本地歌单标记 (未登录也能建的歌单) */
    val isLocal: Boolean = false
)

/** 网易云用户 (搜索用户结果) */
data class User(
    val id: Long,
    val nickname: String,
    val avatar: String,
    val signature: String
)

/** 单行歌词 */
data class LyricLine(
    val timeMs: Long,
    val text: String,
    val translation: String = ""  // 翻译 (如有)
)

/**
 * 一次「音源解析」的真实结果。
 *
 * ★ 这是「音质到底有没有真的变」的关键: 请求的档位是 [requestedLevel],
 *   而服务器实际给的档位是 [httpLevel] / 码率 [br] / 文件大小 [size]。
 *   两者不一致 = 该歌曲没有这个音质的资源 (被降级了), 界面会如实告诉用户,
 *   而不是像以前那样「设置里写着无损, 实际听着是 128k」。
 */
data class PlayUrlInfo(
    val url: String,
    /** 服务器实际返回的档位: standard/higher/exhigh/lossless/hires (可能为空) */
    val level: String,
    /** 服务器实际返回的码率 kbps (0 = 未知) */
    val br: Int,
    /** 文件大小 (字节, 0 = 未知) */
    val size: Long,
    /** 播放源: netease / gdstudio / local */
    val source: String,
    /** 用户请求的档位 */
    val requested: String = ""
) {
    /** 实际码率: 优先用服务器给的 br, 否则用 文件大小/时长 反推 */
    fun actualBr(durationMs: Long): Int {
        if (br > 0) return br
        if (size > 0 && durationMs > 1000) {
            return ((size * 8L) / (durationMs / 1000L) / 1000L).toInt()
        }
        return 0
    }

    /** 是否被降级 (请求了更高音质, 但服务器只给了更低的) */
    fun downgraded(): Boolean {
        if (level.isBlank() || requested.isBlank()) return false
        return rank(level) < rank(requested)
    }

    companion object {
        fun rank(level: String): Int = when (level) {
            "standard" -> 0
            "higher" -> 1
            "exhigh" -> 2
            "lossless" -> 3
            "hires" -> 4
            else -> -1
        }
    }
}

// ---------------------------------------------------------------- JSON 互转
// 播放历史 / 本地歌单需要把 Song 持久化到 SharedPreferences

fun Song.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("name", name)
    .put("artists", artists)
    .put("album", album)
    .put("duration", duration)
    .put("cover", cover)
    .put("fee", fee)
    .put("alias", alias)

fun songFromJson(o: JSONObject?): Song? {
    if (o == null) return null
    val id = o.optLong("id", 0L)
    if (id <= 0L) return null
    return Song(
        id = id,
        name = o.optString("name", ""),
        artists = o.optString("artists", ""),
        album = o.optString("album", ""),
        duration = o.optLong("duration", 0L),
        cover = o.optString("cover", ""),
        fee = o.optInt("fee", 0),
        alias = o.optString("alias", "")
    )
}
