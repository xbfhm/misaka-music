package com.xbfhm.misakamusic.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.ui.PlayerActivity
import com.xbfhm.misakamusic.util.Logger

/**
 * 后台播放服务
 *
 * 关键修复: onCreate 中立刻调 startForeground()，
 * 不依赖 DefaultMediaNotificationProvider（它要等 player 有媒体才调，超时会杀进程）。
 */
@UnstableApi
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        Logger.log("PlaybackService", "onCreate")
        createNotificationChannel()

        // ★★★ 关键: 立刻 startForeground, 不等 player 加载媒体 ★★★
        // 系统要求 startForegroundService 后 5 秒内必须 startForeground
        // 如果等 DefaultMediaNotificationProvider（要等 player 有媒体+播放），URL 解析超时就会被杀
        val basicNotification = buildBasicNotification()
        startForeground(1001, basicNotification)
        Logger.log("PlaybackService", "startForeground 已调用（基础通知）")

        // 然后设置 MediaSession，DefaultMediaNotificationProvider 会自动更新通知内容
        val sessionActivity = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaSession.Builder(this, PlayerEngine.player)
            .setId("misaka_music_session")
            .setSessionActivity(sessionActivity)
            .build()

        val provider = DefaultMediaNotificationProvider.Builder(this)
            .setNotificationId(1001)
            .setChannelId(CHANNEL_ID)
            .build()
        setMediaNotificationProvider(provider)
        Logger.log("PlaybackService", "MediaSession + NotificationProvider 已就绪")
    }

    /** 基础通知: 服务启动时立刻显示，等 player 有媒体后会被 DefaultMediaNotificationProvider 替换 */
    private fun buildBasicNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle("MisakaMusic")
            .setContentText("正在播放...")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val hasQueue = PlayerEngine.hasQueue()
        Logger.log("PlaybackService", "onTaskRemoved hasQueue=$hasQueue playing=${PlayerEngine.isPlaying()}")
        if (!hasQueue) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        Logger.log("PlaybackService", "onDestroy")
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "音乐播放", NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "正在播放的音乐"
                enableLights(false)
                enableVibration(false)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "misaka_music_channel"
    }
}
