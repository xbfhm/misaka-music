package com.xbfhm.misakamusic.player

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.xbfhm.misakamusic.ui.PlayerActivity
import com.xbfhm.misakamusic.util.Logger

/**
 * 后台播放服务: MediaSession → 状态栏通知 / 灵动岛 / 锁屏 / 蓝牙控制
 *
 * 关键修复:
 *  1. onTaskRemoved: 有队列就不杀服务（之前检查 isPlaying 会在缓冲时误杀）
 *  2. onDestroy: 重置 PlayerEngine.serviceStarted 不需要了（每次都调 startForegroundService）
 */
@UnstableApi
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        Logger.log("PlaybackService", "onCreate")
        createNotificationChannel()

        val sessionActivity = PendingIntent.getActivity(
            this,
            0,
            Intent(this, PlayerActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaSession.Builder(this, PlayerEngine.player)
            .setId("misaka_music_session")
            .setSessionActivity(sessionActivity)
            .build()

        val provider = DefaultMediaNotificationProvider.Builder(this)
            .setNotificationId(1001)
            .setChannelId(CHANNEL_ID)
            .build()
        setMediaNotificationProvider(provider)
        Logger.log("PlaybackService", "MediaSession + NotificationProvider 已就绪")
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    /**
     * 用户从最近任务划掉 App 时调用。
     * 修复: 只要有歌单队列就保持服务存活（不检查 isPlaying，因为缓冲/暂停时 isPlaying=false 会误杀）
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val hasQueue = PlayerEngine.hasQueue()
        Logger.log("PlaybackService", "onTaskRemoved hasQueue=$hasQueue playing=${PlayerEngine.isPlaying()}")
        if (!hasQueue) {
            Logger.log("PlaybackService", "无队列, 停止服务")
            stopSelf()
        } else {
            Logger.log("PlaybackService", "有队列, 保持服务存活")
        }
    }

    override fun onDestroy() {
        Logger.log("PlaybackService", "onDestroy")
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "音乐播放",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "正在播放的音乐"
                enableLights(false)
                enableVibration(false)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "misaka_music_channel"
    }
}
