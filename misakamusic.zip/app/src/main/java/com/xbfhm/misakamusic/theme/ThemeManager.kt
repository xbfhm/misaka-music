package com.xbfhm.misakamusic.theme

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.BaseProgressIndicator
import com.google.android.material.tabs.TabLayout
import com.xbfhm.misakamusic.ui.WaveSeekBar
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.lang.ref.WeakReference
import kotlin.math.max
import kotlin.math.min

/**
 * 统一动态取色体系 (v2)。
 *
 * 设计目标 —— 「不冲突、好看」：
 *  1. 单一数据源: 全 App 只有一份配色 [palette]，状态栏 / 导航栏 / 底部导航 / 进度条 /
 *     播放键 / 列表高亮 / 歌词页 / 弹窗强调色 全部取自它，不再出现「一处红一处封面色」。
 *  2. 配色是语义化的: 从封面取到的种子色会先做饱和度/亮度归一化，再推导出
 *     primary / onPrimary / primaryContainer / onPrimaryContainer / secondary / surfaceTint，
 *     保证任何封面都不会刷出灰扑扑或刺眼的界面。
 *  3. 平滑过渡: 换歌时颜色在 420ms 内插值过渡，不会突然闪一下。
 *  4. 永不失效: 封面取色失败或封面是灰阶时保留上一次(或默认)配色。
 *  5. 可关闭: 设置里可关闭动态取色并选择固定主题色。
 */
object ThemeManager {

    /** 默认主色 (fallback) */
    const val DEFAULT_PRIMARY = 0xFFFF6B6B.toInt()

    /** 配色方案: 全部语义化角色 */
    data class Palette(
        val seed: Int,
        val primary: Int,
        val onPrimary: Int,
        val primaryContainer: Int,
        val onPrimaryContainer: Int,
        val secondary: Int,
        val surfaceTint: Int,
        val gradientEnd: Int
    )

    /** 主题监听: [final] = true 表示过渡动画已结束 (列表等重活可只在 final 时刷新) */
    fun interface Listener {
        fun onTheme(p: Palette, final: Boolean)
    }

    @Volatile
    var palette: Palette = build(DEFAULT_PRIMARY)
        private set

    val primary: Int get() = palette.primary
    val onPrimary: Int get() = palette.onPrimary
    val primaryContainer: Int get() = palette.primaryContainer
    val onPrimaryContainer: Int get() = palette.onPrimaryContainer
    val secondary: Int get() = palette.secondary
    val surfaceTint: Int get() = palette.surfaceTint

    /** 当前主色对应的封面 URL (用于去重) */
    @Volatile
    var currentCover: String = ""
        private set

    private val listeners = mutableListOf<WeakReference<Listener>>()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var anim: android.animation.ValueAnimator? = null

    // ==================== 注册 / 通知 ====================

    fun addListener(l: Listener) {
        listeners.removeAll { it.get() == null || it.get() === l }
        listeners.add(WeakReference(l))
        l.onTheme(palette, true)
    }

    fun removeListener(l: Listener) {
        listeners.removeAll { it.get() == null || it.get() === l }
    }

    /** 绑定一个视图树: 立即着色, 并返回可注销的监听 */
    fun bind(root: View?): Listener {
        val l = Listener { p, _ -> applyToTree(root, p) }
        addListener(l)
        return l
    }

    fun unbind(l: Listener?) {
        if (l != null) removeListener(l)
    }

    private fun notify(final: Boolean) {
        val it = listeners.iterator()
        while (it.hasNext()) {
            val l = it.next().get()
            if (l == null) it.remove()
            else runCatching { l.onTheme(palette, final) }
        }
    }

    // ==================== 应用主色 ====================

    /** 直接应用一个种子色 (固定主题色 / 重置) */
    fun applySeed(seed: Int, animate: Boolean = true) {
        val target = build(seed)
        if (target == palette) return
        Logger.log("Theme", "applySeed #${Integer.toHexString(seed)}")
        if (!animate) {
            anim?.cancel()
            palette = target
            notify(true)
            return
        }
        animateTo(target)
    }

    private fun animateTo(target: Palette) {
        anim?.cancel()
        val from = palette
        val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
        a.duration = 420
        a.interpolator = android.view.animation.DecelerateInterpolator()
        a.addUpdateListener { va ->
            palette = lerp(from, target, va.animatedFraction)
            notify(false)
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (anim === animation) {
                    palette = target
                    notify(true)
                }
            }
        })
        anim = a
        a.start()
    }

    /**
     * 从封面 URL 提取主色并全局应用。
     * 同一 URL 只取一次色 (结果缓存), 避免列表滚动时反复解码。
     */
    fun applyCover(context: Context, coverUrl: String?) {
        if (!ThemePrefs.dynamicColor) return
        if (coverUrl.isNullOrBlank()) return
        if (coverUrl == currentCover) return
        currentCover = coverUrl
        val app = context.applicationContext
        scope.launch {
            val seed = withContext(Dispatchers.IO) {
                try {
                    val bmp = Glide.with(app).asBitmap().load(coverUrl).submit().get()
                    val p = androidx.palette.graphics.Palette.from(bmp).clearFilters().maximumColorCount(24).generate()
                    pickSeed(p)
                } catch (e: Exception) {
                    Logger.log("Theme", "封面取色失败: ${e.message}")
                    null
                }
            }
            if (coverUrl != currentCover) return@launch
            if (seed == null) {
                Logger.log("Theme", "封面缺少可用色相, 保留当前配色")
                return@launch
            }
            applySeed(seed, animate = true)
        }
    }

    /** 从 Palette 里挑一个「有个性但不过分」的种子色 */
    private fun pickSeed(p: androidx.palette.graphics.Palette): Int? {
        val candidates = listOfNotNull(
            p.vibrantSwatch,
            p.lightVibrantSwatch,
            p.mutedSwatch,
            p.lightMutedSwatch,
            p.dominantSwatch
        )
        candidates.firstOrNull { saturationOf(it.rgb) >= 0.22f }?.let { return it.rgb }
        candidates.firstOrNull()?.let { return it.rgb }
        return null
    }

    /** 恢复默认主色 */
    fun reset(animate: Boolean = true) {
        currentCover = ""
        applySeed(if (ThemePrefs.dynamicColor) DEFAULT_PRIMARY else ThemePrefs.fixedSeed, animate)
    }

    // ==================== 视图绑定 ====================

    /**
     * 把一个视图树里的「主题控件」着色。
     *
     * 支持 android:tag 标签：
     *   theme_tint          -> ImageView tint / TextView 文字 = primary
     *   theme_tint_on       -> ImageView tint = onPrimary
     *   theme_bg            -> 背景 = primary
     *   theme_bg_container  -> 背景 = primaryContainer
     *   theme_text          -> 文字 = primary
     *   theme_stroke        -> MaterialCardView 描边 = primary
     *   theme_progress      -> 进度条指示色 = primary
     */
    fun applyToTree(root: View?, p: Palette = palette) {
        if (root == null) return
        applyToView(root, p)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) applyToTree(root.getChildAt(i), p)
        }
    }

    private fun applyToView(v: View, p: Palette) {
        when (v) {
            is WaveSeekBar -> v.accentColor = p.primary
            is TabLayout -> {
                v.setSelectedTabIndicatorColor(p.primary)
                v.setTabTextColors(0xFF938F96.toInt(), p.primary)
            }
            is BottomNavigationView -> {
                v.itemIconTintList = tintSelector(p)
                v.itemTextColor = tintSelector(p)
                try {
                    v.itemActiveIndicatorColor = ColorStateList.valueOf(p.primaryContainer)
                } catch (_: Throwable) {
                }
            }
            is BaseProgressIndicator<*> -> {
                v.setIndicatorColor(p.primary)
                try {
                    v.setTrackColor(withAlpha(0xFFFFFFFF.toInt(), 0.16f))
                } catch (_: Throwable) {
                }
            }
            is ProgressBar -> v.indeterminateTintList = ColorStateList.valueOf(p.primary)
        }

        when (v.tag) {
            "theme_tint" -> when {
                v is ImageView -> v.setColorFilter(p.primary)
                // MaterialButton 继承自 TextView, 需要单独处理 (改的是 icon 而不是文字)
                v is com.google.android.material.button.MaterialButton ->
                    v.iconTint = ColorStateList.valueOf(p.primary)
                v is TextView -> v.setTextColor(p.primary)
            }
            "theme_tint_on" -> if (v is ImageView) v.setColorFilter(p.onPrimary)
            "theme_bg" -> v.backgroundTintList = ColorStateList.valueOf(p.primary)
            "theme_bg_container" -> v.backgroundTintList = ColorStateList.valueOf(p.primaryContainer)
            "theme_text" -> when {
                v is com.google.android.material.button.MaterialButton ->
                    v.setTextColor(p.primary)
                v is TextView -> v.setTextColor(p.primary)
            }
            "theme_stroke" -> if (v is MaterialCardView) v.strokeColor = p.primary
            "theme_progress" -> when (v) {
                is BaseProgressIndicator<*> -> v.setIndicatorColor(p.primary)
                is ProgressBar -> v.indeterminateTintList = ColorStateList.valueOf(p.primary)
            }
        }
    }

    /** 底部导航: 选中=primary, 未选中=次级灰 */
    private fun tintSelector(p: Palette): ColorStateList = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
        intArrayOf(p.primary, 0xFF6B676D.toInt())
    )

    // ==================== 颜色工具 ====================

    /** 根据背景亮度自动选择黑/白前景, 保证可读性 */
    fun contrastOn(bg: Int): Int = if (luminance(bg) > 0.6) Color.BLACK else Color.WHITE

    /** 相对亮度 0..1 */
    fun luminance(color: Int): Double =
        (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0

    /** 饱和度 0..1 */
    fun saturationOf(color: Int): Float {
        val r = Color.red(color) / 255f
        val g = Color.green(color) / 255f
        val b = Color.blue(color) / 255f
        val mx = max(max(r, g), b)
        val mn = min(min(r, g), b)
        return if (mx <= 0f) 0f else (mx - mn) / mx
    }

    /** 把颜色按比例混合到基色上 (容器色/浅色遮罩) */
    fun blend(color: Int, ratio: Float, base: Int = 0xFF1A1A1A.toInt()): Int {
        val r = (Color.red(base) * (1 - ratio) + Color.red(color) * ratio).toInt()
        val g = (Color.green(base) * (1 - ratio) + Color.green(color) * ratio).toInt()
        val b = (Color.blue(base) * (1 - ratio) + Color.blue(color) * ratio).toInt()
        return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
    }

    /** 让颜色在深色背景上更「高级」: 亮度不足就提亮, 过曝就压暗 */
    fun tune(color: Int, minL: Float = 0.35f, maxL: Float = 0.80f): Int {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(color, hsl)
        hsl[2] = hsl[2].coerceIn(minL, maxL)
        return ColorUtils.HSLToColor(hsl)
    }

    private fun lerp(a: Palette, b: Palette, f: Float): Palette {
        fun mix(x: Int, y: Int): Int = ColorUtils.blendARGB(x, y, f)
        return Palette(
            seed = if (f < 0.5f) a.seed else b.seed,
            primary = mix(a.primary, b.primary),
            onPrimary = mix(a.onPrimary, b.onPrimary),
            primaryContainer = mix(a.primaryContainer, b.primaryContainer),
            onPrimaryContainer = mix(a.onPrimaryContainer, b.onPrimaryContainer),
            secondary = mix(a.secondary, b.secondary),
            surfaceTint = mix(a.surfaceTint, b.surfaceTint),
            gradientEnd = mix(a.gradientEnd, b.gradientEnd)
        )
    }

    // ==================== 配色生成 ====================

    /**
     * 由种子色生成一套深色主题下舒适的完整配色。
     * 饱和度/亮度归一化 + 色相保持: 「红封面」不会刷出一片刺眼大红,
     * 「灰封面」也不会让界面变成灰色水泥。
     */
    private fun build(seed: Int): Palette {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        val rawS = hsl[1]
        val s = when {
            rawS < 0.12f -> 0.55f
            rawS < 0.42f -> rawS + (0.42f - rawS) * 0.7f
            rawS > 0.82f -> 0.82f
            else -> rawS
        }

        return Palette(
            seed = seed,
            primary = hsl(h, s, 0.72f),
            onPrimary = hsl(h, (s * 0.85f).coerceAtLeast(0.25f), 0.16f),
            primaryContainer = hsl(h, (s * 0.55f).coerceAtLeast(0.22f), 0.24f),
            onPrimaryContainer = hsl(h, (s * 0.45f).coerceAtLeast(0.18f), 0.90f),
            secondary = hsl(h, (s * 0.5f).coerceAtLeast(0.18f), 0.80f),
            surfaceTint = hsl(h, (s * 0.6f).coerceAtLeast(0.2f), 0.55f),
            gradientEnd = hsl((h + if (h > 300f) -34f else 34f) % 360f, s * 0.9f, 0.60f)
        )
    }

    private fun hsl(h: Float, s: Float, l: Float): Int {
        val c = FloatArray(3)
        c[0] = ((h % 360f) + 360f) % 360f
        c[1] = s.coerceIn(0f, 1f)
        c[2] = l.coerceIn(0f, 1f)
        return ColorUtils.HSLToColor(c)
    }

    /** 卡片表面染色 (主题色轻微渗透) */
    fun tintedSurface(base: Int, amount: Float = 0.08f): Int = blend(palette.primary, amount, base)

    /** 调整透明度 */
    fun withAlpha(color: Int, alpha: Float): Int =
        Color.argb(
            (alpha * 255).toInt().coerceIn(0, 255),
            Color.red(color), Color.green(color), Color.blue(color)
        )
}
