package com.xbfhm.misakamusic.net

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.xbfhm.misakamusic.util.Logger
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * 登录态本地加密 (AES-256-GCM + Android Keystore)。
 *
 * 背景: 网易云的 MUSIC_U 等价于账号密码 —— 拿到它就能完整登录用户账号。
 *       早期版本把它明文写在 SharedPreferences 里, 只要设备被 root / 备份被导出 /
 *       文件被其它进程读到, 就等于账号泄露。
 *
 * 现在的做法:
 *  - 密钥由 **Android Keystore** 生成, 私钥材料不出 TEE/StrongBox, 无法被导出;
 *  - 用 AES/GCM/NoPadding 加密 cookie 串, IV 随机, 带完整性校验 (GCM tag);
 *  - 密文形如 `v1:<base64(iv||ciphertext)>` 存在 SharedPreferences。
 *
 * 兼容性:
 *  - 任何一步失败 (Keystore 不可用 / ROM 魔改 / 解密失败) 都**不会崩**,
 *    会自动回退到旧的明文键, 保证用户不会因为加密而突然掉登录。
 *  - 首次启动会自动把旧的明文 cookie 迁移成密文, 并删除明文键。
 */
internal object SessionCrypto {

    private const val TAG = "SessionCrypto"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "misaka_session_key_v1"
    private const val PREFIX = "v1:"
    private const val GCM_TAG_BITS = 128

    /** 加密; 任何异常返回 null (调用方回退明文) */
    fun encrypt(plain: String): String? {
        if (plain.isEmpty()) return null
        return try {
            val key = key() ?: return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            val out = ByteArray(iv.size + ct.size)
            System.arraycopy(iv, 0, out, 0, iv.size)
            System.arraycopy(ct, 0, out, iv.size, ct.size)
            PREFIX + Base64.encodeToString(out, Base64.NO_WRAP)
        } catch (t: Throwable) {
            Logger.log(TAG, "加密不可用, 回退明文存储: ${t.javaClass.simpleName}")
            null
        }
    }

    /** 解密; 任何异常返回 null */
    fun decrypt(stored: String): String? {
        if (!stored.startsWith(PREFIX)) return null
        return try {
            val key = key() ?: return null
            val raw = Base64.decode(stored.removePrefix(PREFIX), Base64.NO_WRAP)
            if (raw.size <= 12) return null
            val iv = raw.copyOfRange(0, 12)
            val ct = raw.copyOfRange(12, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (t: Throwable) {
            Logger.log(TAG, "解密失败 (密钥可能已失效): ${t.javaClass.simpleName}")
            null
        }
    }

    /** 取 (或首次生成) Keystore 里的 AES-256 密钥 */
    private fun key(): SecretKey? {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE)
        ks.load(null)
        (ks.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }

        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        gen.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }
}
