package com.xbfhm.misakamusic.data

import android.content.Context
import android.content.SharedPreferences
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.model.songFromJson
import com.xbfhm.misakamusic.model.toJson
import org.json.JSONArray
import org.json.JSONObject

/**
 * 播放历史 (本地)。
 *
 * ★ 之前完全没有历史记录 —— 用户根本找不到「刚刚听了什么」。
 * 现在每次真正开始播放就写入一条, 最多保留 [MAX] 条, 最新在前。
 */
object PlayHistoryStore {

    private const val PREFS = "play_history"
    private const val KEY = "items"
    private const val MAX = 300

    private var prefs: SharedPreferences? = null

    data class Entry(val song: Song, val playedAt: Long)

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    @Synchronized
    fun record(song: Song) {
        val p = prefs ?: return
        val list = loadRaw()
        val out = ArrayList<JSONObject>(list.length() + 1)
        for (i in 0 until list.length()) {
            list.optJSONObject(i)?.let { out.add(it) }
        }
        // 同一首歌去重后置顶 (保留最新时间)
        out.removeAll { it.optJSONObject("song")?.optLong("id", 0L) == song.id }
        out.add(
            0,
            JSONObject()
                .put("song", song.toJson())
                .put("time", System.currentTimeMillis())
        )
        while (out.size > MAX) out.removeAt(out.size - 1)
        val arr = JSONArray()
        out.forEach { arr.put(it) }
        p.edit().putString(KEY, arr.toString()).apply()
    }

    fun list(): List<Entry> {
        val out = ArrayList<Entry>()
        val arr = loadRaw()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val song = songFromJson(o.optJSONObject("song")) ?: continue
            out.add(Entry(song, o.optLong("time", 0L)))
        }
        return out
    }

    fun songs(): List<Song> = list().map { it.song }

    fun size(): Int = loadRaw().length()

    @Synchronized
    fun clear() {
        prefs?.edit()?.remove(KEY)?.apply()
    }

    private fun loadRaw(): JSONArray {
        val raw = prefs?.getString(KEY, null) ?: return JSONArray()
        return try {
            JSONArray(raw)
        } catch (_: Exception) {
            JSONArray()
        }
    }

    /** 「3 分钟前 / 昨天 20:31」 */
    fun relativeTime(ts: Long): String {
        if (ts <= 0) return ""
        val diff = System.currentTimeMillis() - ts
        val min = diff / 60000
        val fmt = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
        val hm = java.text.SimpleDateFormat("HH:mm", java.util.Locale.CHINA)
        return when {
            min < 1 -> "刚刚"
            min < 60 -> "${min} 分钟前"
            min < 60 * 24 -> "${min / 60} 小时前"
            min < 60 * 24 * 2 -> "昨天 ${hm.format(java.util.Date(ts))}"
            else -> fmt.format(java.util.Date(ts))
        }
    }
}
