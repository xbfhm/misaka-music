package com.xbfhm.misakamusic

import android.app.Application
import android.content.Intent
import com.xbfhm.misakamusic.net.Device
import com.xbfhm.misakamusic.net.GdApi
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.data.LocalPlaylistStore
import com.xbfhm.misakamusic.data.PlayHistoryStore
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.BackgroundPrefs
import com.xbfhm.misakamusic.theme.ThemePrefs
import com.xbfhm.misakamusic.ui.CrashActivity
import com.xbfhm.misakamusic.util.Logger

class App : Application() {
    override fun onCreate() {
        super.onCreate()

        // 1. 最先注册崩溃处理器: 内存日志 + 堆栈落盘 + 崩溃详情页 (便于无电脑时反馈)
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Logger.log("Crash", "未捕获异常: ${throwable::class.java.simpleName}: ${throwable.message}")
            throwable.stackTrace.take(20).forEach { Logger.log("Crash", "  at $it") }
            val stack = android.util.Log.getStackTraceString(throwable)

            // 落盘: Android/data/com.xbfhm.misakamusic/files/crash.log
            try {
                val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                    .format(java.util.Date())
                java.io.File(getExternalFilesDir(null), "crash.log")
                    .appendText("\n===== $time =====\n$stack\n")
            } catch (_: Throwable) {
            }

            // 展示崩溃详情页 (纯代码 UI + 系统主题, 尽量不依赖自定义资源)
            val shown = try {
                startActivity(
                    Intent(this, CrashActivity::class.java)
                        .putExtra(CrashActivity.EXTRA_STACK, stack)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            } catch (_: Throwable) {
                false
            }

            val finishProcess = {
                if (defaultHandler != null) {
                    defaultHandler.uncaughtException(thread, throwable)
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid())
                }
            }
            if (shown) {
                // 留出时间显示崩溃页, 之后再结束进程
                Thread {
                    try {
                        Thread.sleep(2500)
                    } catch (_: InterruptedException) {
                    }
                    finishProcess()
                }.start()
            } else {
                finishProcess()
            }
        }

        // 2. 说明: 这里**不**使用 Material You 系统动态取色 (DynamicColors)。
        //    原因是它按系统壁纸给 Material 控件重新着色, 会与 App 自己的「封面动态取色」
        //    互相打架 (同一个界面出现两套主色)。本 App 的统一配色由 ThemeManager 提供。
        Logger.log("App", "使用内置动态取色(封面取色), 已跳过系统 Material You 取色")

        Logger.log("App", "=== 应用启动 ===")

        // 3. 初始化设备信息
        Device.init(this)
        Logger.log("App", "Device 初始化完成: ${Device.MOBILE_NAME}")

        // 3.5 主题偏好 (动态取色开关 / 固定主题色) —— 必须在任何界面绘制前生效
        ThemePrefs.init(this)
        ThemePrefs.apply(animate = false)
        Logger.log("App", "主题初始化完成: dynamic=${ThemePrefs.dynamicColor}")

        // 3.6 自定义背景 / 播放历史 / 本地歌单
        BackgroundPrefs.init(this)
        PlayHistoryStore.init(this)
        LocalPlaylistStore.init(this)
        Logger.log(
            "App",
            "背景=${if (BackgroundPrefs.enabled) BackgroundPrefs.cacheKey() else "关闭"}, " +
                "历史=${PlayHistoryStore.size()}条, 本地歌单=${LocalPlaylistStore.count()}个"
        )

        // 4. 初始化 Session
        Session.init(this)
        Logger.log("App", "Session 初始化完成: loggedIn=${Session.isLoggedIn()}, uid=${Session.uid}")

        // 4.5 默认播放源 / 音质 兜底值打印 (便于排查"同步失效"类问题)
        Logger.log("App", "播放源=${Session.playSource}, 音质=${Session.quality}, 听歌同步=${Session.syncPlayRecord}")

        // 5. 初始化播放引擎 (解析器返回带真实音质信息的 PlayUrlInfo)
        PlayerEngine.init(this)
        // 默认播放源: netease(网易云原始接口) / gdstudio(免费聚合接口, 直接复用网易云歌曲ID)
        PlayerEngine.urlResolver = { id ->
            if (Session.playSource == "gdstudio") {
                GdApi.resolvePlayUrl(this, id, Session.quality)
            } else {
                NeteaseApi.resolvePlayUrl(this, id)
            }
        }
        PlayerEngine.scrobbleReporter = { songId, sourceId, timeSec ->
            NeteaseApi.scrobble(this, songId, sourceId, timeSec)
        }
        Logger.log("App", "PlayerEngine 初始化完成, scrobbleReporter 已绑定")

        // 6. 后台预取匿名 token + 登录态自检
        Thread {
            try {
                NeteaseApi.ensureAnonymous(this)
                Logger.log("App", "匿名 token 检查完成: MUSIC_A=${Session.has("MUSIC_A")}")
            } catch (e: Exception) {
                Logger.log("App", "匿名 token 获取失败: ${e.message}")
            }
            if (Session.isLoggedIn()) {
                try {
                    // 启动时自检一次 Cookie 是否还有效 (失效会清空登录态并在界面提示)
                    val st = kotlinx.coroutines.runBlocking { LoginChecker.check(this@App, force = true) }
                    Logger.log("App", "启动登录态自检: $st")
                } catch (e: Exception) {
                    Logger.log("App", "登录态自检异常: ${e.message}")
                }
            }
        }.start()

        Logger.log("App", "应用启动完成")
    }
}
