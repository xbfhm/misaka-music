package com.xbfhm.misakamusic

import android.app.Application
import com.google.android.material.color.DynamicColors
import com.xbfhm.misakamusic.net.Device
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.util.Logger

class App : Application() {
    override fun onCreate() {
        super.onCreate()

        // 1. 最先注册崩溃处理器: 内存日志 + 堆栈落盘 (便于无电脑时排查启动崩溃)
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Logger.log("Crash", "未捕获异常: ${throwable::class.java.simpleName}: ${throwable.message}")
            throwable.stackTrace.take(20).forEach { Logger.log("Crash", "  at $it") }
            try {
                val f = java.io.File(getExternalFilesDir(null), "crash.log")
                val time = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                    .format(java.util.Date())
                f.appendText("\n===== $time =====\n")
                f.appendText(android.util.Log.getStackTraceString(throwable))
                f.appendText("\n")
            } catch (_: Throwable) {
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // 2. Material You 动态取色: Android 12+ 跟随系统壁纸, 低版本自动回退主题配色
        //    加 try-catch 兜底, 避免个别 ROM 上动态取色异常导致启动失败
        try {
            DynamicColors.applyToActivitiesIfAvailable(this)
            Logger.log("App", "Material You 动态取色初始化完成")
        } catch (t: Throwable) {
            Logger.log("App", "动态取色初始化失败(已忽略, 不影响使用): ${t.message}")
        }

        Logger.log("App", "=== 应用启动 ===")

        // 1. 初始化设备信息
        Device.init(this)
        Logger.log("App", "Device 初始化完成: ${Device.MOBILE_NAME}")

        // 2. 初始化 Session
        Session.init(this)
        Logger.log("App", "Session 初始化完成: loggedIn=${Session.isLoggedIn()}, uid=${Session.uid}")

        // 3. 初始化播放引擎
        PlayerEngine.init(this)
        PlayerEngine.urlResolver = { id -> NeteaseApi.resolvePlayUrl(this, id) }
        PlayerEngine.scrobbleReporter = { songId, sourceId, timeSec ->
            NeteaseApi.scrobble(this, songId, sourceId, timeSec)
        }
        Logger.log("App", "PlayerEngine 初始化完成, scrobbleReporter 已绑定")

        // 4. 后台预取匿名 token
        Thread {
            try {
                NeteaseApi.ensureAnonymous(this)
                Logger.log("App", "匿名 token 检查完成: MUSIC_A=${Session.has("MUSIC_A")}")
            } catch (e: Exception) {
                Logger.log("App", "匿名 token 获取失败: ${e.message}")
            }
        }.start()

        Logger.log("App", "应用启动完成")
    }
}
