package com.xbfhm.misakamusic

import android.app.Application
import com.xbfhm.misakamusic.net.Device
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.util.Logger

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // 捕获未处理异常, 写入内存日志
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Logger.log("Crash", "未捕获异常: ${throwable::class.java.simpleName}: ${throwable.message}")
            throwable.stackTrace.take(20).forEach { Logger.log("Crash", "  at $it") }
            defaultHandler?.uncaughtException(thread, throwable)
        }

        Logger.log("App", "=== 应用启动 ===")

        // 1. 初始化设备信息
        Device.init(this)
        Logger.log("App", "Device 初始化完成: ${Device.MOBILE_NAME}")

        // 2. 初始化 Session
        Session.init(this)
        Logger.log("App", "Session 初始化完成: loggedIn=${Session.isLoggedIn()}, uid=${Session.uid}")

        // 3. 初始化播放引擎
        PlayerEngine.init(this)
        PlayerEngine.urlResolver = { id -> NeteaseApi.resolvePlayUrl(this, id) }
        PlayerEngine.scrobbleReporter = { songId, sourceId, timeSec ->
            NeteaseApi.scrobble(this, songId, sourceId, timeSec)
        }
        Logger.log("App", "PlayerEngine 初始化完成, scrobbleReporter 已绑定")

        // 4. 后台预取匿名 token
        Thread {
            try {
                NeteaseApi.ensureAnonymous(this)
                Logger.log("App", "匿名 token 检查完成: MUSIC_A=${Session.has("MUSIC_A")}")
            } catch (e: Exception) {
                Logger.log("App", "匿名 token 获取失败: ${e.message}")
            }
        }.start()

        Logger.log("App", "应用启动完成")
    }
}
