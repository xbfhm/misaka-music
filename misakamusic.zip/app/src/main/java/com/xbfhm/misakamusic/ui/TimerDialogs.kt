package com.xbfhm.misakamusic.ui

import android.app.TimePickerDialog
import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.player.PlayScheduler
import com.xbfhm.misakamusic.player.PlayerEngine
import java.util.Calendar

/**
 * 定时功能统一入口 (播放页 / 歌词页 / 设置页共用)。
 *
 * 两类定时:
 *  - **定时关闭**: N 分钟后停止 / 播完当前歌曲后停止 (最后 10 秒音量渐弱)
 *  - **定时播放**: 到点自动开始播放上次的歌单 (闹钟实现, App 被杀也能拉起)
 */
object TimerDialogs {

    private val PRESET_MINUTES = listOf(10, 15, 30, 45, 60, 90)

    fun show(ctx: Context) {
        val items = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        PRESET_MINUTES.forEach { m ->
            items.add(ctx.getString(R.string.timer_minutes_fmt, m) + "后停止")
            actions.add { setSleep(ctx, m) }
        }
        items.add(ctx.getString(R.string.timer_custom))
        actions.add { custom(ctx) }

        items.add(ctx.getString(R.string.timer_after_song))
        actions.add { afterSong(ctx) }

        items.add(ctx.getString(R.string.timer_schedule))
        actions.add { schedule(ctx) }

        if (PlayerEngine.hasSleepTimer()) {
            items.add(PlayerEngine.sleepLabel() + "（点此取消）")
            actions.add { cancelSleep(ctx) }
        }
        if (PlayScheduler.isEnabled(ctx)) {
            items.add("定时播放：${PlayScheduler.label(ctx)}（点此取消）")
            actions.add { cancelSchedule(ctx) }
        }

        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.timer_title)
            .setItems(items.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------- 定时关闭 ----------------

    private fun setSleep(ctx: Context, minutes: Int) {
        PlayerEngine.setSleepTimer(minutes)
        toast(ctx, ctx.getString(R.string.timer_set_fmt, minutes))
    }

    private fun afterSong(ctx: Context) {
        PlayerEngine.setSleepAfterCurrentSong()
        toast(ctx, ctx.getString(R.string.timer_after_song_set))
    }

    /** 自定义分钟数 */
    private fun custom(ctx: Context) {
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = ctx.getString(R.string.timer_custom_hint)
        }
        val wrap = FrameLayout(ctx).apply {
            val pad = (20 * ctx.resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.timer_custom_title)
            .setView(wrap)
            .setPositiveButton(R.string.timer_ok) { _, _ ->
                val m = input.text.toString().trim().toIntOrNull() ?: 0
                if (m in 1..600) setSleep(ctx, m)
                else toast(ctx, "请输入 1 - 600 之间的分钟数")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------- 定时播放 ----------------

    private fun schedule(ctx: Context) {
        val cal = Calendar.getInstance()
        val h = if (PlayScheduler.isEnabled(ctx)) PlayScheduler.hour(ctx) else cal.get(Calendar.HOUR_OF_DAY)
        val m = if (PlayScheduler.isEnabled(ctx)) PlayScheduler.minute(ctx) else cal.get(Calendar.MINUTE)
        val listener = TimePickerDialog.OnTimeSetListener { _, hh, mm ->
            PlayScheduler.schedule(ctx, hh, mm, true)
            toast(ctx, ctx.getString(R.string.timer_schedule_set_fmt, "%02d:%02d".format(hh, mm)))
        }
        TimePickerDialog(ctx, listener, h, m, true).show()
    }

    private fun cancelSleep(ctx: Context) {
        PlayerEngine.cancelSleepTimer()
        toast(ctx, ctx.getString(R.string.timer_canceled))
    }

    private fun cancelSchedule(ctx: Context) {
        PlayScheduler.cancel(ctx)
        toast(ctx, ctx.getString(R.string.timer_canceled))
    }

    private fun toast(ctx: Context, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }
}
