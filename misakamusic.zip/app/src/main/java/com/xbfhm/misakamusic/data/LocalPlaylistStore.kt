package com.xbfhm.misakamusic.data

import android.content.Context
import android.content.SharedPreferences
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.model.songFromJson
import com.xbfhm.misakamusic.model.toJson
import org.json.JSONArray
import org.json.JSONObject

/**
 * 本地歌单 (不需要登录网易云)。
 *
 * ★ 之前「我的歌单」页在未登录时是一整块「请先登录」的空状态,
 *   于是没登录的用户根本没法建歌单、也没法把歌收进去。
 *   现在本地歌单与网易云歌单并存:
 *     · 未登录  → 只能看到 / 编辑本地歌单 (歌曲存在本机)
 *     · 已登录  → 两组都在, 「添加到歌单」时都可以选
 *
 * id 用负数, 和网易云歌单 id (正数) 天然区分开。
 */
object LocalPlaylistStore {

    private const val PREFS = "local_playlists"
    private const val KEY = "items"

    private var prefs: SharedPreferences? = null

    data class Local(
        val id: Long,
        val name: String,
        val songs: List<Song>,
        val createdAt: Long
    )

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    fun all(): List<Local> {
        val arr = loadRaw()
        val out = ArrayList<Local>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                Local(
                    id = o.optLong("id", 0L),
                    name = o.optString("name", "本地歌单"),
                    songs = parseSongs(o.optJSONArray("songs")),
                    createdAt = o.optLong("created_at", 0L)
                )
            )
        }
        return out
    }

    fun get(id: Long): Local? = all().firstOrNull { it.id == id }

    /** 新建歌单, 返回新歌单 id */
    @Synchronized
    fun create(name: String): Long {
        val p = prefs ?: return 0L
        val clean = name.trim().ifEmpty { "新建歌单" }
        var id = -System.currentTimeMillis()
        // 极端情况下同一毫秒内建两个, 保证 id 唯一
        while (all().any { it.id == id }) id -= 1
        val arr = loadRaw()
        arr.put(
            JSONObject()
                .put("id", id)
                .put("name", clean)
                .put("created_at", System.currentTimeMillis())
                .put("songs", JSONArray())
        )
        p.edit().putString(KEY, arr.toString()).apply()
        return id
    }

    @Synchronized
    fun rename(id: Long, name: String) {
        val p = prefs ?: return
        val arr = loadRaw()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optLong("id", 0L) == id) o.put("name", name.trim().ifEmpty { "本地歌单" })
        }
        p.edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized
    fun delete(id: Long) {
        val p = prefs ?: return
        val arr = loadRaw()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optLong("id", 0L) != id) out.put(o)
        }
        p.edit().putString(KEY, out.toString()).apply()
    }

    /** 添加歌曲, 返回 true=新加入, false=已存在 */
    @Synchronized
    fun addSong(id: Long, song: Song): Boolean {
        val p = prefs ?: return false
        val arr = loadRaw()
        var added = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optLong("id", 0L) != id) continue
            val songs = o.optJSONArray("songs") ?: JSONArray()
            if (contains(songs, song.id)) return false
            songs.put(song.toJson())
            o.put("songs", songs)
            added = true
        }
        if (added) p.edit().putString(KEY, arr.toString()).apply()
        return added
    }

    @Synchronized
    fun removeSong(id: Long, songId: Long) {
        val p = prefs ?: return
        val arr = loadRaw()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optLong("id", 0L) != id) continue
            val songs = o.optJSONArray("songs") ?: JSONArray()
            val out = JSONArray()
            for (j in 0 until songs.length()) {
                val s = songs.optJSONObject(j) ?: continue
                if (s.optLong("id", 0L) != songId) out.put(s)
            }
            o.put("songs", out)
        }
        p.edit().putString(KEY, arr.toString()).apply()
    }

    fun contains(id: Long, songId: Long): Boolean {
        val pl = get(id) ?: return false
        return pl.songs.any { it.id == songId }
    }

    fun count(): Int = all().size

    private fun contains(arr: JSONArray, songId: Long): Boolean {
        for (j in 0 until arr.length()) {
            if (arr.optJSONObject(j)?.optLong("id", 0L) == songId) return true
        }
        return false
    }

    private fun parseSongs(arr: JSONArray?): List<Song> {
        if (arr == null) return emptyList()
        val out = ArrayList<Song>()
        for (i in 0 until arr.length()) {
            songFromJson(arr.optJSONObject(i))?.let { out.add(it) }
        }
        return out
    }

    private fun loadRaw(): JSONArray {
        val raw = prefs?.getString(KEY, null) ?: return JSONArray()
        return try {
            JSONArray(raw)
        } catch (_: Exception) {
            JSONArray()
        }
    }
}
