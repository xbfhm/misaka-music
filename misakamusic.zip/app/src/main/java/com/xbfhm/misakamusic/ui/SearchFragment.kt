package com.xbfhm.misakamusic.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.FragmentSearchBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.model.User
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.ThemeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 搜索页 —— 全 App 唯一的搜索入口 (首页那个「假搜索框」已经删掉)。
 * 双栏 (歌曲 / 用户) + 热门关键词快捷搜索。
 */
class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songAdapter = SongAdapter { index -> playSong(index) }
    private val userAdapter = UserAdapter { u -> openUser(u) }
    private var songs: List<Song> = emptyList()
    private var userList: List<User> = emptyList()
    private var currentTab = 0  // 0=歌曲 1=用户
    private var searched = false
    private val SEARCH_TAG = -2L

    private val hotWords = arrayOf(
        "初音未来", "孤独摇滚", "Aimer", "YOASOBI", "四月是你的谎言", "泽野弘之"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ThemeManager.applyToTree(view)
        binding.rvSongs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSongs.adapter = songAdapter
        binding.rvUsers.layoutManager = LinearLayoutManager(requireContext())
        binding.rvUsers.adapter = userAdapter

        binding.etSearch.setOnEditorActionListener { _: TextView?, actionId: Int, _: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(binding.etSearch.text.toString().trim())
                true
            } else false
        }
        binding.btnSearch.setOnClickListener {
            doSearch(binding.etSearch.text.toString().trim())
        }
        binding.btnClearSearch.setOnClickListener { clearSearch() }

        // 热门关键词: 一点即搜
        val chips = listOf(
            binding.hot1, binding.hot2, binding.hot3,
            binding.hot4, binding.hot5, binding.hot6
        )
        chips.forEachIndexed { i, tv ->
            tv.text = hotWords[i]
            tv.setOnClickListener {
                binding.etSearch.setText(hotWords[i])
                binding.etSearch.setSelection(hotWords[i].length)
                doSearch(hotWords[i])
            }
            UiFx.attachPressFeedback(tv, 0.94f)
        }

        binding.tabSongs.setOnClickListener { selectTab(0) }
        binding.tabUsers.setOnClickListener { selectTab(1) }
        UiFx.attachPressFeedback(binding.tabSongs, 0.95f)
        UiFx.attachPressFeedback(binding.tabUsers, 0.95f)

        render()
    }

    private fun doSearch(keyword: String) {
        if (keyword.isEmpty()) {
            toast(getString(R.string.search_empty))
            return
        }
        searched = true
        binding.hotBox.visibility = View.GONE
        hideKeyboard()
        binding.tvEmpty.visibility = View.GONE
        scope.launch {
            val s = withContext(Dispatchers.IO) { NeteaseApi.search(requireContext(), keyword, 30) }
            val u = withContext(Dispatchers.IO) { NeteaseApi.searchUser(requireContext(), keyword, 20) }
            songs = s
            userList = u
            render()
        }
    }

    private fun selectTab(index: Int) {
        if (currentTab == index) return
        currentTab = index
        renderTabs()
        render()
    }

    /** 同步玻璃分段控件的选中态 (选中=主色药丸, 未选中=透明) */
    private fun renderTabs() {
        val onBg = resources.getDrawable(R.drawable.bg_segment_selected, null)
        val selected = context?.let { androidx.core.content.ContextCompat.getColor(it, R.color.segment_text_selected) }
            ?: 0xFFFFFFFF.toInt()
        val normal = context?.let { androidx.core.content.ContextCompat.getColor(it, R.color.namida_text_secondary) }
            ?: 0xFFA4AAB8.toInt()
        binding.tabSongs.background = if (currentTab == 0) onBg else null
        binding.tabUsers.background = if (currentTab == 1) onBg else null
        binding.tabSongs.setTextColor(if (currentTab == 0) selected else normal)
        binding.tabUsers.setTextColor(if (currentTab == 1) selected else normal)
    }

    private fun render() {
        renderTabs()
        binding.btnClearSearch.visibility =
            if (binding.etSearch.text.isNullOrEmpty()) View.GONE else View.VISIBLE
        if (!searched) {
            binding.hotBox.visibility = View.VISIBLE
            binding.rvSongs.visibility = if (currentTab == 0) View.VISIBLE else View.GONE
            binding.rvUsers.visibility = if (currentTab == 1) View.VISIBLE else View.GONE
            binding.tvEmpty.visibility = View.GONE
            binding.tvEmpty.text = getString(R.string.search_empty_tip)
            songAdapter.submit(emptyList())
            userAdapter.submit(emptyList())
            return
        }
        if (currentTab == 0) {
            binding.rvSongs.visibility = View.VISIBLE
            binding.rvUsers.visibility = View.GONE
            songAdapter.submit(songs)
            binding.tvEmpty.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE
            if (songs.isEmpty()) binding.tvEmpty.text = "没有找到相关歌曲"
        } else {
            binding.rvSongs.visibility = View.GONE
            binding.rvUsers.visibility = View.VISIBLE
            userAdapter.submit(userList)
            binding.tvEmpty.visibility = if (userList.isEmpty()) View.VISIBLE else View.GONE
            if (userList.isEmpty()) binding.tvEmpty.text = "没有找到相关用户"
        }
    }

    private fun clearSearch() {
        binding.etSearch.setText("")
        songs = emptyList()
        userList = emptyList()
        searched = false
        songAdapter.submit(emptyList())
        userAdapter.submit(emptyList())
        binding.tvEmpty.visibility = View.GONE
        binding.hotBox.visibility = View.VISIBLE
        binding.etSearch.clearFocus()
        hideKeyboard()
        render()
    }

    private fun hideKeyboard() {
        runCatching {
            val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(binding.etSearch.windowToken, 0)
        }
    }

    private fun playSong(index: Int) {
        if (index !in songs.indices) return
        PlayerEngine.setPlaylist(SEARCH_TAG, songs, index)
        songAdapter.currentIndex = PlayerEngine.currentIndex
        songAdapter.notifyDataSetChanged()
        ThemeManager.applyCover(requireContext(), songs[index].cover)
        val intent = Intent(requireContext(), PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_COVER_TRANSITION, songAdapter.coverTransitionName(index))
        val holder = binding.rvSongs.findViewHolderForAdapterPosition(index) as? SongAdapter.VH
        if (holder != null) {
            UiFx.startWithSharedCover(
                requireActivity(), intent, holder.binding.cover,
                songAdapter.coverTransitionName(index),
                R.anim.slide_in_bottom, R.anim.fade_out
            )
        } else {
            startActivity(intent)
            requireActivity().overridePendingTransition(R.anim.slide_in_bottom, R.anim.fade_out)
        }
    }

    private fun openUser(u: User) {
        val intent = Intent(requireContext(), UserActivity::class.java)
        intent.putExtra(UserActivity.EXTRA_UID, u.id)
        intent.putExtra(UserActivity.EXTRA_NICKNAME, u.nickname)
        startActivity(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
