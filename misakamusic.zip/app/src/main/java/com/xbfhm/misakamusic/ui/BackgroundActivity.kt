package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityBackgroundBinding
import com.xbfhm.misakamusic.theme.BackgroundPrefs
import com.xbfhm.misakamusic.theme.ThemeManager

/**
 * 自定义背景设置页。
 *
 * 提供:
 *  · 6 张内置二次元插画 (drawable-nodpi, 随 App 一起打包, 无需联网)
 *  · 从相册选图 (SAF 持久化授权, 重启后依然可用)
 *  · 毛玻璃强度 / 背景暗度 / 呼吸微动效
 * 调完立即生效, 并同步刷新所有已打开的页面。
 */
class BackgroundActivity : BaseActivity() {

    private lateinit var binding: ActivityBackgroundBinding
    private lateinit var presetCards: List<MaterialCardView>

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Throwable) {
            }
            BackgroundPrefs.customUri = uri.toString()
            BackgroundPrefs.source = "custom"
            BackgroundPrefs.enabled = true
            binding.swEnable.isChecked = true
            updateCustomPreview(uri)
            applyAll()
            toast(getString(R.string.bg_picked))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBackgroundBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        presetCards = listOf(
            binding.bgP0, binding.bgP1, binding.bgP2,
            binding.bgP3, binding.bgP4, binding.bgP5
        )

        binding.btnBack.setOnClickListener { finish() }

        binding.swEnable.isChecked = BackgroundPrefs.enabled
        binding.swEnable.setOnCheckedChangeListener { _, checked ->
            BackgroundPrefs.enabled = checked
            applyAll()
        }

        binding.swMotion.isChecked = BackgroundPrefs.motion
        binding.swMotion.setOnCheckedChangeListener { _, checked ->
            BackgroundPrefs.motion = checked
            applyAll()
        }

        presetCards.forEachIndexed { index, card ->
            card.setOnClickListener {
                BackgroundPrefs.presetIndex = index
                BackgroundPrefs.source = "preset"
                BackgroundPrefs.enabled = true
                binding.swEnable.isChecked = true
                applyAll()
            }
        }

        binding.btnPickImage.setOnClickListener {
            runCatching { pickImage.launch(arrayOf("image/*")) }
                .onFailure { toast(getString(R.string.bg_pick_fail)) }
        }

        binding.btnRandom.setOnClickListener {
            var next = (Math.random() * BackgroundPrefs.PRESETS.size).toInt()
            if (next == BackgroundPrefs.presetIndex) next = (next + 1) % BackgroundPrefs.PRESETS.size
            BackgroundPrefs.presetIndex = next
            BackgroundPrefs.source = "preset"
            BackgroundPrefs.enabled = true
            binding.swEnable.isChecked = true
            applyAll()
        }

        binding.btnBlurMinus.setOnClickListener { stepBlur(-6) }
        binding.btnBlurPlus.setOnClickListener { stepBlur(6) }
        binding.btnDimMinus.setOnClickListener { stepDim(-10) }
        binding.btnDimPlus.setOnClickListener { stepDim(10) }

        render()
    }

    private fun stepBlur(delta: Int) {
        BackgroundPrefs.blur = BackgroundPrefs.blur + delta
        render()
        applyAll()
    }

    private fun stepDim(delta: Int) {
        BackgroundPrefs.dim = BackgroundPrefs.dim + delta
        render()
        applyAll()
    }

    private fun render() {
        binding.tvBlur.text = if (BackgroundPrefs.blur <= 0)
            getString(R.string.bg_blur_off)
        else "${BackgroundPrefs.blur}（${BackgroundPrefs.blur * 3}dp）"
        binding.tvDim.text = "${BackgroundPrefs.dim}%"

        val accent = ThemeManager.primary
        presetCards.forEachIndexed { index, card ->
            val selected = BackgroundPrefs.source == "preset" && index == BackgroundPrefs.presetIndex
            card.strokeColor = if (selected) accent else 0x33FFFFFF
            card.strokeWidth = if (selected) (3 * resources.displayMetrics.density).toInt() else 2
            card.alpha = if (selected) 1f else 0.72f
        }
        binding.tvPreviewTitle.text = if (BackgroundPrefs.source == "custom")
            getString(R.string.bg_source_custom) else getString(R.string.bg_preview_title)

        val enabled = BackgroundPrefs.enabled
        binding.ivPreview.alpha = if (enabled) 1f else 0.25f
        binding.swMotion.isEnabled = enabled
        binding.btnBlurPlus.isEnabled = enabled
        binding.btnBlurMinus.isEnabled = enabled
        binding.btnDimPlus.isEnabled = enabled
        binding.btnDimMinus.isEnabled = enabled

        // 预览图直接用当前背景资源 (未启用时也显示, 便于挑选)
        if (BackgroundPrefs.source != "custom") {
            binding.ivPreview.setImageResource(BackgroundPrefs.presetRes())
        }
    }

    private fun updateCustomPreview(uri: Uri) {
        Glide.with(this)
            .load(uri)
            .placeholder(R.drawable.bg_preset_1)
            .into(binding.ivPreview)
        binding.tvPreviewTitle.text = getString(R.string.bg_source_custom)
    }

    /** 立即生效: 刷新本页 + 通知所有页面重画 */
    private fun applyAll() {
        BackgroundHost.refresh(this)
        render()
        BackgroundChanged.notifyChanged()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}

/**
 * 背景变更广播 (简单静态版本号即可, 各页在 onResume 里重新 attach 时会自行比对)。
 */
object BackgroundChanged {
    @Volatile
    var version: Int = 0
        private set

    fun notifyChanged() {
        version++
    }
}
