package com.xbfhm.misakamusic.theme

import android.content.Context
import android.content.SharedPreferences
import com.xbfhm.misakamusic.R

/**
 * 自定义背景偏好。
 *
 * 支持两类来源:
 *  - 内置二次元插画 (drawable-nodpi/bg_preset_1..6.jpg), 开箱即用
 *  - 相册自选图片 (通过 SAF 持久化 URI 权限, 重启后依然可用)
 *
 * 另外提供「毛玻璃半径」「暗度」「缓慢呼吸动效」三个可调项,
 * 配合玻璃拟态卡片形成 OPPO / 酷安 / 苹果那种「Liquid Glass」观感。
 */
object BackgroundPrefs {

    private const val PREFS = "bg_prefs"

    /** 内置背景 (顺序即选择器顺序) */
    val PRESETS: List<Int> = listOf(
        R.drawable.bg_preset_1,
        R.drawable.bg_preset_2,
        R.drawable.bg_preset_3,
        R.drawable.bg_preset_4,
        R.drawable.bg_preset_5,
        R.drawable.bg_preset_6
    )

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    private fun p(): SharedPreferences? = prefs

    /** 总开关 (关掉 = 使用纯色深空背景) */
    var enabled: Boolean
        get() = p()?.getBoolean("enabled", false) ?: false
        set(v) { p()?.edit()?.putBoolean("enabled", v)?.apply() }

    /** 来源: preset / custom */
    var source: String
        get() = p()?.getString("source", "preset") ?: "preset"
        set(v) { p()?.edit()?.putString("source", v)?.apply() }

    var presetIndex: Int
        get() = p()?.getInt("preset_index", 0) ?: 0
        set(v) { p()?.edit()?.putInt("preset_index", v.coerceIn(0, PRESETS.size - 1))?.apply() }

    var customUri: String
        get() = p()?.getString("custom_uri", "") ?: ""
        set(v) { p()?.edit()?.putString("custom_uri", v)?.apply() }

    /** 毛玻璃半径 0..48 (在缩小后的位图上做堆栈模糊, 代价极低) */
    var blur: Int
        get() = p()?.getInt("blur", 22) ?: 22
        set(v) { p()?.edit()?.putInt("blur", v.coerceIn(0, 48))?.apply() }

    /** 背景暗度 0..80 (%) — 越大文字越清晰 */
    var dim: Int
        get() = p()?.getInt("dim", 34) ?: 34
        set(v) { p()?.edit()?.putInt("dim", v.coerceIn(0, 80))?.apply() }

    /** 背景缓慢呼吸缩放 (苹果壁纸式微动效) */
    var motion: Boolean
        get() = p()?.getBoolean("motion", true) ?: true
        set(v) { p()?.edit()?.putBoolean("motion", v)?.apply() }

    fun presetRes(): Int = PRESETS[presetIndex.coerceIn(0, PRESETS.size - 1)]

    /** 位图缓存键 (不含 dim: 暗度由遮罩层实时控制) */
    fun cacheKey(): String = when {
        !enabled -> "off"
        source == "custom" -> "c|$customUri|b$blur"
        else -> "p|$presetIndex|b$blur"
    }
}
