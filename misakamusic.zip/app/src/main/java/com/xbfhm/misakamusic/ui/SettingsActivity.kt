package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.data.PlayHistoryStore
import com.xbfhm.misakamusic.databinding.ActivitySettingsBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayScheduler
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.BackgroundPrefs
import com.xbfhm.misakamusic.theme.ThemeManager
import com.xbfhm.misakamusic.theme.ThemePrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        binding.btnBack.setOnClickListener { finish() }
        binding.aboutCard.setOnClickListener {
            openPage(Intent(this, AboutActivity::class.java), singleTop = true)
        }
        binding.btnLogin.setOnClickListener {
            openPage(Intent(this, LoginActivity::class.java), singleTop = true)
        }
        binding.btnLogout.setOnClickListener { logout() }
        binding.btnRefreshVip.setOnClickListener { loadVip() }
        binding.btnCheckLogin.setOnClickListener { checkLogin() }
        // 音质: 与播放页共用同一个选择器 (切换后立刻按新档位重新加载当前歌曲)
        binding.qualityCard.setOnClickListener { QualityDialogs.show(this) { renderQuality() } }
        binding.sourceCard.setOnClickListener { showSourceChooser() }
        binding.timerCard.setOnClickListener { TimerDialogs.show(this) }
        binding.syncCard.setOnClickListener { verifySync() }
        // 自定义背景 + 播放历史
        binding.bgCard.setOnClickListener {
            openPage(Intent(this, BackgroundActivity::class.java), singleTop = true)
        }
        binding.historyCard.setOnClickListener {
            openPage(Intent(this, HistoryActivity::class.java), singleTop = true)
        }

        // 动态取色开关
        binding.swDynamic.isChecked = ThemePrefs.dynamicColor
        binding.swDynamic.setOnCheckedChangeListener { _, checked ->
            ThemePrefs.dynamicColor = checked
            ThemePrefs.apply(animate = true)
            renderTheme()
            toast(
                if (checked) getString(R.string.theme_dynamic_desc)
                else getString(R.string.theme_locked)
            )
        }
        binding.colorCard.setOnClickListener { showColorChooser() }
        binding.colorCard.alpha = if (ThemePrefs.dynamicColor) 0.5f else 1f

        // 听歌记录同步开关
        binding.swSync.isChecked = Session.syncPlayRecord
        binding.swSync.setOnCheckedChangeListener { _, checked ->
            Session.syncPlayRecord = checked
            renderSync()
            if (checked && !Session.isLoggedIn()) toast(getString(R.string.sync_need_login))
        }

        renderAccount()
        renderSource()
        renderQuality()
        renderTheme()
        renderSync()
        renderTimer()
        loadVip()
    }

    override fun onResume() {
        super.onResume()
        renderAccount()
        renderTimer()
        renderBackground()
        binding.tvHistoryState.text = "${PlayHistoryStore.size()} 首 · ${getString(R.string.history_desc)}"
        renderQuality()
        renderSync()
    }

    /** 背景状态: 让设置页一眼看到当前用的是哪张背景 */
    private fun renderBackground() {
        binding.tvBgState.text = if (!BackgroundPrefs.enabled) {
            getString(R.string.bg_entry_desc)
        } else {
            val src = if (BackgroundPrefs.source == "custom") "相册图片"
            else "内置插画 #${BackgroundPrefs.presetIndex + 1}"
            "$src · 模糊 ${BackgroundPrefs.blur} · 暗度 ${BackgroundPrefs.dim}%"
        }
    }

    /** 未登录: 显示登录入口; 已登录: 显示账号信息 */
    private fun renderAccount() {
        val logged = Session.isLoggedIn()
        binding.loginCard.visibility = if (logged) View.GONE else View.VISIBLE
        binding.accountCard.visibility = if (logged) View.VISIBLE else View.GONE
        if (!logged) return
        binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
        binding.tvUid.text = "${getString(R.string.uid_label)}: ${Session.uid}"
        Glide.with(this)
            .load(Session.avatar)
            .placeholder(R.drawable.ic_account)
            .error(R.drawable.ic_account)
            .into(binding.avatar)
    }

    /**
     * 检测登录状态。
     *
     * ★ 以前只判断「账号资料接口通不通」, 结果经常显示「登录有效」但歌单/收藏照样失败,
     *   用户觉得这个按钮没用。现在会**真实跑一遍关键接口**并逐项报告:
     *     ① 账号资料（昵称 / UID）  ② 我的歌单能不能拉  ③ 音源接口能不能拿到地址
     *   任何一项失败都会明确指出是哪一步出的问题。
     */
    private fun checkLogin() {
        if (!Session.isLoggedIn()) {
            toast(getString(R.string.login_none))
            return
        }
        binding.btnCheckLogin.isEnabled = false
        binding.tvLoginStatus.visibility = View.VISIBLE
        binding.tvLoginStatus.text = getString(R.string.login_checking)
        scope.launch {
            val st = try {
                LoginChecker.check(this@SettingsActivity, force = true)
            } catch (e: Exception) {
                LoginChecker.State.OFFLINE
            }

            // 逐项实测
            val sb = StringBuilder()
            var allOk = st == LoginChecker.State.VALID
            sb.append("① 账号资料：")
            if (st == LoginChecker.State.VALID) {
                sb.append("✅ ${Session.nickname}（UID ${Session.uid}）\n")
            } else {
                allOk = false
                sb.append("❌ ${LoginChecker.lastMessage}\n")
            }

            sb.append("② 我的歌单：")
            if (st == LoginChecker.State.VALID && Session.uid > 0) {
                val pls = withContext(Dispatchers.IO) {
                    runCatching { NeteaseApi.userPlaylists(this@SettingsActivity, Session.uid) }.getOrNull()
                }
                if (pls == null) {
                    allOk = false
                    sb.append("❌ 接口请求失败（网络或风控）\n")
                } else {
                    sb.append("✅ 拉到 ${pls.size} 个歌单\n")
                }
            } else {
                allOk = false
                sb.append("⏭ 跳过（登录态无效）\n")
            }

            sb.append("③ 音源接口：")
            val cur = PlayerEngine.currentSong()
            if (st == LoginChecker.State.VALID && cur != null) {
                val info = withContext(Dispatchers.IO) {
                    runCatching { NeteaseApi.songUrlInfo(this@SettingsActivity, cur.id, Session.quality) }.getOrNull()
                }
                if (info != null) {
                    sb.append("✅ 《${cur.name}》可播放（实际 ${QualityDialogs.shortLabel(info.level)}")
                    val br = info.actualBr(cur.duration)
                    if (br > 0) sb.append(" ${br}kbps")
                    sb.append("）\n")
                } else {
                    sb.append("⚠️ 该曲暂无可播放地址（可能无版权）\n")
                }
            } else {
                sb.append("⏭ 跳过（先播放一首歌再来检测）\n")
            }

            sb.append('\n')
            sb.append(
                when {
                    allOk -> "结论：登录态完全正常，歌单 / 收藏 / 播放都可以正常使用。"
                    st == LoginChecker.State.OFFLINE -> "结论：网络异常，暂时无法判断。已保留登录态，请换网络再试。"
                    else -> "结论：登录态已失效，请重新登录。"
                }
            )

            binding.btnCheckLogin.isEnabled = true
            binding.tvLoginStatus.text = when (st) {
                LoginChecker.State.VALID ->
                    getString(R.string.login_valid_fmt, Session.nickname, Session.uid)
                LoginChecker.State.INVALID ->
                    getString(R.string.login_invalid_fmt, LoginChecker.lastMessage)
                LoginChecker.State.OFFLINE ->
                    getString(R.string.login_offline_fmt, LoginChecker.lastMessage)
                else -> getString(R.string.login_none)
            }
            renderAccount()

            MaterialAlertDialogBuilder(this@SettingsActivity)
                .setTitle(if (allOk) "登录状态检测：全部正常" else "登录状态检测结果")
                .setMessage(sb.toString())
                .setPositiveButton(R.string.timer_ok, null)
                .apply {
                    if (st == LoginChecker.State.INVALID) {
                        setNeutralButton(R.string.relogin) { _, _ ->
                            openPage(
                                Intent(this@SettingsActivity, LoginActivity::class.java),
                                singleTop = true
                            )
                        }
                    }
                }
                .show()
        }
    }

    private fun loadVip() {
        if (!Session.isLoggedIn()) return
        binding.tvVipStatus.text = getString(R.string.loading)
        binding.tvVipLevel.text = "--"
        binding.tvVipExpire.text = "--"
        scope.launch {
            val info = withContext(Dispatchers.IO) {
                NeteaseApi.vipInfo(this@SettingsActivity, Session.uid)
            }
            binding.tvVipStatus.text =
                if (info.isVip) getString(R.string.vip_yes) else getString(R.string.vip_no)
            binding.tvVipStatus.setTextColor(ThemeManager.primary)
            binding.tvVipLevel.text = info.level.ifEmpty { "--" }
            binding.tvVipExpire.text = info.expireTime.ifEmpty { "--" }
        }
    }

    // ---------------- 主题 ----------------

    private fun renderTheme() {
        val seed = ThemePrefs.fixedSeed
        val name = ThemePrefs.PRESETS.firstOrNull { it.second == seed }?.first ?: "自定义"
        binding.tvThemeColor.text = name
        binding.themeDot.backgroundTintList = ColorStateList.valueOf(ThemeManager.tune(seed))
        binding.colorCard.alpha = if (ThemePrefs.dynamicColor) 0.5f else 1f
    }

    private fun showColorChooser() {
        val names = ThemePrefs.PRESETS.map { it.first }.toTypedArray()
        val current = ThemePrefs.PRESETS.indexOfFirst { it.second == ThemePrefs.fixedSeed }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.theme_color_title)
            .setSingleChoiceItems(names, current) { d: DialogInterface, which: Int ->
                ThemePrefs.fixedSeed = ThemePrefs.PRESETS[which].second
                ThemePrefs.dynamicColor = false
                ThemePrefs.apply(animate = true)
                binding.swDynamic.isChecked = false
                renderTheme()
                d.dismiss()
                toast(getString(R.string.theme_saved))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------- 播放源 / 音质 ----------------

    private fun renderSource() {
        binding.tvSource.text = when (Session.playSource) {
            "gdstudio" -> getString(R.string.source_gdstudio)
            else -> getString(R.string.source_netease)
        }
    }

    private fun showSourceChooser() {
        val labels = arrayOf(
            getString(R.string.source_netease),
            getString(R.string.source_gdstudio)
        )
        val values = arrayOf("netease", "gdstudio")
        val current = values.indexOf(Session.playSource).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.source_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                Session.playSource = values[which]
                renderSource()
                d.dismiss()
                toast(getString(R.string.source_saved))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /**
     * 音质条目。
     * ★ 不只显示「设置成什么」, 还显示「当前这首歌实际拿到什么」,
     *   一眼就能看出音质改动是否真的生效 (点条目可打开选择 + 音质自检)。
     */
    private fun renderQuality() {
        val picked = QualityDialogs.label(this, Session.quality)
        val actual = PlayerEngine.currentPlayInfo
        binding.tvQuality.text = if (actual == null) picked
        else "$picked（当前 ${QualityDialogs.nowPlayingText(this)}）"
    }

    private fun showQualityChooser() {
        val labels = arrayOf(
            getString(R.string.quality_standard),
            getString(R.string.quality_higher),
            getString(R.string.quality_exhigh),
            getString(R.string.quality_lossless),
            getString(R.string.quality_hires)
        )
        val values = arrayOf("standard", "higher", "exhigh", "lossless", "hires")
        val current = values.indexOf(Session.quality).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.quality_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                Session.quality = values[which]
                renderQuality()
                d.dismiss()
                toast(getString(R.string.quality_saved))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ---------------- 同步 / 定时状态 ----------------

    private fun renderSync() {
        val on = Session.syncPlayRecord
        binding.tvSyncDesc.text = if (on && Session.isLoggedIn()) {
            val t = Session.lastSyncTime
            if (t > 0) {
                val fmt = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
                getString(R.string.sync_desc) + "\n最近同步：${fmt.format(java.util.Date(t))}"
            } else {
                getString(R.string.sync_desc)
            }
        } else {
            getString(R.string.sync_desc)
        }
    }

    /**
     * 同步自检: 查一下「当前这首歌」在网易云听歌排行里的次数,
     * 这样能直接确认上报真的生效了 (而不仅仅是接口返回 200)。
     */
    private fun verifySync() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            toast("先在推荐页播放一首歌，再回来检测同步")
            return
        }
        if (!Session.isLoggedIn()) {
            toast(getString(R.string.sync_need_login))
            return
        }
        if (Session.uid <= 0) {
            toast("账号信息未就绪，请稍后重试")
            return
        }
        binding.tvSyncDesc.text = "正在查询《${song.name}》的听歌排行…"
        scope.launch {
            val count = withContext(Dispatchers.IO) {
                NeteaseApi.playCount(this@SettingsActivity, Session.uid, song.id)
            }
            renderSync()
            when {
                count < 0 -> toast("查询失败，请检查网络后重试")
                count == 0 -> toast("《${song.name}》还没有出现在听歌排行（多播一会儿再看）")
                else -> toast("《${song.name}》在网易云听歌排行中已播放 $count 次 ✅")
            }
        }
    }

    private fun renderTimer() {
        binding.tvTimerState.text = when {
            PlayScheduler.isEnabled(this) -> "定时播放：${PlayScheduler.label(this)}"
            PlayerEngine.hasSleepTimer() -> PlayerEngine.sleepLabel()
            else -> getString(R.string.timer_schedule_hint)
        }
    }

    private fun logout() {
        PlayerEngine.stopAndClear()
        LoginChecker.reset()
        Session.clearLiked()
        Session.clearLogin()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        openPage(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
