package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivitySettingsBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.aboutCard.setOnClickListener {
            openPage(Intent(this, AboutActivity::class.java))
        }
        binding.btnLogin.setOnClickListener {
            // Cookie 登录 (唯一登录方式)
            showLoginChooser()
        }
        binding.btnLogout.setOnClickListener { logout() }
        binding.btnRefreshVip.setOnClickListener { loadVip() }
        binding.qualityCard.setOnClickListener { showQualityChooser() }
        binding.sourceCard.setOnClickListener { showSourceChooser() }

        renderAccount()
        renderSource()
        renderQuality()
        loadVip()
    }

    override fun onResume() {
        super.onResume()
        renderAccount()
    }

    /** 未登录: 显示登录入口; 已登录: 显示账号信息 */
    private fun renderAccount() {
        val logged = Session.isLoggedIn()
        binding.loginCard.visibility = if (logged) View.GONE else View.VISIBLE
        binding.accountCard.visibility = if (logged) View.VISIBLE else View.GONE
        if (!logged) return
        binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
        binding.tvUid.text = "${getString(R.string.uid_label)}: ${Session.uid}"
        Glide.with(this)
            .load(Session.avatar)
            .placeholder(R.drawable.ic_account)
            .error(R.drawable.ic_account)
            .into(binding.avatar)
    }

    /** 选择登录方式: Cookie(推荐) / 扫码 / 手机号验证码 */
    /** 选择登录方式: Cookie 登录 (唯一方式) */
    private fun showLoginChooser() {
        openPage(Intent(this, LoginActivity::class.java))
    }

    private fun loadVip() {
        binding.tvVipStatus.text = getString(R.string.loading)
        binding.tvVipLevel.text = "--"
        binding.tvVipExpire.text = "--"
        scope.launch {
            val info = withContext(Dispatchers.IO) {
                NeteaseApi.vipInfo(this@SettingsActivity, Session.uid)
            }
            binding.tvVipStatus.text =
                if (info.isVip) getString(R.string.vip_yes) else getString(R.string.vip_no)
            binding.tvVipStatus.setTextColor(
                if (info.isVip) androidx.core.content.ContextCompat.getColor(this@SettingsActivity, R.color.net_red)
                else androidx.core.content.ContextCompat.getColor(this@SettingsActivity, R.color.namida_text_secondary)
            )
            binding.tvVipLevel.text = info.level.ifEmpty { "--" }
            binding.tvVipExpire.text = info.expireTime.ifEmpty { "--" }
        }
    }

    /** 默认播放源 */
    private fun renderSource() {
        binding.tvSource.text = when (Session.playSource) {
            "gdstudio" -> getString(R.string.source_gdstudio)
            else -> getString(R.string.source_netease)
        }
    }

    private fun showSourceChooser() {
        val labels = arrayOf(
            getString(R.string.source_netease),
            getString(R.string.source_gdstudio)
        )
        val values = arrayOf("netease", "gdstudio")
        val current = values.indexOf(Session.playSource).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.source_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                Session.playSource = values[which]
                renderSource()
                d.dismiss()
                toast(getString(R.string.source_saved))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /** 音质选择 */
    private fun renderQuality() {
        binding.tvQuality.text = when (Session.quality) {
            "standard" -> getString(R.string.quality_standard)
            "higher" -> getString(R.string.quality_higher)
            "exhigh" -> getString(R.string.quality_exhigh)
            "lossless" -> getString(R.string.quality_lossless)
            "hires" -> getString(R.string.quality_hires)
            else -> getString(R.string.quality_exhigh)
        }
    }

    private fun showQualityChooser() {
        val labels = arrayOf(
            getString(R.string.quality_standard),
            getString(R.string.quality_higher),
            getString(R.string.quality_exhigh),
            getString(R.string.quality_lossless),
            getString(R.string.quality_hires)
        )
        val values = arrayOf("standard", "higher", "exhigh", "lossless", "hires")
        val current = values.indexOf(Session.quality).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.quality_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                Session.quality = values[which]
                renderQuality()
                d.dismiss()
                toast(getString(R.string.quality_saved))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun logout() {
        PlayerEngine.stopAndClear()
        Session.clearLiked()
        Session.clearLogin()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        openPage(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
