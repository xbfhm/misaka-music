package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivitySettingsBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayScheduler
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.ThemeManager
import com.xbfhm.misakamusic.theme.ThemePrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        binding.btnBack.setOnClickListener { finish() }
        binding.aboutCard.setOnClickListener {
            openPage(Intent(this, AboutActivity::class.java), singleTop = true)
        }
        binding.btnLogin.setOnClickListener {
            openPage(Intent(this, LoginActivity::class.java), singleTop = true)
        }
        binding.btnLogout.setOnClickListener { logout() }
        binding.btnRefreshVip.setOnClickListener { loadVip() }
        binding.btnCheckLogin.setOnClickListener { checkLogin() }
        binding.qualityCard.setOnClickListener { showQualityChooser() }
        binding.sourceCard.setOnClickListener { showSourceChooser() }
        binding.timerCard.setOnClickListener { TimerDialogs.show(this) }

        // 动态取色开关
        binding.swDynamic.isChecked = ThemePrefs.dynamicColor
        binding.swDynamic.setOnCheckedChangeListener { _, checked ->
            ThemePrefs.dynamicColor = checked
            ThemePrefs.apply(animate = true)
            renderTheme()
            toast(
                if (checked) getString(R.string.theme_dynamic_desc)
                else getString(R.string.theme_locked)
            )
        }
        binding.colorCard.setOnClickListener { showColorChooser() }
        binding.colorCard.alpha = if (ThemePrefs.dynamicColor) 0.5f else 1f

        // 听歌记录同步开关
        binding.swSync.isChecked = Session.syncPlayRecord
        binding.swSync.setOnCheckedChangeListener { _, checked ->
            Session.syncPlayRecord = checked
            renderSync()
            if (checked && !Session.isLoggedIn()) toast(getString(R.string.sync_need_login))
        }

        renderAccount()
        renderSource()
        renderQuality()
        renderTheme()
        renderSync()
        renderTimer()
        loadVip()
    }

    override fun onResume() {
        super.onResume()
        renderAccount()
        renderTimer()
    }

    /** 未登录: 显示登录入口; 已登录: 显示账号信息 */
    private fun renderAccount() {
        val logged = Session.isLoggedIn()
        binding.loginCard.visibility = if (logged) View.GONE else View.VISIBLE
        binding.accountCard.visibility = if (logged) View.VISIBLE else View.GONE
        if (!logged) return
        binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
        binding.tvUid.text = "${getString(R.string.uid_label)}: ${Session.uid}"
        Glide.with(this)
            .load(Session.avatar)
            .placeholder(R.drawable.ic_account)
            .error(R.drawable.ic_account)
            .into(binding.avatar)
    }

    /**
     * 检测登录状态: Cookie 失效时明确告知 (而不是让歌单/收藏莫名其妙失败)。
     */
    private fun checkLogin() {
        if (!Session.isLoggedIn()) {
            toast(getString(R.string.login_none))
            return
        }
        binding.btnCheckLogin.isEnabled = false
        binding.tvLoginStatus.visibility = View.VISIBLE
        binding.tvLoginStatus.text = getString(R.string.login_checking)
        scope.launch {
            val st = try {
                LoginChecker.check(this@SettingsActivity, force = true)
            } catch (e: Exception) {
                LoginChecker.State.OFFLINE
            }
            binding.btnCheckLogin.isEnabled = true
            binding.tvLoginStatus.text = when (st) {
                LoginChecker.State.VALID ->
                    getString(R.string.login_valid_fmt, Session.nickname, Session.uid)
                LoginChecker.State.INVALID ->
                    getString(R.string.login_invalid_fmt, LoginChecker.lastMessage)
                LoginChecker.State.OFFLINE ->
                    getString(R.string.login_offline_fmt, LoginChecker.lastMessage)
                else -> getString(R.string.login_none)
            }
            if (st == LoginChecker.State.INVALID) {
                renderAccount()
                MaterialAlertDialogBuilder(this@SettingsActivity)
                    .setTitle(R.string.login_expired_title)
                    .setMessage(getString(R.string.login_expired_message, LoginChecker.lastMessage))
                    .setPositiveButton(R.string.relogin) { _, _ ->
                        openPage(Intent(this@SettingsActivity, LoginActivity::class.java), singleTop = true)
                    }
                    .setNegativeButton(R.string.later, null)
                    .show()
            }
        }
    }

    private fun loadVip() {
        if (!Session.isLoggedIn()) return
        binding.tvVipStatus.text = getString(R.string.loading)
        binding.tvVipLevel.text = "--"
        binding.tvVipExpire.text = "--"
        scope.launch {
            val info = withContext(Dispatchers.IO) {
                NeteaseApi.vipInfo(this@SettingsActivity, Session.uid)
            }
            binding.tvVipStatus.text =
                if (info.isVip) getString(R.string.vip_yes) else getString(R.string.vip_no)
            binding.tvVipStatus.setTextColor(ThemeManager.primary)
            binding.tvVipLevel.text = info.level.ifEmpty { "--" }
            binding.tvVipExpire.text = info.expireTime.ifEmpty { "--" }
        }
    }

    // ---------------- 主题 ----------------

    private fun renderTheme() {
        val seed = ThemePrefs.fixedSeed
        val name = ThemePrefs.PRESETS.firstOrNull { it.second == seed }?.first ?: "自定义"
        binding.tvThemeColor.text = name
        binding.themeDot.backgroundTintList = ColorStateList.valueOf(ThemeManager.tune(seed))
        binding.colorCard.alpha = if (ThemePrefs.dynamicColor) 0.5f else 1f
    }

    private fun showColorChooser() {
        val names = ThemePrefs.PRESETS.map { it.first }.toTypedArray()
        val current = ThemePrefs.PRESETS.indexOfFirst { it.second == ThemePrefs.fixedSeed }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.theme_color_title)
            .setSingleChoiceItems(names, current) { d: DialogInterface, which: Int ->
                ThemePrefs.fixedSeed = ThemePrefs.PRESETS[which].second
                ThemePrefs.dynamicColor = false
                ThemePrefs.apply(animate = true)
                binding.swDynamic.isChecked = false
                renderTheme()
                d.dismiss()
                toast(getString(R.string.theme_saved))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------- 播放源 / 音质 ----------------

    private fun renderSource() {
        binding.tvSource.text = when (Session.playSource) {
            "gdstudio" -> getString(R.string.source_gdstudio)
            else -> getString(R.string.source_netease)
        }
    }

    private fun showSourceChooser() {
        val labels = arrayOf(
            getString(R.string.source_netease),
            getString(R.string.source_gdstudio)
        )
        val values = arrayOf("netease", "gdstudio")
        val current = values.indexOf(Session.playSource).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.source_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                Session.playSource = values[which]
                renderSource()
                d.dismiss()
                toast(getString(R.string.source_saved))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun renderQuality() {
        binding.tvQuality.text = when (Session.quality) {
            "standard" -> getString(R.string.quality_standard)
            "higher" -> getString(R.string.quality_higher)
            "exhigh" -> getString(R.string.quality_exhigh)
            "lossless" -> getString(R.string.quality_lossless)
            "hires" -> getString(R.string.quality_hires)
            else -> getString(R.string.quality_exhigh)
        }
    }

    private fun showQualityChooser() {
        val labels = arrayOf(
            getString(R.string.quality_standard),
            getString(R.string.quality_higher),
            getString(R.string.quality_exhigh),
            getString(R.string.quality_lossless),
            getString(R.string.quality_hires)
        )
        val values = arrayOf("standard", "higher", "exhigh", "lossless", "hires")
        val current = values.indexOf(Session.quality).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.quality_title))
            .setSingleChoiceItems(labels, current) { d: DialogInterface, which: Int ->
                Session.quality = values[which]
                renderQuality()
                d.dismiss()
                toast(getString(R.string.quality_saved))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ---------------- 同步 / 定时状态 ----------------

    private fun renderSync() {
        val on = Session.syncPlayRecord
        binding.tvSyncDesc.text = if (on && Session.isLoggedIn()) {
            val t = Session.lastSyncTime
            if (t > 0) {
                val fmt = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
                getString(R.string.sync_desc) + "\n最近同步：${fmt.format(java.util.Date(t))}"
            } else {
                getString(R.string.sync_desc)
            }
        } else {
            getString(R.string.sync_desc)
        }
    }

    private fun renderTimer() {
        binding.tvTimerState.text = when {
            PlayScheduler.isEnabled(this) -> "定时播放：${PlayScheduler.label(this)}"
            PlayerEngine.hasSleepTimer() -> PlayerEngine.sleepLabel()
            else -> getString(R.string.timer_schedule_hint)
        }
    }

    private fun logout() {
        PlayerEngine.stopAndClear()
        LoginChecker.reset()
        Session.clearLiked()
        Session.clearLogin()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        openPage(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
