package com.xbfhm.misakamusic.net

import android.content.Context
import com.xbfhm.misakamusic.model.PlayUrlInfo
import com.xbfhm.misakamusic.util.Logger
import org.json.JSONObject

/**
 * GDStudio 开源聚合 API 客户端 (免费音源)
 *
 * 接口: https://music-api.gdstudio.xyz/api.php  (GitHub 开源项目)
 * 特点: 直接复用网易云歌曲 ID 换取直链, 无需登录 / 无需会员即可播放。
 *      因此登录网易云拿到的歌单/我喜欢, 都能用这个免费源播放。
 *
 * 支持 source=netease / joox, 这里固定用 netease 以复用歌曲 ID。
 */
object GdApi {

    private const val BASE = "https://music-api.gdstudio.xyz/api.php"

    private const val UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    /**
     * 按 App 音质偏好映射到 GDStudio 的 br 参数。
     * GDStudio 常用档位: 999(无损/FLAC) / 320 / 192 / 128
     */
    private fun qualityOrder(quality: String): List<String> = when (quality) {
        "standard" -> listOf("128", "192", "320")
        "higher" -> listOf("192", "320", "128")
        "lossless", "hires" -> listOf("999", "320", "192", "128")
        else -> listOf("320", "192", "128")
    }

    /** br 数值 -> 网易云等价档位 (用于和设置里的档位比较) */
    private fun levelOf(br: Int): String = when {
        br >= 900 -> "lossless"
        br >= 300 -> "exhigh"
        br >= 180 -> "higher"
        else -> "standard"
    }

    /**
     * 解析可播放直链, 按音质由高到低逐档尝试, 全部失败返回 null。
     * 返回结果里带上真实的 br / size, 界面可以据此显示「实际音质」。
     */
    fun resolvePlayUrl(ctx: Context, id: Long, quality: String): PlayUrlInfo? {
        for (br in qualityOrder(quality)) {
            try {
                val info = fetchUrl(id, br, quality)
                if (info != null) return info
            } catch (e: Exception) {
                Logger.log("GdApi", "获取直链失败 id=$id br=$br: ${e.message}")
            }
        }
        Logger.log("GdApi", "免费源无可用直链 id=$id")
        return null
    }

    /** 单次请求: types=url&source=netease&id=xx&br=xx -> {"url":"...","br":320,"size":...} */
    private fun fetchUrl(id: Long, br: String, requested: String): PlayUrlInfo? {
        val url = "$BASE?types=url&source=netease&id=$id&br=$br"
        val resp = Http.get(url, null, mapOf("User-Agent" to UA))
        if (resp.httpCode != 200) return null
        val j = try {
            JSONObject(resp.body)
        } catch (_: Exception) {
            return null
        }
        // 无版权/无资源时会返回 url 为空字符串或 null
        val real = j.optString("url", "")
        if (real.isBlank()) return null
        val realBr = j.optInt("br", br.toIntOrNull() ?: 0)
        return PlayUrlInfo(
            url = real,
            level = levelOf(realBr),
            br = realBr,
            size = j.optLong("size", 0L),
            source = "gdstudio",
            requested = requested
        )
    }
}