package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLoginBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 登录页 (仅 Cookie 登录)
 * 从浏览器/官方 App 复制完整 Cookie 粘贴即可
 */
class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Session.isLoggedIn()) {
            Logger.log("Login", "已登录, uid=${Session.uid}, 跳转主页")
            goMain()
            return
        }

        binding.btnCookieTutorial.setOnClickListener {
            openPage(Intent(this, CookieTutorialActivity::class.java))
        }
        binding.btnCookieImport.setOnClickListener { importCookie() }
    }

    private fun importCookie() {
        val raw = binding.etCookie.text.toString().trim()
        if (raw.isEmpty()) {
            toast(getString(R.string.cookie_empty))
            return
        }
        Logger.log("Login", "开始 Cookie 登录, 输入长度=${raw.length}")

        // 解析 cookie
        Session.absorbCookieString(raw)

        if (!Session.has("MUSIC_U")) {
            Logger.log("Login", "缺少 MUSIC_U")
            toast(getString(R.string.cookie_need_music_u))
            return
        }

        val musicU = Session.get("MUSIC_U") ?: ""
        Logger.log("Login", "MUSIC_U 长度=${musicU.length}, 前8位=${musicU.take(8)}...")

        binding.btnCookieImport.isEnabled = false
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            Logger.log("Login", "afterLogin 结果: $ok, uid=${Session.uid}, nickname=${Session.nickname}")
            if (!ok) {
                binding.btnCookieImport.isEnabled = true
                toast(getString(R.string.cookie_fail))
                return@launch
            }
            Session.clearLiked()
            toast(getString(R.string.cookie_success))
            goMain()
        }
    }

    private fun goMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        openPage(intent)
        finish()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
