package com.xbfhm.misakamusic.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.tabs.TabLayout
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLoginBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * 登录页
 *
 *  1. **扫码登录 (默认)** —— 向网易云申请网页版登录二维码 (内容为
 *     `https://music.163.com/login?codekey=<unikey>`), 用手机网易云音乐 App
 *     扫码并确认, 服务器随响应下发 MUSIC_U, App 自动收下 Cookie 完成登录。
 *     同一部手机可以点「保存二维码到相册」, 再用网易云「扫一扫 › 相册」识别。
 *  2. **Cookie 登录 (备用)** —— 粘贴浏览器 Cookie, 导入时立即校验登录态。
 */
class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var pollJob: Job? = null
    private var keyJob: Job? = null
    private var qrKey: String? = null
    private var qrBitmap: Bitmap? = null
    private var finished = false
    private var pollType = 3
    /** 距二维码过期的剩余秒数 (用于界面倒计时) */
    private var expireIn = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        if (Session.isLoggedIn()) {
            Logger.log("Login", "已登录, uid=${Session.uid}, 直接进入主页")
            goMain()
            return
        }

        setupTabs()
        binding.btnQrRefresh.setOnClickListener { startQrFlow() }
        binding.btnQrSave.setOnClickListener { saveQr() }
        binding.btnCookieTutorial.setOnClickListener {
            startActivity(Intent(this, CookieTutorialActivity::class.java))
        }
        binding.btnCookieImport.setOnClickListener { importCookie() }
        binding.btnCookieCheck.setOnClickListener { checkLoginManually() }
    }

    // ================= 扫码登录 =================

    private fun setupTabs() {
        binding.tabLogin.addTab(binding.tabLogin.newTab().setText(R.string.tab_qr_login), true)
        binding.tabLogin.addTab(binding.tabLogin.newTab().setText(R.string.tab_cookie))
        binding.tabLogin.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = switchTab(tab.position)
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        switchTab(0)
    }

    private fun switchTab(idx: Int) {
        binding.qrPanel.visibility = if (idx == 0) View.VISIBLE else View.GONE
        binding.cookiePanel.visibility = if (idx == 1) View.VISIBLE else View.GONE
        if (idx == 0) {
            if (qrKey == null) startQrFlow()
        } else {
            stopPoll()
        }
    }

    /** 获取 unikey -> 生成网页版二维码 -> 轮询扫码结果 */
    private fun startQrFlow() {
        if (finished) return
        stopPoll()
        keyJob?.cancel()
        qrKey = null
        qrBitmap = null
        binding.ivQr.setImageDrawable(null)
        binding.qrLoading.visibility = View.VISIBLE
        binding.btnQrSave.isEnabled = false
        binding.tvQrStatus.text = getString(R.string.qr_fetching)
        binding.btnQrRefresh.visibility = View.GONE

        keyJob = scope.launch {
            var type = 3
            var key = withContext(Dispatchers.IO) { safeQrKey(type) }
            if (key.isNullOrEmpty()) {
                // 兼容回退: 部分账号/地区只认 type=1
                type = 1
                key = withContext(Dispatchers.IO) { safeQrKey(type) }
            }
            if (finished) return@launch
            if (key.isNullOrEmpty()) {
                Logger.log("Login", "获取二维码 unikey 失败")
                binding.qrLoading.visibility = View.GONE
                binding.tvQrStatus.text = getString(R.string.qr_failed)
                binding.btnQrRefresh.visibility = View.VISIBLE
                return@launch
            }
            pollType = type
            qrKey = key
            Logger.log("Login", "unikey(type=$type)=${key.take(8)}…")
            val content = "https://music.163.com/login?codekey=$key"
            val bmp = withContext(Dispatchers.Default) { QrGen.generate(content, 560) }
            if (finished) return@launch
            qrBitmap = bmp
            binding.ivQr.setImageBitmap(bmp)
            binding.qrLoading.visibility = View.GONE
            binding.btnQrSave.isEnabled = true
            binding.tvQrStatus.text = getString(R.string.qr_waiting)
            expireIn = QR_TTL_SEC
            startPoll(key)
            startCountdown()
        }
    }

    private fun safeQrKey(type: Int): String? = try {
        NeteaseApi.qrKey(this, type)
    } catch (e: Exception) {
        Logger.log("Login", "qrKey(type=$type) 异常: ${e.message}")
        null
    }

    private fun startPoll(key: String) {
        pollJob?.cancel()
        pollJob = scope.launch {
            var scanned = false
            while (isActive && !finished) {
                delay(2500)
                val res = withContext(Dispatchers.IO) {
                    try {
                        NeteaseApi.qrCheck(this@LoginActivity, key, pollType)
                    } catch (e: Exception) {
                        Logger.log("Login", "qrCheck 异常: ${e.message}")
                        JSONObject()
                    }
                }
                if (finished) return@launch
                when (res.optInt("code", -1)) {
                    800 -> {
                        Logger.log("Login", "二维码已过期")
                        binding.tvQrStatus.text = getString(R.string.qr_expired)
                        binding.btnQrRefresh.visibility = View.VISIBLE
                        return@launch
                    }
                    801 -> { /* 等待扫码 */ }
                    802 -> {
                        if (!scanned) {
                            scanned = true
                            Logger.log("Login", "已扫码, 等待手机确认")
                            binding.tvQrStatus.text = getString(R.string.qr_scanned)
                        }
                    }
                    803 -> {
                        Logger.log("Login", "扫码授权成功")
                        onQrAuthorized(res)
                        return@launch
                    }
                }
            }
        }
    }

    /** 二维码有效期倒计时, 到点前 10 秒自动换一张 (和网页版行为一致) */
    private fun startCountdown() {
        scope.launch {
            while (isActive && !finished) {
                delay(1000)
                if (binding.qrPanel.visibility != View.VISIBLE) continue
                expireIn--
                if (expireIn <= 0) return@launch
                if (expireIn <= 10 && binding.btnQrRefresh.visibility != View.VISIBLE) {
                    binding.tvQrStatus.text = "二维码即将过期，正在自动刷新…"
                    startQrFlow()
                    return@launch
                }
            }
        }
    }

    private fun onQrAuthorized(res: JSONObject) {
        // 部分版本会把 cookie 直接放在响应体里, 一起吸收 (Set-Cookie 已由网络层自动收下)
        res.optString("cookie", "").takeIf { it.isNotBlank() }?.let {
            Session.absorbCookieString(it)
        }
        binding.tvQrStatus.text = getString(R.string.loading)
        stopPoll()
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            if (finished) return@launch
            if (ok) {
                LoginChecker.reset()
                Session.clearLiked()
                toast(getString(R.string.qr_success_toast))
                goMain()
            } else {
                Logger.log("Login", "扫码后校验失败, MUSIC_U=${Session.has("MUSIC_U")}")
                binding.tvQrStatus.text = getString(R.string.cookie_fail)
                binding.btnQrRefresh.visibility = View.VISIBLE
            }
        }
    }

    private fun saveQr() {
        if (qrBitmap == null) {
            toast(getString(R.string.qr_save_empty))
            return
        }
        // Android 9 及以下写相册需要存储权限
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1002
            )
            return
        }
        doSaveQr()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1002) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doSaveQr()
            } else {
                toast(getString(R.string.qr_save_fail))
            }
        }
    }

    private fun doSaveQr() {
        val bmp = qrBitmap ?: return
        val path = QrSaver.saveToGallery(this, bmp)
        if (path != null) {
            toast(getString(R.string.qr_saved, path))
        } else {
            toast(getString(R.string.qr_save_fail))
        }
    }

    private fun stopPoll() {
        pollJob?.cancel()
        pollJob = null
    }

    // ================= Cookie 登录 =================

    private fun importCookie() {
        val raw = binding.etCookie.text.toString().trim()
        if (raw.isEmpty()) {
            toast(getString(R.string.cookie_empty))
            return
        }
        Logger.log("Login", "开始 Cookie 登录, 输入长度=${raw.length}")
        Session.absorbCookieString(raw)
        if (!Session.has("MUSIC_U")) {
            Logger.log("Login", "Cookie 中缺少 MUSIC_U")
            toast(getString(R.string.cookie_need_music_u))
            return
        }
        binding.btnCookieImport.isEnabled = false
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            Logger.log("Login", "afterLogin 结果: $ok, uid=${Session.uid}")
            binding.btnCookieImport.isEnabled = true
            if (finished) return@launch
            if (!ok) {
                toast(getString(R.string.cookie_fail))
                return@launch
            }
            LoginChecker.reset()
            Session.clearLiked()
            toast(getString(R.string.cookie_success))
            goMain()
        }
    }

    /** Cookie 登录状态检测: 明确告诉用户 Cookie 是否还有效 */
    private fun checkLoginManually() {
        if (!Session.isLoggedIn()) {
            val raw = binding.etCookie.text.toString().trim()
            if (raw.isBlank()) {
                toast(getString(R.string.login_check_need_cookie))
                return
            }
            Session.absorbCookieString(raw)
        }
        binding.btnCookieCheck.isEnabled = false
        binding.tvCookieStatus.visibility = View.VISIBLE
        binding.tvCookieStatus.text = getString(R.string.login_checking)
        scope.launch {
            val st = try {
                LoginChecker.check(this@LoginActivity, force = true)
            } catch (e: Exception) {
                Logger.log("Login", "登录检测异常: ${e.message}")
                LoginChecker.State.OFFLINE
            }
            binding.btnCookieCheck.isEnabled = true
            if (finished) return@launch
            binding.tvCookieStatus.text = when (st) {
                LoginChecker.State.VALID ->
                    getString(R.string.login_valid_fmt, Session.nickname, Session.uid)
                LoginChecker.State.INVALID -> getString(R.string.login_invalid_fmt, LoginChecker.lastMessage)
                LoginChecker.State.OFFLINE -> getString(R.string.login_offline_fmt, LoginChecker.lastMessage)
                else -> getString(R.string.login_none)
            }
            toast(binding.tvCookieStatus.text.toString())
        }
    }

    private fun goMain() {
        finished = true
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        openPage(intent)
        finish()
    }

    override fun onDestroy() {
        finished = true
        stopPoll()
        keyJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        /** 二维码有效期 (秒) */
        private const val QR_TTL_SEC = 180
    }
}
