package com.xbfhm.misakamusic.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.tabs.TabLayout
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLoginBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * 登录页
 *
 *  1. **网页登录 (默认, 推荐)** —— 打开内置的网易云官方网页登录页
 *     ([WebLoginActivity]): 扫码 / 手机号验证码 / 邮箱密码 都能登, 登录成功后
 *     从 WebView 的 CookieStore 直接抓 MUSIC_U, 自动完成 Cookie 登录。
 *  2. **内置二维码** —— 向网易云申请网页版登录二维码 (内容为
 *     `https://music.163.com/login?codekey=<unikey>`), 扫码确认后收下 MUSIC_U。
 *     同一部手机可以点「保存二维码到相册」, 再用网易云「扫一扫 › 相册」识别。
 *  3. **Cookie 登录 (手动, 备用)** —— 粘贴浏览器 Cookie, 导入时立即校验登录态。
 */
class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var pollJob: Job? = null
    private var keyJob: Job? = null
    private var countdownJob: Job? = null
    private var qrKey: String? = null
    private var qrBitmap: Bitmap? = null
    private var finished = false
    private var pollType = 3
    /** 当前 unikey 是网页通道拿的 (true) 还是 eapi 通道拿的 (false) */
    private var pollWeb = true
    /** 距二维码过期的剩余秒数 (用于界面倒计时) */
    private var expireIn = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        if (Session.isLoggedIn()) {
            Logger.log("Login", "已登录, uid=${Session.uid}, 直接进入主页")
            goMain()
            return
        }

        setupTabs()
        binding.btnWebLogin.setOnClickListener {
            startActivityForResult(Intent(this, WebLoginActivity::class.java), REQ_WEB_LOGIN)
        }
        binding.btnQrRefresh.setOnClickListener { startQrFlow() }
        binding.btnQrSave.setOnClickListener { saveQr() }
        binding.btnCookieTutorial.setOnClickListener {
            startActivity(Intent(this, CookieTutorialActivity::class.java))
        }
        binding.btnCookieImport.setOnClickListener { importCookie() }
        binding.btnCookieCheck.setOnClickListener { checkLoginManually() }
    }

    // ================= 扫码登录 =================

    private fun setupTabs() {
        binding.tabLogin.addTab(binding.tabLogin.newTab().setText(R.string.tab_qr_login), true)
        binding.tabLogin.addTab(binding.tabLogin.newTab().setText(R.string.tab_cookie))
        binding.tabLogin.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = switchTab(tab.position)
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        switchTab(0)
    }

    private fun switchTab(idx: Int) {
        binding.qrPanel.visibility = if (idx == 0) View.VISIBLE else View.GONE
        binding.cookiePanel.visibility = if (idx == 1) View.VISIBLE else View.GONE
        if (idx == 0) {
            if (qrKey == null) startQrFlow()
        } else {
            stopPoll()
        }
    }

    /** 获取 unikey -> 生成网页版二维码 -> 轮询扫码结果 */
    private fun startQrFlow() {
        if (finished) return
        stopPoll()
        keyJob?.cancel()
        qrKey = null
        qrBitmap = null
        binding.ivQr.setImageDrawable(null)
        binding.qrLoading.visibility = View.VISIBLE
        binding.btnQrSave.isEnabled = false
        binding.tvQrStatus.text = getString(R.string.qr_fetching)
        binding.btnQrRefresh.visibility = View.GONE

        keyJob = scope.launch {
            // ① 优先走网页通道 (与 music.163.com 登录页同源, 不需要 eapi 加密)
            var web = true
            var type = 1
            // 网页通道 (type=1) 就是网易云网页版登录二维码:
            // 二维码内容 https://music.163.com/login?codekey=xxx, 手机 App 扫码后确认登录的是「网页版」,
            // 轮询 803 时 Set-Cookie 会带回 MUSIC_U —— 这才是真正的 Cookie 登录。
            // 网络抖动时重试 3 次, 尽量不退回 eapi 通道 (那是手机客户端通道, 不是网页版)
            var key: String? = ""
            for (attempt in 1..3) {
                key = withContext(Dispatchers.IO) {
                    try {
                        NeteaseApi.qrKeyWeb()
                    } catch (e: Exception) {
                        Logger.log("Login", "qrKeyWeb 异常($attempt): ${e.message}")
                        ""
                    }
                }
                if (!key.isNullOrEmpty()) break
                delay(500)
            }
            // ② eapi 通道兜底
            if (key.isNullOrEmpty()) {
                web = false
                type = 3
                key = withContext(Dispatchers.IO) { safeQrKey(type) }
            }
            if (key.isNullOrEmpty()) {
                type = 1
                key = withContext(Dispatchers.IO) { safeQrKey(type) }
            }
            if (finished) return@launch
            if (key.isNullOrEmpty()) {
                Logger.log("Login", "获取二维码 unikey 失败")
                binding.qrLoading.visibility = View.GONE
                binding.tvQrStatus.text = getString(R.string.qr_failed)
                binding.btnQrRefresh.visibility = View.VISIBLE
                return@launch
            }
            pollType = type
            pollWeb = web
            qrKey = key
            Logger.log("Login", "unikey(channel=${if (web) "web" else "eapi"}, type=$type)=${key.take(8)}…")
            val content = "https://music.163.com/login?codekey=$key"
            val bmp = withContext(Dispatchers.Default) { QrGen.generate(content, 560) }
            if (finished) return@launch
            qrBitmap = bmp
            binding.ivQr.setImageBitmap(bmp)
            binding.qrLoading.visibility = View.GONE
            binding.btnQrSave.isEnabled = true
            binding.tvQrStatus.text = getString(R.string.qr_waiting)
            expireIn = QR_TTL_SEC
            startPoll(key)
            startCountdown()
        }
    }

    private fun safeQrKey(type: Int): String? = try {
        NeteaseApi.qrKey(this, type)
    } catch (e: Exception) {
        Logger.log("Login", "qrKey(type=$type) 异常: ${e.message}")
        null
    }

    private fun startPoll(key: String) {
        pollJob?.cancel()
        pollJob = scope.launch {
            var scanned = false
            while (isActive && !finished) {
                delay(2500)
                val poll = withContext(Dispatchers.IO) {
                    try {
                        if (pollWeb) NeteaseApi.qrCheckWeb(key)
                        else NeteaseApi.QrPoll(NeteaseApi.qrCheck(this@LoginActivity, key, pollType), "")
                    } catch (e: Exception) {
                        Logger.log("Login", "qrCheck 异常: ${e.message}")
                        NeteaseApi.QrPoll(JSONObject(), "")
                    }
                }
                val res = poll.json
                if (finished) return@launch
                when (res.optInt("code", -1)) {
                    800 -> {
                        Logger.log("Login", "二维码已过期, 自动换一张")
                        binding.tvQrStatus.text = getString(R.string.qr_expired)
                        binding.btnQrRefresh.visibility = View.VISIBLE
                        delay(1200)
                        if (isActive && !finished) startQrFlow()
                        return@launch
                    }
                    801 -> { /* 等待扫码 */ }
                    802 -> {
                        if (!scanned) {
                            scanned = true
                            Logger.log("Login", "已扫码, 等待手机确认")
                            binding.tvQrStatus.text = getString(R.string.qr_scanned)
                        }
                    }
                    803 -> {
                        Logger.log("Login", "扫码授权成功, 收下 Set-Cookie")
                        if (onQrAuthorized(res, poll.cookies)) return@launch
                    }
                }
            }
        }
    }

    /** 二维码有效期倒计时, 到点前 10 秒自动换一张 (和网页版行为一致) */
    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = scope.launch {
            while (isActive && !finished) {
                delay(1000)
                if (binding.qrPanel.visibility != View.VISIBLE) continue
                expireIn--
                if (expireIn <= 0) return@launch
                if (expireIn <= 10 && binding.btnQrRefresh.visibility != View.VISIBLE) {
                    binding.tvQrStatus.text = "二维码即将过期，正在自动刷新…"
                    startQrFlow()
                    return@launch
                }
            }
        }
    }

    /** @return true = 已收下登录态并开始校验; false = 还没拿到 MUSIC_U, 继续轮询 */
    private fun onQrAuthorized(res: JSONObject, setCookies: String = ""): Boolean {
        // 1) 优先吸收 Set-Cookie 里的登录态 (网页扫码 803 的真正 payload)
        if (setCookies.isNotBlank()) Session.absorbCookieString(setCookies)
        // 2) 部分版本会把 cookie 直接放在响应体里, 一起吸收
        res.optString("cookie", "").takeIf { it.isNotBlank() }?.let {
            Session.absorbCookieString(it)
        }
        if (!Session.has("MUSIC_U")) {
            Logger.log("Login", "803 但未拿到 MUSIC_U, 继续等待下一次轮询")
            return false
        }
        // 网页通道下来的是浏览器身份, 设备字段要换回本机 App 的
        Session.normalizeDeviceCookies()
        binding.tvQrStatus.text = getString(R.string.loading)
        stopPoll()
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            if (finished) return@launch
            if (ok) {
                LoginChecker.reset()
                Session.clearLiked()
                toast(getString(R.string.qr_success_toast))
                goMain()
            } else {
                Logger.log("Login", "扫码后校验失败, MUSIC_U=${Session.has("MUSIC_U")}")
                binding.tvQrStatus.text = getString(R.string.cookie_fail)
                binding.btnQrRefresh.visibility = View.VISIBLE
            }
        }
        return true
    }

    private fun saveQr() {
        if (qrBitmap == null) {
            toast(getString(R.string.qr_save_empty))
            return
        }
        // Android 9 及以下写相册需要存储权限
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1002
            )
            return
        }
        doSaveQr()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1002) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doSaveQr()
            } else {
                toast(getString(R.string.qr_save_fail))
            }
        }
    }

    private fun doSaveQr() {
        val bmp = qrBitmap ?: return
        val path = QrSaver.saveToGallery(this, bmp)
        if (path != null) {
            toast(getString(R.string.qr_saved, path))
        } else {
            toast(getString(R.string.qr_save_fail))
        }
    }

    private fun stopPoll() {
        pollJob?.cancel()
        pollJob = null
    }

    // ================= Cookie 登录 =================

    private fun importCookie() {
        val raw = binding.etCookie.text.toString().trim()
        if (raw.isEmpty()) {
            toast(getString(R.string.cookie_empty))
            return
        }
        Logger.log("Login", "开始 Cookie 登录, 输入长度=${raw.length}")
        Session.absorbCookieString(raw)
        if (!Session.has("MUSIC_U")) {
            Logger.log("Login", "Cookie 中缺少 MUSIC_U")
            toast(getString(R.string.cookie_need_music_u))
            return
        }
        binding.btnCookieImport.isEnabled = false
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            Logger.log("Login", "afterLogin 结果: $ok, uid=${Session.uid}")
            binding.btnCookieImport.isEnabled = true
            if (finished) return@launch
            if (!ok) {
                toast(getString(R.string.cookie_fail))
                return@launch
            }
            LoginChecker.reset()
            Session.clearLiked()
            toast(getString(R.string.cookie_success))
            goMain()
        }
    }

    /** Cookie 登录状态检测: 明确告诉用户 Cookie 是否还有效 */
    private fun checkLoginManually() {
        if (!Session.isLoggedIn()) {
            val raw = binding.etCookie.text.toString().trim()
            if (raw.isBlank()) {
                toast(getString(R.string.login_check_need_cookie))
                return
            }
            Session.absorbCookieString(raw)
        }
        binding.btnCookieCheck.isEnabled = false
        binding.tvCookieStatus.visibility = View.VISIBLE
        binding.tvCookieStatus.text = getString(R.string.login_checking)
        scope.launch {
            val st = try {
                LoginChecker.check(this@LoginActivity, force = true)
            } catch (e: Exception) {
                Logger.log("Login", "登录检测异常: ${e.message}")
                LoginChecker.State.OFFLINE
            }
            binding.btnCookieCheck.isEnabled = true
            if (finished) return@launch
            binding.tvCookieStatus.text = when (st) {
                LoginChecker.State.VALID ->
                    getString(R.string.login_valid_fmt, Session.nickname, Session.uid)
                LoginChecker.State.INVALID -> getString(R.string.login_invalid_fmt, LoginChecker.lastMessage)
                LoginChecker.State.OFFLINE -> getString(R.string.login_offline_fmt, LoginChecker.lastMessage)
                else -> getString(R.string.login_none)
            }
            toast(binding.tvCookieStatus.text.toString())
        }
    }

    /** 内置网页登录返回: 已登录就直接进主页 */
    @Deprecated("startActivityForResult 兼容旧写法, 这里只用于网页登录回跳")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_WEB_LOGIN) return
        if (resultCode == RESULT_OK && Session.isLoggedIn()) {
            LoginChecker.reset()
            Session.clearLiked()
            goMain()
        }
    }

    private fun goMain() {
        finished = true
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        openPage(intent)
        finish()
    }

    override fun onDestroy() {
        finished = true
        stopPoll()
        keyJob?.cancel()
        countdownJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        /** 二维码有效期 (秒) */
        private const val QR_TTL_SEC = 240
        /** 内置网页登录的 requestCode */
        private const val REQ_WEB_LOGIN = 1001
    }
}
