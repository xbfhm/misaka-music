package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.google.android.material.tabs.TabLayout
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLoginBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * 登录页
 *  - 扫码登录(默认): App 内直接生成网易云官方二维码, 手机网易云 App 扫码授权, 自动获取 Cookie 并登录
 *  - Cookie 登录: 从浏览器/官方 App 复制完整 Cookie 粘贴
 */
class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var pollJob: Job? = null
    private var qrKey: String? = null
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Session.isLoggedIn()) {
            Logger.log("Login", "已登录, uid=${Session.uid}, 跳转主页")
            goMain()
            return
        }

        setupTabs()

        binding.btnQrRefresh.setOnClickListener { startQrFlow() }
        binding.btnCookieTutorial.setOnClickListener {
            openPage(Intent(this, CookieTutorialActivity::class.java))
        }
        binding.btnCookieImport.setOnClickListener { importCookie() }
    }

    // ================= 扫码登录 =================

    private fun setupTabs() {
        binding.tabLogin.addTab(
            binding.tabLogin.newTab().setText(R.string.tab_qr_login), true
        )
        binding.tabLogin.addTab(
            binding.tabLogin.newTab().setText(R.string.tab_cookie)
        )
        binding.tabLogin.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                switchTab(tab.position)
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        switchTab(0)
    }

    private fun switchTab(idx: Int) {
        binding.qrPanel.visibility = if (idx == 0) View.VISIBLE else View.GONE
        binding.cookiePanel.visibility = if (idx == 1) View.VISIBLE else View.GONE
        if (idx == 0) startQrFlow() else stopPoll()
    }

    /** 获取 unikey -> 生成二维码 -> 开始轮询 */
    private fun startQrFlow() {
        if (finished) return
        stopPoll()
        binding.ivQr.setImageDrawable(null)
        binding.qrLoading.visibility = View.VISIBLE
        binding.tvQrStatus.text = getString(R.string.qr_fetching)
        binding.btnQrRefresh.visibility = View.GONE

        scope.launch {
            val key = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.qrKey(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "qrKey 异常: ${e.message}")
                    ""
                }
            }
            if (key.isNullOrEmpty()) {
                Logger.log("Login", "获取二维码 key 失败")
                binding.qrLoading.visibility = View.GONE
                binding.tvQrStatus.text = getString(R.string.qr_failed)
                binding.btnQrRefresh.visibility = View.VISIBLE
                return@launch
            }
            qrKey = key
            Logger.log("Login", "获取到 unikey=${key.take(10)}...")
            val content = "https://music.163.com/login?codekey=$key"
            val bmp = withContext(Dispatchers.Default) {
                QrGen.generate(content, 560)
            }
            binding.ivQr.setImageBitmap(bmp)
            binding.qrLoading.visibility = View.GONE
            binding.tvQrStatus.text = getString(R.string.qr_waiting)
            startPoll(key)
        }
    }

    private fun startPoll(key: String) {
        pollJob = scope.launch {
            var scanned = false
            while (isActive && !finished) {
                delay(2000)
                val res = withContext(Dispatchers.IO) {
                    try {
                        NeteaseApi.qrCheck(this@LoginActivity, key)
                    } catch (e: Exception) {
                        Logger.log("Login", "qrCheck 异常: ${e.message}")
                        JSONObject()
                    }
                }
                when (res.optInt("code", -1)) {
                    800 -> {
                        Logger.log("Login", "二维码已过期")
                        binding.tvQrStatus.text = getString(R.string.qr_expired)
                        binding.btnQrRefresh.visibility = View.VISIBLE
                        return@launch
                    }
                    801 -> { /* 等待扫码 */ }
                    802 -> {
                        if (!scanned) {
                            scanned = true
                            Logger.log("Login", "已扫码, 等待确认")
                            binding.tvQrStatus.text = getString(R.string.qr_scanned)
                        }
                    }
                    803 -> {
                        Logger.log("Login", "扫码授权成功")
                        onQrAuthorized(res)
                        return@launch
                    }
                }
            }
        }
    }

    private fun onQrAuthorized(res: JSONObject) {
        // 兼容部分版本: 授权成功时响应体里带 cookie 字段
        res.optString("cookie", "").takeIf { it.isNotBlank() }?.let {
            Session.absorbCookieString(it)
        }
        binding.tvQrStatus.text = getString(R.string.loading)
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            if (ok) {
                Session.clearLiked()
                toast(getString(R.string.qr_success_toast))
                goMain()
            } else {
                Logger.log("Login", "扫码后校验失败")
                binding.tvQrStatus.text = getString(R.string.cookie_fail)
                binding.btnQrRefresh.visibility = View.VISIBLE
            }
        }
    }

    private fun stopPoll() {
        pollJob?.cancel()
        pollJob = null
    }

    // ================= Cookie 登录 =================

    private fun importCookie() {
        val raw = binding.etCookie.text.toString().trim()
        if (raw.isEmpty()) {
            toast(getString(R.string.cookie_empty))
            return
        }
        Logger.log("Login", "开始 Cookie 登录, 输入长度=${raw.length}")

        Session.absorbCookieString(raw)

        if (!Session.has("MUSIC_U")) {
            Logger.log("Login", "缺少 MUSIC_U")
            toast(getString(R.string.cookie_need_music_u))
            return
        }

        binding.btnCookieImport.isEnabled = false
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    NeteaseApi.afterLogin(this@LoginActivity)
                } catch (e: Exception) {
                    Logger.log("Login", "afterLogin 异常: ${e.message}")
                    false
                }
            }
            Logger.log("Login", "afterLogin 结果: $ok, uid=${Session.uid}")
            if (!ok) {
                binding.btnCookieImport.isEnabled = true
                toast(getString(R.string.cookie_fail))
                return@launch
            }
            Session.clearLiked()
            toast(getString(R.string.cookie_success))
            goMain()
        }
    }

    private fun goMain() {
        finished = true
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        openPage(intent)
        finish()
    }

    override fun onDestroy() {
        finished = true
        stopPoll()
        scope.cancel()
        super.onDestroy()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
