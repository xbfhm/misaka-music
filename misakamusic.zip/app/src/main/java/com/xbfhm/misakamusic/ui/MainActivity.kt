package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityMainBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.ThemeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding

    private val fragments: List<Fragment> = listOf(
        RecommendFragment(),
        PlaylistsFragment(),
        SearchFragment(),
        RankFragment(),
        MineFragment()
    )
    private var currentIndex = -1
    private var brandClickCount = 0
    private var brandClickTime = 0L
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var sessionDialogShown = false

    private lateinit var navButtons: List<ImageButton>
    private lateinit var navDots: List<View>
    private var themeListener: ThemeManager.Listener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        navButtons = listOf(
            binding.navBtn0, binding.navBtn1, binding.navBtn2, binding.navBtn3, binding.navBtn4
        )
        navDots = listOf(
            binding.navDot0, binding.navDot1, binding.navDot2, binding.navDot3, binding.navDot4
        )

        // 隐藏日志入口 (点品牌 5 次)
        binding.tvBrand.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - brandClickTime > 1500) brandClickCount = 0
            brandClickTime = now
            brandClickCount++
            if (brandClickCount >= 5) {
                brandClickCount = 0
                startActivity(Intent(this, LogActivity::class.java))
            }
        }

        binding.btnHistory.setOnClickListener {
            openPage(Intent(this, HistoryActivity::class.java), singleTop = true)
        }

        navButtons.forEachIndexed { index, btn ->
            btn.setOnClickListener { switchTab(index) }
        }

        // 主题变化时重刷导航选中色 (选中图标跟随动态主色)
        themeListener = ThemeManager.Listener { _, _ ->
            runOnUiThread { updateNavUI(currentIndex) }
        }
        ThemeManager.addListener(themeListener!!)

        binding.miniBar.setOnClickListener {
            openPageUp(Intent(this, PlayerActivity::class.java), singleTop = true)
        }
        binding.miniPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updateMiniPlayer()
        }
        binding.miniPrev.setOnClickListener {
            PlayerEngine.prev()
            updateMiniPlayer()
        }
        binding.miniNext.setOnClickListener {
            PlayerEngine.next()
            updateMiniPlayer()
        }

        switchTab(if (currentIndex >= 0) currentIndex else 0)
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { _ -> runOnUiThread { updateMiniPlayer() } }
        PlayerEngine.onPlayState = { runOnUiThread { updateMiniPlayer() } }
        updateMiniPlayer()
        startTicker()
        checkLoginState()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    override fun onDestroy() {
        themeListener?.let { ThemeManager.removeListener(it) }
        themeListener = null
        super.onDestroy()
    }

    // ---------------- 底部导航切换 ----------------

    private val fragmentTags = listOf(
        "tab_recommend", "tab_playlists", "tab_search", "tab_rank", "tab_mine"
    )

    /**
     * 切换 Tab (5 个)。
     * commitNowAllowingStateLoss 同步提交 + 下标幂等, 防止同一 Fragment 被重复添加。
     */
    private fun switchTab(index: Int) {
        if (index !in fragmentTags.indices) return
        if (index == currentIndex) {
            updateNavUI(index)
            return
        }
        val fm = supportFragmentManager
        if (fm.isDestroyed) return
        val tag = fragmentTags[index]
        val target = fm.findFragmentByTag(tag) ?: fragments[index]
        val tx = fm.beginTransaction()
        tx.setCustomAnimations(R.anim.fade_in, R.anim.fade_out, R.anim.fade_in, R.anim.fade_out)
        fm.fragments.forEach { f ->
            if (f.isAdded && f !== target && !f.isHidden) tx.hide(f)
        }
        if (target.isAdded) tx.show(target) else tx.add(R.id.fragmentContainer, target, tag)
        currentIndex = index
        try {
            tx.commitNowAllowingStateLoss()
        } catch (t: Throwable) {
            runCatching { tx.commitAllowingStateLoss() }
        }
        updateNavUI(index)
    }

    /**
     * 液态玻璃导航选中态:
     *  - 选中 = 主色图标 + 底部指示点 + 轻微放大
     *  - 未选中 = 次文字灰, 原尺寸
     */
    private fun updateNavUI(index: Int) {
        if (!::navButtons.isInitialized) return
        val inactive = ContextCompat.getColor(this, R.color.namida_text_tertiary)
        val active = ThemeManager.primary
        for (i in navButtons.indices) {
            val selected = i == index
            navButtons[i].setColorFilter(if (selected) active else inactive)
            navDots[i].visibility = if (selected) View.VISIBLE else View.GONE
            val scale = if (selected) 1.1f else 1f
            navButtons[i].animate().scaleX(scale).scaleY(scale)
                .setDuration(160).start()
        }
    }

    // ---------------- 登录态 ---------------- =================

    private fun checkLoginState() {
        if (!Session.isLoggedIn()) return
        scope.launch {
            val st = try {
                LoginChecker.check(this@MainActivity)
            } catch (_: Exception) {
                return@launch
            }
            if (st == LoginChecker.State.INVALID && !sessionDialogShown) {
                sessionDialogShown = true
                showSessionExpiredDialog(LoginChecker.lastMessage)
            }
        }
    }

    private fun showSessionExpiredDialog(reason: String) {
        if (isFinishing || isDestroyed) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.login_expired_title)
            .setMessage(getString(R.string.login_expired_message, reason))
            .setPositiveButton(R.string.relogin) { _, _ ->
                startActivity(Intent(this, LoginActivity::class.java))
            }
            .setNegativeButton(R.string.later, null)
            .show()
    }

    // ---------------- 迷你播放条 ---------------- =================

    private fun updateMiniPlayer() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            UiFx.slideOutBottom(binding.miniBar) { binding.miniBar.visibility = View.GONE }
            return
        }
        if (binding.miniBar.visibility != View.VISIBLE) {
            UiFx.slideInBottom(binding.miniBar)
        }
        binding.miniTitle.text = song.name
        binding.miniArtist.text = song.artists
        com.bumptech.glide.Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .into(binding.miniCover)
        ThemeManager.applyCover(this, song.cover)
        binding.miniProgress.setIndicatorColor(ThemeManager.primary)
        binding.miniPlay.setColorFilter(ThemeManager.primary)
        binding.miniPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
        if (PlayerEngine.hasSleepTimer()) {
            binding.miniTimer.visibility = View.VISIBLE
            binding.miniTimer.text = PlayerEngine.sleepLabel()
        } else {
            binding.miniTimer.visibility = View.GONE
        }
        val dur = song.duration.toInt().coerceAtLeast(1)
        binding.miniProgress.max = dur
        binding.miniProgress.setProgressCompat(
            PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
            true
        )
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                val song = PlayerEngine.currentSong() ?: continue
                val dur = song.duration.toInt().coerceAtLeast(1)
                binding.miniProgress.setProgressCompat(
                    PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
                    true
                )
                if (PlayerEngine.hasSleepTimer()) {
                    binding.miniTimer.visibility = View.VISIBLE
                    binding.miniTimer.text = PlayerEngine.sleepLabel()
                } else if (binding.miniTimer.visibility == View.VISIBLE) {
                    binding.miniTimer.visibility = View.GONE
                }
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
