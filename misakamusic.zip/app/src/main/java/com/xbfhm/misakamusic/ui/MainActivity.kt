package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityMainBinding
import com.xbfhm.misakamusic.net.LoginChecker
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.theme.ThemeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding

    private val fragments: List<Fragment> = listOf(
        RecommendFragment(),
        PlaylistsFragment(),
        SearchFragment()
    )
    private var currentIndex = -1
    /** 程序性同步选中项时抑制回调, 避免重复切换 */
    private var suppressNav = false
    private var brandClickCount = 0
    private var brandClickTime = 0L
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var sessionDialogShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindTheme()

        // 隐藏日志入口
        binding.tvBrand.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - brandClickTime > 1500) brandClickCount = 0
            brandClickTime = now
            brandClickCount++
            if (brandClickCount >= 5) {
                brandClickCount = 0
                startActivity(Intent(this, LogActivity::class.java))
            }
        }

        binding.btnSettings.setOnClickListener { openSettings() }
        binding.searchEntry.setOnClickListener { switchTab(2) }
        binding.avatar.setOnClickListener { openSettings() }

        // Material 3 NavigationBar 选中回调
        binding.bottomNavBar.setOnItemSelectedListener { item ->
            if (suppressNav) return@setOnItemSelectedListener true
            when (item.itemId) {
                R.id.nav_recommend -> switchTab(0)
                R.id.nav_playlists -> switchTab(1)
                R.id.nav_search -> switchTab(2)
            }
            true
        }

        binding.miniBar.setOnClickListener {
            openPageUp(Intent(this, PlayerActivity::class.java), singleTop = true)
        }
        binding.miniPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updateMiniPlayer()
        }
        binding.miniPrev.setOnClickListener {
            PlayerEngine.prev()
            updateMiniPlayer()
        }
        binding.miniNext.setOnClickListener {
            PlayerEngine.next()
            updateMiniPlayer()
        }

        updateHeader()
        switchTab(if (currentIndex >= 0) currentIndex else 0)
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { _ -> runOnUiThread { updateMiniPlayer() } }
        PlayerEngine.onPlayState = { runOnUiThread { updateMiniPlayer() } }
        updateMiniPlayer()
        updateHeader()
        startTicker()
        checkLoginState()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    // ---------------- 底部导航切换 ----------------

    private val fragmentTags = listOf("tab_recommend", "tab_playlists", "tab_search")

    /**
     * 切换 Tab。
     *
     * ★ 修复「重复页面」: 原实现用 commitAllowingStateLoss() (异步提交) 后再判断
     * `target.isAdded`, 连续两次点击同一个 Tab 时第二次判断时上一次还没执行完,
     * 于是同一个 Fragment 被 add 了两次, 界面上就出现两份列表叠在一起。
     * 现在改为 commitNowAllowingStateLoss() 同步提交 + 记住当前下标做幂等保护。
     */
    private fun switchTab(index: Int) {
        if (index !in fragmentTags.indices) return
        if (index == currentIndex) {
            // 已经是该页: 只同步一次导航选中态, 不做任何 Fragment 事务
            updateNavUI(index)
            binding.searchEntry.visibility = if (index == 2) View.GONE else View.VISIBLE
            return
        }
        val fm = supportFragmentManager
        if (fm.isDestroyed) return
        val tag = fragmentTags[index]
        val target = fm.findFragmentByTag(tag) ?: fragments[index]
        val tx = fm.beginTransaction()
        tx.setCustomAnimations(R.anim.fade_in, R.anim.fade_out, R.anim.fade_in, R.anim.fade_out)
        fm.fragments.forEach { f ->
            if (f.isAdded && f !== target && !f.isHidden) tx.hide(f)
        }
        if (target.isAdded) tx.show(target) else tx.add(R.id.fragmentContainer, target, tag)
        currentIndex = index
        try {
            // 同步提交: 保证下一次点击时状态已经生效, 不会把同一个 Fragment 加两次
            tx.commitNowAllowingStateLoss()
        } catch (t: Throwable) {
            // 极端情况(如 FragmentManager 正在执行事务)退化为异步提交
            runCatching { tx.commitAllowingStateLoss() }
        }
        updateNavUI(index)
        binding.searchEntry.visibility = if (index == 2) View.GONE else View.VISIBLE
    }

    /**
     * Material 3 NavigationBar: 同步选中项
     * 图标/文字着色由 ThemeManager 统一处理 (选中=动态主色)。
     */
    private fun updateNavUI(index: Int) {
        val targetId = when (index) {
            0 -> R.id.nav_recommend
            1 -> R.id.nav_playlists
            else -> R.id.nav_search
        }
        if (binding.bottomNavBar.selectedItemId != targetId) {
            suppressNav = true
            binding.bottomNavBar.selectedItemId = targetId
            suppressNav = false
        }
    }

    // ---------------- 头部/登录态 ----------------

    private fun updateHeader() {
        if (Session.isLoggedIn()) {
            binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
            binding.avatar.visibility = View.VISIBLE
            Glide.with(this)
                .load(Session.avatar)
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .into(binding.avatar)
        } else {
            binding.tvNickname.text = getString(R.string.not_logged_in)
            binding.avatar.visibility = View.GONE
        }
    }

    /**
     * 登录态自检: Cookie 失效时明确提示重新登录, 而不是让歌单/收藏默默失败。
     */
    private fun checkLoginState() {
        if (!Session.isLoggedIn()) {
            updateHeader()
            return
        }
        scope.launch {
            val st = try {
                LoginChecker.check(this@MainActivity)
            } catch (_: Exception) {
                return@launch
            }
            updateHeader()
            if (st == LoginChecker.State.INVALID && !sessionDialogShown) {
                sessionDialogShown = true
                showSessionExpiredDialog(LoginChecker.lastMessage)
            }
        }
    }

    private fun showSessionExpiredDialog(reason: String) {
        if (isFinishing || isDestroyed) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.login_expired_title)
            .setMessage(getString(R.string.login_expired_message, reason))
            .setPositiveButton(R.string.relogin) { _, _ ->
                startActivity(Intent(this, LoginActivity::class.java))
            }
            .setNegativeButton(R.string.later, null)
            .show()
    }

    // ---------------- 迷你播放条 ----------------

    private fun updateMiniPlayer() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            UiFx.slideOutBottom(binding.miniBar) { binding.miniBar.visibility = View.GONE }
            return
        }
        if (binding.miniBar.visibility != View.VISIBLE) {
            UiFx.slideInBottom(binding.miniBar)
        }
        binding.miniTitle.text = song.name
        binding.miniArtist.text = song.artists
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .into(binding.miniCover)
        // 全局主题色跟随当前封面 (状态栏/导航栏/进度条/按钮联动)
        ThemeManager.applyCover(this, song.cover)
        binding.miniProgress.setIndicatorColor(ThemeManager.primary)
        binding.miniPlay.setColorFilter(ThemeManager.primary)
        binding.miniPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
        // 定时关闭提示
        if (PlayerEngine.hasSleepTimer()) {
            binding.miniTimer.visibility = View.VISIBLE
            binding.miniTimer.text = PlayerEngine.sleepLabel()
        } else {
            binding.miniTimer.visibility = View.GONE
        }
        val dur = song.duration.toInt().coerceAtLeast(1)
        binding.miniProgress.max = dur
        binding.miniProgress.setProgressCompat(
            PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
            true
        )
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                val song = PlayerEngine.currentSong() ?: continue
                val dur = song.duration.toInt().coerceAtLeast(1)
                binding.miniProgress.setProgressCompat(
                    PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
                    true
                )
                if (PlayerEngine.hasSleepTimer()) {
                    binding.miniTimer.visibility = View.VISIBLE
                    binding.miniTimer.text = PlayerEngine.sleepLabel()
                } else if (binding.miniTimer.visibility == View.VISIBLE) {
                    binding.miniTimer.visibility = View.GONE
                }
            }
        }
    }

    private fun openSettings() {
        openPage(Intent(this, SettingsActivity::class.java), singleTop = true)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
