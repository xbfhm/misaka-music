package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityMainBinding
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding

    private val fragments: List<Fragment> = listOf(
        RecommendFragment(),
        PlaylistsFragment(),
        SearchFragment()
    )
    private var currentIndex = 0
    private var brandClickCount = 0
    private var brandClickTime = 0L
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 隐藏日志入口
        binding.tvBrand.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - brandClickTime > 1500) brandClickCount = 0
            brandClickTime = now
            brandClickCount++
            if (brandClickCount >= 5) {
                brandClickCount = 0
                startActivity(Intent(this, LogActivity::class.java))
            }
        }

        binding.btnSettings.setOnClickListener { openSettings() }
        binding.searchEntry.setOnClickListener { switchTab(2) }
        binding.avatar.setOnClickListener { openSettings() }

        binding.navRecommend.setOnClickListener { switchTab(0) }
        binding.navPlaylists.setOnClickListener { switchTab(1) }
        binding.navSearch.setOnClickListener { switchTab(2) }

        binding.miniBar.setOnClickListener {
            openPageUp(Intent(this, PlayerActivity::class.java))
        }
        binding.miniPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updateMiniPlayer()
        }
        binding.miniPrev.setOnClickListener {
            PlayerEngine.prev()
            updateMiniPlayer()
        }
        binding.miniNext.setOnClickListener {
            PlayerEngine.next()
            updateMiniPlayer()
        }

        updateHeader()
        switchTab(0)
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { _ -> runOnUiThread { updateMiniPlayer() } }
        PlayerEngine.onPlayState = { runOnUiThread { updateMiniPlayer() } }
        updateMiniPlayer()
        updateHeader()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    // ---------------- 底部导航切换 ----------------

    private val fragmentTags = listOf("tab_recommend", "tab_playlists", "tab_search")

    private fun switchTab(index: Int) {
        if (index !in fragmentTags.indices) return
        val fm = supportFragmentManager
        val tag = fragmentTags[index]
        val target = fm.findFragmentByTag(tag) ?: fragments[index]
        val tx = fm.beginTransaction()
        tx.setCustomAnimations(
            R.anim.fade_in, R.anim.fade_out,
            R.anim.fade_in, R.anim.fade_out
        )
        fm.fragments.forEach { f ->
            if (f.isAdded && f != target) tx.hide(f)
        }
        if (target.isAdded) tx.show(target) else tx.add(R.id.fragmentContainer, target, tag)
        tx.commitAllowingStateLoss()
        currentIndex = index
        updateNavUI(index)
    }

    /** Namida 风格: 选中=主色调亮色, 未选中=暗灰色 */
    private fun updateNavUI(index: Int) {
        val active = ContextCompat.getColor(this, R.color.namida_text_primary)
        val inactive = ContextCompat.getColor(this, R.color.namida_text_tertiary)

        binding.iconRecommend.setColorFilter(if (index == 0) active else inactive)
        binding.tvRecommend.setTextColor(if (index == 0) active else inactive)
        binding.iconPlaylists.setColorFilter(if (index == 1) active else inactive)
        binding.tvPlaylists.setTextColor(if (index == 1) active else inactive)
        binding.iconSearch.setColorFilter(if (index == 2) active else inactive)
        binding.tvSearch.setTextColor(if (index == 2) active else inactive)
    }

    // ---------------- 头部/登录态 ----------------

    private fun updateHeader() {
        if (Session.isLoggedIn()) {
            binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
            binding.avatar.visibility = View.VISIBLE
            Glide.with(this)
                .load(Session.avatar)
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .into(binding.avatar)
        } else {
            binding.tvNickname.text = getString(R.string.not_logged_in)
            binding.avatar.visibility = View.GONE
        }
    }

    // ---------------- 迷你播放条 ----------------

    private fun updateMiniPlayer() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            binding.miniBar.visibility = View.GONE
            return
        }
        binding.miniBar.visibility = View.VISIBLE
        binding.miniTitle.text = song.name
        binding.miniArtist.text = song.artists
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .into(binding.miniCover)
        applyMiniPalette(song.cover)
        binding.miniPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
        val dur = song.duration.toInt().coerceAtLeast(1)
        binding.miniProgress.max = dur
        binding.miniProgress.setProgressCompat(
            PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
            true
        )
    }

    /** Namida 动态取色: 进度条 + 播放键跟随封面主色 */
    private fun applyMiniPalette(cover: String) {
        if (cover.isBlank()) {
            binding.miniProgress.setIndicatorColor(
                ContextCompat.getColor(this, R.color.namida_primary)
            )
            return
        }
        scope.launch {
            val palette = try {
                withContext(Dispatchers.IO) {
                    Glide.with(this@MainActivity)
                        .asBitmap()
                        .load(cover)
                        .submit()
                        .get()
                        ?.let { Palette.from(it).generate() }
                }
            } catch (_: Exception) { null }
            val swatch = palette?.vibrantSwatch ?: palette?.dominantSwatch ?: palette?.mutedSwatch
            if (swatch != null) {
                binding.miniProgress.setIndicatorColor(swatch.rgb)
                binding.miniPlay.setColorFilter(swatch.rgb)
            }
        }
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                val song = PlayerEngine.currentSong() ?: continue
                val dur = song.duration.toInt().coerceAtLeast(1)
                binding.miniProgress.setProgressCompat(
                    PlayerEngine.player.currentPosition.toInt().coerceIn(0, dur),
                    true
                )
            }
        }
    }

    private fun openSettings() {
        openPage(Intent(this, SettingsActivity::class.java))
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
