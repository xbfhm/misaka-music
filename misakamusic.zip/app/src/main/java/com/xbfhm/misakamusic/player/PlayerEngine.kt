package com.xbfhm.misakamusic.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlayMode { ORDER, LOOP, SHUFFLE }

/** 定时关闭模式 */
enum class SleepMode { OFF, DURATION, AFTER_SONG }

/**
 * 全局播放引擎 (单例)
 *
 * 职责: 播放队列 / 播放控制 / 音源解析 / 网易云听歌记录上报 / 定时关闭。
 */
object PlayerEngine {

    private lateinit var appCtx: Context
    private var listenerAttached = false

    private var playerReady = false

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        ensurePlayer()
    }

    val player: ExoPlayer by lazy { ExoPlayer.Builder(appCtx).build() }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songs = mutableListOf<Song>()
    var currentIndex: Int = -1
        private set
    var mode: PlayMode = PlayMode.ORDER
        private set
    var queueTag: Long = -1L

    private val shuffleQueue = ArrayDeque<Int>()
    private val history = ArrayDeque<Int>()
    private var consecutiveFail = 0
    private var preloadJob: Job? = null

    var urlResolver: (suspend (Long) -> String?)? = null

    var listener: ((Song?) -> Unit)? = null
    var onPlayState: (() -> Unit)? = null

    /** 听歌记录上报: (songId, sourceId, 播放秒数) -> 是否成功 */
    var scrobbleReporter: (suspend (songId: Long, sourceId: Long, timeSec: Int) -> Boolean)? = null

    /** 上报结果回调 (主线程): (成功?, 文案) —— 用于界面提示「已同步到网易云」 */
    var onScrobbleResult: ((Boolean, String) -> Unit)? = null

    private fun ensurePlayer() {
        if (listenerAttached) return
        listenerAttached = true
        playerReady = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                onPlayState?.invoke()
                Logger.log("Player", "state=${stateName(state)}")
                if (state == Player.STATE_ENDED) {
                    onSongEnded()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                Logger.log("Player", "isPlaying=$isPlaying")
                if (isPlaying) scrobbleResume() else scrobblePause()
            }

            override fun onPlayerError(error: PlaybackException) {
                Logger.log("Player", "错误: ${error.errorCodeName} ${error.message}")
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return
                }
                toast(unplayableMsg(currentSong()))
                autoNext()
            }
        })
    }

    private fun stateName(s: Int) = when (s) {
        Player.STATE_IDLE -> "IDLE"
        Player.STATE_BUFFERING -> "BUFFERING"
        Player.STATE_READY -> "READY"
        Player.STATE_ENDED -> "ENDED"
        else -> "UNKNOWN"
    }

    /**
     * 启动前台播放服务。
     * 必须在 player.play() 之前调用，否则系统 5 秒超时会杀进程。
     */
    fun ensureService() {
        try {
            val intent = Intent(appCtx, PlaybackService::class.java)
            appCtx.startForegroundService(intent)
            Logger.log("Player", "PlaybackService startForegroundService 已调用")
        } catch (e: Exception) {
            Logger.log("Player", "启动 PlaybackService 失败: ${e.message}")
        }
    }

    fun currentSong(): Song? = if (currentIndex in songs.indices) songs[currentIndex] else null

    fun isPlaying(): Boolean = player.isPlaying

    fun hasQueue(): Boolean = songs.isNotEmpty()

    fun queue(): List<Song> = songs.toList()

    fun setPlaylist(tag: Long, list: List<Song>, startIndex: Int = 0, randomStart: Boolean = false) {
        preloadJob?.cancel()
        songs.clear(); songs.addAll(list)
        history.clear(); shuffleQueue.clear()
        consecutiveFail = 0
        queueTag = tag
        if (list.isEmpty()) {
            currentIndex = -1
            listener?.invoke(null)
            return
        }
        val start = if (randomStart && list.size > 1) {
            list.indices.random()
        } else {
            startIndex.coerceIn(0, list.size - 1)
        }
        // 记录队列快照, 供「定时播放」在 App 被杀后恢复
        PlayQueueStore.save(appCtx, tag, list, start)
        playAt(start)
    }

    fun playFromList(index: Int) {
        if (index !in songs.indices) return
        playAt(index)
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
    }

    fun playAt(index: Int) {
        if (index !in songs.indices) return
        // 切歌前结算上一首的听歌记录
        scrobbleSwitch()
        currentIndex = index
        history.addLast(index)
        if (history.size > 200) history.removeFirst()
        listener?.invoke(songs[index])
        Logger.log("Player", "播放 [${index + 1}/${songs.size}] ${songs[index].name} - ${songs[index].artists}")
        // ★ 先启动服务，再解析 URL 播放 (系统要求 startForegroundService 后 5 秒内 startForeground)
        ensureService()
        resolveAndPlay()
    }

    private suspend fun resolveUrl(id: Long): String? {
        val resolver = urlResolver ?: return null
        return withContext(Dispatchers.IO) {
            try {
                resolver.invoke(id)
            } catch (e: Exception) {
                Logger.log("Player", "解析URL失败 id=$id: ${e.message}")
                null
            }
        }
    }

    private fun resolveAndPlay() {
        val song = currentSong() ?: return
        val id = song.id
        preloadJob?.cancel()
        preloadJob = scope.launch {
            Logger.log("Player", "正在解析音源: ${song.name} (id=$id)")
            val url = resolveUrl(id)
            if (url.isNullOrEmpty()) {
                Logger.log("Player", "音源解析失败: url为空")
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return@launch
                }
                toast(unplayableMsg(song))
                autoNext()
            } else {
                consecutiveFail = 0
                Logger.log("Player", "音源解析成功, 开始播放")
                val item = MediaItem.Builder()
                    .setUri(url)
                    .setMediaId(id.toString())
                    .setMediaMetadata(MediaMetadata.Builder()
                        .setTitle(song.name)
                        .setArtist(song.artists)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(if (song.cover.isNotBlank()) Uri.parse(song.cover) else null)
                        .build())
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.play()
            }
        }
    }

    private fun unplayableMsg(song: Song?): String = when {
        song == null -> "无法播放"
        song.fee > 0 && !Session.isLoggedIn() -> "《${song.name}》需要 VIP，请先登录网易云账号"
        song.fee > 0 -> "《${song.name}》需要 VIP 会员"
        else -> "《${song.name}》无法播放（可能已下架或无版权）"
    }

    /** 一首歌自然播完 */
    private fun onSongEnded() {
        scrobbleFinish("播完")
        if (sleepState == SleepMode.AFTER_SONG) {
            sleepState = SleepMode.OFF
            sleepEndMs = 0
            player.pause()
            toast("定时关闭：当前歌曲已播完，已停止")
            return
        }
        autoNext()
    }

    fun autoNext() {
        if (songs.isEmpty()) return
        when (mode) {
            PlayMode.ORDER -> {
                if (currentIndex >= songs.size - 1) {
                    player.seekTo(0)
                    player.pause()
                    return
                }
                playAt(currentIndex + 1)
            }
            PlayMode.LOOP -> playAt((currentIndex + 1) % songs.size)
            PlayMode.SHUFFLE -> {
                if (shuffleQueue.isEmpty()) rebuildShuffle()
                if (shuffleQueue.isEmpty()) return
                playAt(shuffleQueue.removeFirst())
            }
        }
    }

    fun next() = autoNext()

    fun prev() {
        if (songs.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        if (history.size > 1) {
            history.removeLast()
            val prevIdx = history.removeLast()
            playAt(prevIdx)
        } else {
            player.seekTo(0)
        }
    }

    private fun rebuildShuffle() {
        val list = (0 until songs.size).toMutableList()
        if (currentIndex in list && songs.size > 1) list.remove(currentIndex)
        list.shuffle()
        shuffleQueue.clear()
        shuffleQueue.addAll(list)
    }

    fun toggleMode(): PlayMode {
        mode = when (mode) {
            PlayMode.ORDER -> PlayMode.LOOP
            PlayMode.LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.ORDER
        }
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
        return mode
    }

    fun togglePlayPause() {
        if (currentIndex < 0) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            ensureService()
            player.prepare()
            player.play()
        }
    }

    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun playModeLabel(): String = when (mode) {
        PlayMode.ORDER -> "顺序播放"
        PlayMode.LOOP -> "循环播放"
        PlayMode.SHUFFLE -> "随机播放"
    }

    fun stopAndClear() {
        scrobbleFinish("停止")
        player.stop()
        songs.clear()
        currentIndex = -1
        history.clear()
        shuffleQueue.clear()
        listener?.invoke(null)
    }

    // ==================== 听歌记录上报 (同步到网易云) ====================

    /** 少于这个秒数不上报 (避免噪声, 也不会被网易云计入播放) */
    private const val MIN_REPORT_SEC = 5

    private var scSongId = -1L
    private var scSec = 0
    private var scAnchorMs = 0L
    private var scReportedOnce = false

    /** 开始/继续播放 */
    private fun scrobbleResume() {
        val song = currentSong() ?: return
        if (scSongId != song.id) {
            // 换歌: 旧歌已在 playAt 里结算
            scSongId = song.id
            scSec = 0
        }
        if (scAnchorMs == 0L) scAnchorMs = System.currentTimeMillis()
        Logger.log("Scrobble", "开始计时: ${song.name} (id=${song.id})")
    }

    /**
     * 暂停/缓冲: 结算。
     * 注意这里用较高的门槛 (30s) —— 频繁暂停/继续不应该产生一堆碎片记录,
     * 未达门槛的秒数会保留下来, 与下一次继续播放的时长合并后再上报。
     */
    private fun scrobblePause() {
        scrobbleAccumulate()
        scAnchorMs = 0
        Logger.log("Scrobble", "暂停, 当前累计 ${scSec}s")
        flushScrobble("暂停", minSec = 30)
    }

    /** 切歌: 结算上一首 */
    private fun scrobbleSwitch() {
        if (scSongId <= 0) return
        flushScrobble("切歌")
        scAnchorMs = 0
        scSec = 0
        scSongId = -1
    }

    /** 一首歌完整结束 */
    private fun scrobbleFinish(reason: String) {
        flushScrobble(reason)
        scAnchorMs = 0
        scSec = 0
    }

    private fun scrobbleAccumulate() {
        if (scAnchorMs > 0) {
            val d = ((System.currentTimeMillis() - scAnchorMs) / 1000).toInt()
            if (d > 0) scSec += d
            scAnchorMs = System.currentTimeMillis()
        }
    }

    private fun flushScrobble(reason: String, minSec: Int = MIN_REPORT_SEC) {
        scrobbleAccumulate()
        val id = scSongId
        val t = scSec
        if (id <= 0 || t < minSec) {
            if (id > 0) Logger.log("Scrobble", "($reason) 仅 ${t}s, 不上报")
            return
        }
        scSec = 0
        // sourceId 兜底: 推荐/搜索队列没有歌单 id, 用「我喜欢的音乐」代替,
        // 官方播放器总是带一个真实的歌单 id, 缺失时服务端可能忽略这次上报
        val src = if (queueTag > 0) queueTag else Session.likedPlaylistId
        Logger.log("Scrobble", "($reason) 上报 songId=$id time=${t}s source=$src loggedIn=${Session.isLoggedIn()}")
        scope.launch {
            val ok = try {
                withContext(Dispatchers.IO) { scrobbleReporter?.invoke(id, src, t) } ?: false
            } catch (e: Exception) {
                Logger.log("Scrobble", "上报异常: ${e.message}")
                false
            }
            Logger.log("Scrobble", "上报结果: $ok")
            if (ok) {
                Session.lastSyncTime = System.currentTimeMillis()
                if (!scReportedOnce) {
                    scReportedOnce = true
                    onScrobbleResult?.invoke(true, "已同步到网易云 · 听歌记录 +${formatSec(t)}")
                }
            }
        }
    }

    private fun formatSec(sec: Int): String =
        if (sec >= 60) "${sec / 60}分${sec % 60}秒" else "${sec}秒"

    // ==================== 定时关闭 ====================

    @Volatile
    private var sleepState: SleepMode = SleepMode.OFF
    private var sleepEndMs: Long = 0
    private var sleepJob: Job? = null

    /** 定时关闭: [minutes] 分钟后停止播放 (最后 10 秒音量渐弱) */
    fun setSleepTimer(minutes: Int) {
        cancelSleepTimer()
        if (minutes <= 0) return
        sleepState = SleepMode.DURATION
        sleepEndMs = System.currentTimeMillis() + minutes * 60_000L
        Logger.log("Timer", "定时关闭已设置: ${minutes} 分钟")
        sleepJob = scope.launch {
            try {
                while (isActive) {
                    val left = sleepEndMs - System.currentTimeMillis()
                    if (left <= 0) break
                    if (left <= 10_000) {
                        // 最后 10 秒淡出, 避免突然静音
                        player.volume = (left / 10_000f).coerceIn(0f, 1f)
                    }
                    delay(400)
                }
            } finally {
                player.volume = 1f
            }
            sleepEndMs = 0
            sleepState = SleepMode.OFF
            if (player.isPlaying) player.pause()
            toast("定时关闭：已停止播放")
            Logger.log("Timer", "定时关闭触发, 已暂停")
            onPlayState?.invoke()
        }
    }

    /** 播完当前歌曲后停止 */
    fun setSleepAfterCurrentSong() {
        cancelSleepTimer()
        sleepState = SleepMode.AFTER_SONG
        Logger.log("Timer", "定时关闭: 播完当前歌曲后停止")
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel()
        sleepJob = null
        sleepState = SleepMode.OFF
        sleepEndMs = 0
        if (playerReady) player.volume = 1f
    }

    fun hasSleepTimer(): Boolean = sleepState != SleepMode.OFF

    fun currentSleepMode(): SleepMode = sleepState

    fun sleepRemainingMs(): Long = (sleepEndMs - System.currentTimeMillis()).coerceAtLeast(0)

    /** 定时关闭的展示文案 (无定时返回空串) */
    fun sleepLabel(): String = when (sleepState) {
        SleepMode.OFF -> ""
        SleepMode.AFTER_SONG -> "定时关闭：播完当前歌曲停止"
        SleepMode.DURATION -> {
            val s = sleepRemainingMs() / 1000
            "定时关闭：还剩 %d:%02d".format(s / 60, s % 60)
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
    }
}
