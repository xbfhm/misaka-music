package com.xbfhm.misakamusic.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlayMode { ORDER, LOOP, SHUFFLE }

/**
 * 全局播放引擎 (单例)
 */
object PlayerEngine {

    private lateinit var appCtx: Context
    private var listenerAttached = false

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        ensurePlayer()
    }

    val player: ExoPlayer by lazy { ExoPlayer.Builder(appCtx).build() }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songs = mutableListOf<Song>()
    var currentIndex: Int = -1
        private set
    var mode: PlayMode = PlayMode.ORDER
        private set
    var queueTag: Long = -1L

    private val shuffleQueue = ArrayDeque<Int>()
    private val history = ArrayDeque<Int>()
    private var consecutiveFail = 0

    var urlResolver: (suspend (Long) -> String?)? = null

    var listener: ((Song?) -> Unit)? = null
    var onPlayState: (() -> Unit)? = null

    var scrobbleReporter: (suspend (songId: Long, sourceId: Long, timeSec: Int) -> Unit)? = null

    private fun ensurePlayer() {
        if (listenerAttached) return
        listenerAttached = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                onPlayState?.invoke()
                Logger.log("Player", "state=${stateName(state)}")
                if (state == Player.STATE_ENDED) autoNext()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                Logger.log("Player", "isPlaying=$isPlaying")
                if (isPlaying) {
                    onScrobblePlay()
                } else {
                    onScrobblePause()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                Logger.log("Player", "错误: ${error.errorCodeName} ${error.message}")
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return
                }
                toast(unplayableMsg(currentSong()))
                autoNext()
            }
        })
    }

    private fun stateName(s: Int) = when (s) {
        Player.STATE_IDLE -> "IDLE"
        Player.STATE_BUFFERING -> "BUFFERING"
        Player.STATE_READY -> "READY"
        Player.STATE_ENDED -> "ENDED"
        else -> "UNKNOWN"
    }

    /**
     * 启动前台播放服务。
     * 必须在 player.play() 之前调用，否则系统 5 秒超时会杀进程。
     */
    fun ensureService() {
        try {
            val intent = Intent(appCtx, PlaybackService::class.java)
            appCtx.startForegroundService(intent)
            Logger.log("Player", "PlaybackService startForegroundService 已调用")
        } catch (e: Exception) {
            Logger.log("Player", "启动 PlaybackService 失败: ${e.message}")
        }
    }

    fun currentSong(): Song? = if (currentIndex in songs.indices) songs[currentIndex] else null

    fun isPlaying(): Boolean = player.isPlaying

    fun hasQueue(): Boolean = songs.isNotEmpty()

    fun setPlaylist(tag: Long, list: List<Song>, startIndex: Int = 0, randomStart: Boolean = false) {
        preloadJob?.cancel()
        songs.clear(); songs.addAll(list)
        history.clear(); shuffleQueue.clear()
        consecutiveFail = 0
        queueTag = tag
        if (list.isEmpty()) { currentIndex = -1; listener?.invoke(null); return }
        val start = if (randomStart && list.size > 1) {
            list.indices.random()
        } else {
            startIndex.coerceIn(0, list.size - 1)
        }
        playAt(start)
    }

    fun playFromList(index: Int) {
        if (index !in songs.indices) return
        playAt(index)
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
    }

    fun playAt(index: Int) {
        if (index !in songs.indices) return
        currentIndex = index
        history.addLast(index)
        if (history.size > 200) history.removeFirst()
        listener?.invoke(songs[index])
        Logger.log("Player", "播放 [${index}/${songs.size}] ${songs[index].name} - ${songs[index].artists}")
        // ★ 关键修复: 先启动服务，再解析 URL 播放
        // 系统要求 startForegroundService 后 5 秒内必须 startForeground
        // 提前启动服务，给足时间
        ensureService()
        resolveAndPlay()
    }

    private suspend fun resolveUrl(id: Long): String? {
        val resolver = urlResolver ?: return null
        return withContext(Dispatchers.IO) {
            try { resolver.invoke(id) } catch (e: Exception) {
                Logger.log("Player", "解析URL失败 id=$id: ${e.message}")
                null
            }
        }
    }

    private fun resolveAndPlay() {
        val song = currentSong() ?: return
        val id = song.id
        preloadJob?.cancel()
        preloadJob = scope.launch {
            Logger.log("Player", "正在解析音源: ${song.name} (id=$id)")
            val url = resolveUrl(id)
            if (url.isNullOrEmpty()) {
                Logger.log("Player", "音源解析失败: url为空")
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return@launch
                }
                toast(unplayableMsg(song))
                autoNext()
            } else {
                consecutiveFail = 0
                Logger.log("Player", "音源解析成功, 开始播放")
                val item = MediaItem.Builder()
                    .setUri(url)
                    .setMediaId(id.toString())
                    .setMediaMetadata(MediaMetadata.Builder()
                        .setTitle(song.name)
                        .setArtist(song.artists)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(if (song.cover.isNotBlank()) Uri.parse(song.cover) else null)
                        .build())
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.play()
            }
        }
    }

    private fun unplayableMsg(song: Song?): String = when {
        song == null -> "无法播放"
        song.fee > 0 && !Session.isLoggedIn() -> "《${song.name}》需要 VIP，请先在设置中登录"
        song.fee > 0 -> "《${song.name}》需要 VIP 会员"
        else -> "《${song.name}》无法播放（可能已下架或无版权）"
    }

    fun autoNext() {
        if (songs.isEmpty()) return
        when (mode) {
            PlayMode.ORDER -> {
                if (currentIndex >= songs.size - 1) {
                    player.seekTo(0)
                    player.pause()
                    return
                }
                playAt(currentIndex + 1)
            }
            PlayMode.LOOP -> playAt((currentIndex + 1) % songs.size)
            PlayMode.SHUFFLE -> {
                if (shuffleQueue.isEmpty()) rebuildShuffle()
                if (shuffleQueue.isEmpty()) return
                playAt(shuffleQueue.removeFirst())
            }
        }
    }

    fun next() = autoNext()

    fun prev() {
        if (songs.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        if (history.size > 1) {
            history.removeLast()
            val prevIdx = history.removeLast()
            playAt(prevIdx)
        } else {
            player.seekTo(0)
        }
    }

    private fun rebuildShuffle() {
        val list = (0 until songs.size).toMutableList()
        if (currentIndex in list && songs.size > 1) list.remove(currentIndex)
        list.shuffle()
        shuffleQueue.clear()
        shuffleQueue.addAll(list)
    }

    fun toggleMode(): PlayMode {
        mode = when (mode) {
            PlayMode.ORDER -> PlayMode.LOOP
            PlayMode.LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.ORDER
        }
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
        return mode
    }

    fun togglePlayPause() {
        if (currentIndex < 0) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            ensureService()
            player.prepare()
            player.play()
        }
    }

    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun playModeLabel(): String = when (mode) {
        PlayMode.ORDER -> "顺序播放"
        PlayMode.LOOP -> "循环播放"
        PlayMode.SHUFFLE -> "随机播放"
    }

    // ==================== 播放上报 (网易云同步历史) ====================

    private var preloadJob: Job? = null
    private var scrobbleSongId = -1L
    private var scrobblePendingSec = 0
    private var scrobbleAnchorMs = 0L
    private var scrobbleJob: Job? = null

    private fun onScrobblePlay() {
        val song = currentSong() ?: return
        if (scrobbleReporter == null) {
            Logger.log("Scrobble", "跳过: reporter 未设置")
            return
        }
        if (!Session.isLoggedIn()) {
            Logger.log("Scrobble", "跳过: 未登录")
            return
        }
        // 切歌时先上报上一首
        if (scrobbleSongId > 0 && scrobbleSongId != song.id) {
            flushScrobble()
        }
        scrobbleSongId = song.id
        scrobblePendingSec = 0
        scrobbleAnchorMs = System.currentTimeMillis()
        Logger.log("Scrobble", "开始跟踪: ${song.name} (id=${song.id})")
        startScrobbleTick()
    }

    private fun onScrobblePause() {
        // 暂停时累加已播放时长
        accumulatePlayedTime()
        // 立即上报已累计的时长（不等30秒）
        flushScrobble()
        scrobbleJob?.cancel()
    }

    /** 把 anchor 到现在的时长累加到 pendingSec */
    private fun accumulatePlayedTime() {
        if (scrobbleSongId > 0 && scrobbleAnchorMs > 0) {
            val extra = ((System.currentTimeMillis() - scrobbleAnchorMs) / 1000).toInt()
            if (extra > 0) {
                scrobblePendingSec += extra
                Logger.log("Scrobble", "累加 ${extra}s, 累计 ${scrobblePendingSec}s")
            }
            scrobbleAnchorMs = System.currentTimeMillis()
        }
    }

    private fun startScrobbleTick() {
        scrobbleJob?.cancel()
        scrobbleJob = scope.launch {
            // 每 10 秒检查一次（缩短间隔，提高同步成功率）
            while (true) {
                delay(10_000L)
                if (player.isPlaying && scrobbleSongId > 0) {
                    accumulatePlayedTime()
                    // 累计满 15 秒就上报一次（降低门槛）
                    if (scrobblePendingSec >= 15) {
                        flushScrobble()
                    }
                }
            }
        }
    }

    private fun flushScrobble() {
        val id = scrobbleSongId
        val time = scrobblePendingSec
        if (id <= 0 || time <= 0) return
        val src = queueTag
        // 先清零，防止重复上报
        scrobblePendingSec = 0
        Logger.log("Scrobble", "上报: songId=$id, time=${time}s, source=$src, loggedIn=${Session.isLoggedIn()}")
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { scrobbleReporter?.invoke(id, src, time) }
                Logger.log("Scrobble", "上报结果: $result")
            } catch (e: Exception) {
                Logger.log("Scrobble", "上报异常: ${e.message}")
            }
        }
    }

    // ==================== 定时关闭 ====================

    private var sleepEndMs: Long = 0
    private var sleepJob: Job? = null

    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) {
            sleepEndMs = 0
            return
        }
        sleepEndMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            while (System.currentTimeMillis() < sleepEndMs) {
                delay(1000)
            }
            sleepEndMs = 0
            player.pause()
            toast("定时关闭：已停止播放")
        }
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel()
        sleepEndMs = 0
    }

    fun hasSleepTimer(): Boolean = sleepEndMs > 0

    fun sleepRemainingMs(): Long = (sleepEndMs - System.currentTimeMillis()).coerceAtLeast(0)

    fun stopAndClear() {
        player.stop()
        songs.clear()
        currentIndex = -1
        history.clear()
        shuffleQueue.clear()
        listener?.invoke(null)
    }

    private fun toast(msg: String) {
        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
    }
}
