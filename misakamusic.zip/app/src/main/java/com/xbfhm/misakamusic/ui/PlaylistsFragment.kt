package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.FragmentPlaylistsBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 我的歌单页: 含"我喜欢的音乐" + 全部歌单 */
class PlaylistsFragment : Fragment() {

    private var _binding: FragmentPlaylistsBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val adapter = PlaylistAdapter { p -> openPlaylist(p) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlaylistsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvPlaylists.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPlaylists.adapter = adapter
        binding.btnLogin.setOnClickListener {
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        loadPlaylists()
    }

    override fun onResume() {
        super.onResume()
        loadPlaylists()
    }

    private fun loadPlaylists() {
        if (!Session.isLoggedIn()) {
            binding.tvEmpty.visibility = View.VISIBLE
            binding.btnLogin.visibility = View.VISIBLE
            adapter.submit(emptyList())
            return
        }
        binding.tvEmpty.visibility = View.GONE
        binding.btnLogin.visibility = View.GONE
        scope.launch {
            if (Session.uid <= 0) {
                val info = withContext(Dispatchers.IO) { NeteaseApi.accountInfo(requireContext()) }
                Session.uid = info.optJSONObject("profile")?.optLong("userId", 0) ?: 0
            }
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(requireContext(), Session.uid)
            }
            adapter.submit(playlists)
        }
    }

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(requireContext(), PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        startActivity(intent)
        requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
