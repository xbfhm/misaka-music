package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.data.LocalPlaylistStore
import com.xbfhm.misakamusic.data.PlayHistoryStore
import com.xbfhm.misakamusic.databinding.FragmentPlaylistsBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.theme.ThemeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 我的歌单页。
 *
 * ★ 修复「未登录不能添加歌单」:
 *   本地歌单和网易云歌单现在并存 —— 未登录也能新建歌单、把歌加进去、播放;
 *   登录后网易云歌单会一起列出来。未登录只给一条不挡路的提示。
 */
class PlaylistsFragment : Fragment() {

    private var _binding: FragmentPlaylistsBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val adapter = PlaylistAdapter(
        onClick = { p -> openPlaylist(p) },
        onLongClick = { p -> showLocalOptions(p) }
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlaylistsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ThemeManager.applyToTree(view)
        binding.rvPlaylists.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPlaylists.adapter = adapter

        binding.btnLogin.setOnClickListener { openLogin() }
        binding.cardHistory.setOnClickListener {
            startActivity(Intent(requireContext(), HistoryActivity::class.java))
            requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        binding.cardNew.setOnClickListener { createLocal() }
        loadPlaylists()
    }

    override fun onResume() {
        super.onResume()
        loadPlaylists()
    }

    private fun loadPlaylists() {
        val logged = Session.isLoggedIn()
        binding.loginHintCard.visibility = if (logged) View.GONE else View.VISIBLE
        binding.tvHistoryCount.text = "${PlayHistoryStore.size()} 首"

        val locals = LocalPlaylistStore.all().map { l ->
            Playlist(
                id = l.id,
                name = l.name,
                cover = l.songs.firstOrNull()?.cover ?: "",
                trackCount = l.songs.size,
                playCount = 0L,
                isLiked = false,
                isLocal = true
            )
        }

        if (!logged) {
            adapter.submit(locals)
            binding.tvEmpty.visibility = if (locals.isEmpty()) View.VISIBLE else View.GONE
            return
        }
        scope.launch {
            if (Session.uid <= 0) {
                val info = withContext(Dispatchers.IO) { NeteaseApi.accountInfo(requireContext()) }
                Session.uid = info.optJSONObject("profile")?.optLong("userId", 0) ?: 0
            }
            val remote = withContext(Dispatchers.IO) {
                runCatching { NeteaseApi.userPlaylists(requireContext(), Session.uid) }
                    .getOrDefault(emptyList())
            }
            remote.firstOrNull { it.isLiked }?.let { Session.likedPlaylistId = it.id }
            val all = locals + remote
            adapter.submit(all)
            binding.tvEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    // ---------------- 本地歌单 ----------------

    private fun createLocal() {
        showNameDialog(getString(R.string.pl_new), "") { name ->
            LocalPlaylistStore.create(name)
            loadPlaylists()
            toast(getString(R.string.pl_created))
        }
    }

    private fun showLocalOptions(p: Playlist) {
        val options = arrayOf(getString(R.string.pl_rename), getString(R.string.pl_delete))
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(p.name)
            .setItems(options) { _: DialogInterface?, which: Int ->
                if (which == 0) {
                    showNameDialog(getString(R.string.pl_rename), p.name) { name ->
                        LocalPlaylistStore.rename(p.id, name)
                        loadPlaylists()
                    }
                } else {
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle(R.string.pl_delete)
                        .setMessage(R.string.pl_delete_confirm)
                        .setPositiveButton(R.string.timer_ok) { _, _ ->
                            LocalPlaylistStore.delete(p.id)
                            loadPlaylists()
                            toast(getString(R.string.pl_deleted))
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showNameDialog(title: String, preset: String, onOk: (String) -> Unit) {
        val input = EditText(requireContext()).apply {
            hint = getString(R.string.pl_name_hint)
            setSingleLine(true)
            setText(preset)
            setSelection(text.length)
            setBackgroundResource(R.drawable.bg_glass_field)
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            setTextColor(0xFFEDEFF5.toInt())
            setHintTextColor(0xFF767C8C.toInt())
        }
        val wrap = android.widget.FrameLayout(requireContext()).apply {
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, 0)
            addView(input, android.widget.FrameLayout.LayoutParams(-1, -2))
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton(R.string.timer_ok) { _, _ ->
                onOk(input.text?.toString()?.trim().orEmpty())
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------- 打开 ----------------

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(requireContext(), PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        intent.putExtra(PlaylistActivity.EXTRA_LOCAL, p.isLocal)
        startActivity(intent)
        requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun openLogin() {
        startActivity(Intent(requireContext(), LoginActivity::class.java))
        requireActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
