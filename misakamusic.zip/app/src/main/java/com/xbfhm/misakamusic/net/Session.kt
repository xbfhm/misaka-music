package com.xbfhm.misakamusic.net

import android.content.Context
import com.xbfhm.misakamusic.util.Logger

/**
 * 登录会话: cookie 持久化 + 用户资料
 *
 * ★ 安全说明 (v4.0.0 安全审查)：
 *   MUSIC_U 等价于账号密码, 因此 cookie 串**不再明文落盘**:
 *   优先用 [SessionCrypto] (Android Keystore 里的 AES-256-GCM 密钥) 加密后存入
 *   `cookies_enc`; 只有当 Keystore 不可用时才回退旧明文键 `cookies`(并会在下次
 *   保存时再次尝试加密)。旧版本升级上来时自动迁移并删除明文。
 */
object Session {
    private const val PREFS = "session"
    private const val KEY_COOKIES_ENC = "cookies_enc"
    private const val KEY_COOKIES_RAW = "cookies"
    private lateinit var appCtx: Context
    private val cookies = LinkedHashMap<String, String>()

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        load()
        ensureDeviceCookies()
    }

    private fun prefs() = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun load() {
        cookies.clear()
        val enc = prefs().getString(KEY_COOKIES_ENC, null)
        if (enc != null) {
            val plain = SessionCrypto.decrypt(enc)
            if (plain != null) {
                parse(plain)
                return
            }
            Logger.log("Session", "登录态解密失败, 尝试回退明文")
        }
        val raw = prefs().getString(KEY_COOKIES_RAW, null) ?: return
        parse(raw)
        // 迁移: 旧明文 -> 密文, 并立刻删掉明文键
        save()
    }

    private fun parse(raw: String) {
        raw.split(";").forEach { part ->
            val i = part.indexOf('=')
            if (i > 0) {
                val k = part.substring(0, i).trim()
                val v = part.substring(i + 1).trim()
                if (k.isNotEmpty()) cookies[k] = v
            }
        }
    }

    private fun serialized(): String =
        cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }

    private fun save() {
        val plain = serialized()
        val enc = SessionCrypto.encrypt(plain)
        val e = prefs().edit()
        if (enc != null) {
            e.putString(KEY_COOKIES_ENC, enc)
            e.remove(KEY_COOKIES_RAW)
        } else {
            // 兜底: Keystore 不可用时仍可正常登录, 只是没有加密保护
            e.putString(KEY_COOKIES_RAW, plain)
            e.remove(KEY_COOKIES_ENC)
        }
        e.apply()
    }

    /** 补充设备相关 cookie (对齐 request.js processCookieObject) */
    private fun ensureDeviceCookies() {
        var changed = false
        if (!cookies.containsKey("_ntes_nuid")) {
            cookies["_ntes_nuid"] = randomHex(32)
            changed = true
        }
        if (!cookies.containsKey("os")) { cookies["os"] = Device.OS; changed = true }
        if (!cookies.containsKey("osver")) { cookies["osver"] = Device.OSVER; changed = true }
        if (!cookies.containsKey("appver")) { cookies["appver"] = Device.APPV; changed = true }
        if (!cookies.containsKey("channel")) { cookies["channel"] = Device.CHANNEL; changed = true }
        if (!cookies.containsKey("WEVNSM")) { cookies["WEVNSM"] = "1.0.0"; changed = true }
        if (!cookies.containsKey("__remember_me")) { cookies["__remember_me"] = "true"; changed = true }
        if (!cookies.containsKey("deviceId")) {
            cookies["deviceId"] = Device.id(appCtx)
            changed = true
        }
        if (!cookies.containsKey("WNMCID")) {
            val chars = "abcdefghijklmnopqrstuvwxyz"
            val sb = StringBuilder(6)
            repeat(6) { sb.append(chars[(Math.random() * 26).toInt()]) }
            cookies["WNMCID"] = "${sb}.${System.currentTimeMillis()}.01.0"
            changed = true
        }
        if (changed) save()
    }

    private fun randomHex(len: Int): String {
        val chars = "0123456789abcdef"
        val sb = StringBuilder(len)
        repeat(len) { sb.append(chars[(Math.random() * 16).toInt()]) }
        return sb.toString()
    }

    /** 从 Set-Cookie 或响应体 cookie 字段吸收 */
    fun absorbCookieString(str: String) {
        if (str.isBlank()) return
        str.split(";").forEach { part ->
            val i = part.indexOf('=')
            if (i > 0) {
                val k = part.substring(0, i).trim()
                val v = part.substring(i + 1).trim()
                if (k.isNotEmpty()) cookies[k] = v
            }
        }
        save()
    }

    /**
     * 内置网页登录成功后把 WebView 的 cookie 并入会话。
     *
     * 网页版登录下来的 cookie 里 `os/osver/appver/channel/deviceId` 是**浏览器身份**,
     * 直接拿去请求 eapi 会被服务端当成「异常客户端」。所以这里保留登录态字段
     * (MUSIC_U / __csrf / MUSIC_A / NMTID 等), 把设备身份字段强制换成本机 App 的。
     */
    fun absorbWebCookies(raw: String) {
        absorbCookieString(raw)
        normalizeDeviceCookies()
    }

    /** 把 eapi 需要的设备身份字段强制对齐本机 App (网页登录后必须调用一次) */
    fun normalizeDeviceCookies() {
        cookies["os"] = Device.OS
        cookies["osver"] = Device.OSVER
        cookies["appver"] = Device.APPV
        cookies["channel"] = Device.CHANNEL
        cookies["deviceId"] = Device.id(appCtx)
        if (!cookies.containsKey("_ntes_nuid")) cookies["_ntes_nuid"] = randomHex(32)
        if (!cookies.containsKey("WEVNSM")) cookies["WEVNSM"] = "1.0.0"
        save()
    }

    fun put(key: String, value: String) {
        cookies[key] = value
        save()
    }

    fun get(key: String): String? = cookies[key]

    fun has(key: String): Boolean = !cookies[key].isNullOrEmpty()

    fun cookieHeader(): String =
        cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }

    /**
     * 网页播放器身份 cookie (os=osx)。
     * ★ 听歌记录/听歌时长上报 (weblog) 是网页播放器统计口径:
     *   cookie 里 os 必须是 osx, 服务端才会把这次播放计入「听歌排行 / 听歌时长」。
     *   App 默认 os=android (eapi 通道), 直接上报会被网页口径忽略。
     */
    fun cookieHeaderWeb(): String =
        cookies.entries.joinToString("; ") { (k, v) -> if (k == "os") "os=osx" else "$k=$v" }

    fun isLoggedIn(): Boolean = has("MUSIC_U")

    /** 读取单个 cookie 值 (NCBL 上报需要逐个取) */
    fun cookieValue(key: String): String = cookies[key] ?: ""

    fun clearLogin() {
        cookies.clear()
        // 直接删除两个键 (而不是 save() 一个空串), 避免磁盘上残留任何登录信息
        prefs().edit()
            .remove(KEY_COOKIES_ENC)
            .remove(KEY_COOKIES_RAW)
            .remove("nickname")
            .remove("avatar")
            .remove("uid")
            .apply()
        clearWebViewCookies()
    }

    /**
     * 清空 WebView 里残留的网易云 cookie。
     * 退出登录时不清的话, 再打开「网页登录」会直接是已登录状态 (旧会话被复用)。
     */
    fun clearWebViewCookies() {
        try {
            val cm = android.webkit.CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
        } catch (_: Throwable) {
            // WebView 未初始化 / 某些 ROM 限制, 忽略
        }
    }

    // ---- 用户资料 ----
    var nickname: String
        get() = prefs().getString("nickname", "") ?: ""
        set(v) { prefs().edit().putString("nickname", v).apply() }

    var avatar: String
        get() = prefs().getString("avatar", "") ?: ""
        set(v) { prefs().edit().putString("avatar", v).apply() }

    var uid: Long
        get() = prefs().getLong("uid", 0)
        set(v) { prefs().edit().putLong("uid", v).apply() }

    // ---- 音质偏好: standard/higher/exhigh/lossless/hires ----
    var quality: String
        get() = prefs().getString("quality", "exhigh") ?: "exhigh"
        set(v) { prefs().edit().putString("quality", v).apply() }

    // ---- 默认播放源: netease(网易云原始接口) / gdstudio(GDStudio 免费聚合接口) ----
    var playSource: String
        get() = prefs().getString("play_source", "netease") ?: "netease"
        set(v) { prefs().edit().putString("play_source", v).apply() }

    // ---- 听歌记录同步 (上报到网易云: 听歌记录 / 听歌排行 / 听歌时长), 默认开 ----
    var syncPlayRecord: Boolean
        get() = prefs().getBoolean("sync_play_record", true)
        set(v) { prefs().edit().putBoolean("sync_play_record", v).apply() }

    // ---- 「我喜欢的音乐」歌单 id: 听歌上报时作为 sourceId 兜底 ----
    var likedPlaylistId: Long
        get() = prefs().getLong("liked_playlist_id", 0L)
        set(v) { prefs().edit().putLong("liked_playlist_id", v).apply() }

    // ---- 最近一次同步时间 ----
    var lastSyncTime: Long
        get() = prefs().getLong("last_sync_time", 0L)
        set(v) { prefs().edit().putLong("last_sync_time", v).apply() }

    // ---- 最近一次上报是否因登录态失效而失败 (301) ----
    var lastSyncAuthFail: Boolean
        get() = prefs().getBoolean("last_sync_auth_fail", false)
        set(v) { prefs().edit().putBoolean("last_sync_auth_fail", v).apply() }

    // ---- 我喜欢的音乐 id 缓存 (登录后加载, 用于判断收藏状态) ----
    private val likedIdsCache = mutableSetOf<Long>()
    var likedLoaded = false
        private set

    fun isLiked(id: Long): Boolean = id in likedIdsCache

    fun setLiked(id: Long, liked: Boolean) {
        if (liked) likedIdsCache.add(id) else likedIdsCache.remove(id)
    }

    fun setLikedIds(ids: Collection<Long>) {
        likedIdsCache.clear()
        likedIdsCache.addAll(ids)
        likedLoaded = true
    }

    fun clearLiked() {
        likedIdsCache.clear()
        likedLoaded = false
    }

    // ---- 本地收藏 (未登录时收藏歌曲) ----
    fun localLiked(): MutableSet<String> =
        prefs().getStringSet("local_liked", emptySet())?.toMutableSet() ?: mutableSetOf()

    fun isLocalLiked(id: Long): Boolean = localLiked().contains(id.toString())

    fun toggleLocalLiked(id: Long): Boolean {
        val set = localLiked()
        val key = id.toString()
        val liked = if (set.contains(key)) { set.remove(key); false } else { set.add(key); true }
        prefs().edit().putStringSet("local_liked", set).apply()
        return liked
    }
}
