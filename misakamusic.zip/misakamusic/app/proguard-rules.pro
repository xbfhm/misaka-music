# debug 构建不混淆, 这些规则仅为 release 备用
-keep class com.google.zxing.** { *; }
-keep class okhttp3.** { *; }
-keep class com.bumptech.glide.** { *; }
