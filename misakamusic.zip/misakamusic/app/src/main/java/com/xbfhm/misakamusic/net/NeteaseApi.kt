package com.xbfhm.misakamusic.net

import android.content.Context
import com.xbfhm.misakamusic.crypto.NeteaseCrypto
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.model.Song
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * 网易云音乐 API 客户端 (独立实现, 无需服务器)
 * 加密/接口路径 对齐 NeteaseCloudMusicApi 4.32.0
 */
object NeteaseApi {

    private const val DOMAIN = "https://music.163.com"
    private const val API_DOMAIN = "https://interface.music.163.com"
    private const val UA_WEAPI = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
    private const val UA_API = "NeteaseMusic/9.1.65.240927161425(9001065);Dalvik/2.1.0 (Linux; U; Android 14; 23013RK75C Build/UKQ1.230804.001)"

    // ================= 加密请求底层 =================

    private fun buildEapiHeader(ctx: Context): JSONObject {
        val h = JSONObject()
        h.put("osver", Device.OSVER)
        h.put("deviceId", Device.id(ctx))
        h.put("os", Device.OS)
        h.put("appver", Device.APPV)
        h.put("versioncode", Device.VERSION_CODE)
        h.put("mobilename", Device.MOBILE_NAME)
        h.put("buildver", System.currentTimeMillis().toString().substring(0, 10))
        h.put("resolution", Device.RESOLUTION)
        h.put("__csrf", Session.get("__csrf") ?: "")
        h.put("channel", Device.CHANNEL)
        h.put("requestId", System.currentTimeMillis().toString() + "_" + (Math.random() * 1000).toInt().toString().padStart(4, '0'))
        Session.get("MUSIC_U")?.takeIf { it.isNotEmpty() }?.let { h.put("MUSIC_U", it) }
        Session.get("MUSIC_A")?.takeIf { it.isNotEmpty() }?.let { h.put("MUSIC_A", it) }
        return h
    }

    private fun eapiCookie(ctx: Context): String {
        val h = buildEapiHeader(ctx)
        val parts = ArrayList<String>()
        val it = h.keys()
        while (it.hasNext()) {
            val k = it.next()
            parts.add(URLEncoder.encode(k, "UTF-8") + "=" + URLEncoder.encode(h.getString(k), "UTF-8"))
        }
        return parts.joinToString("; ")
    }

    private fun handleSetCookies(resp: Http.Resp) {
        resp.setCookies.forEach { sc ->
            val i = sc.indexOf(';')
            val pair = if (i > 0) sc.substring(0, i) else sc
            val eq = pair.indexOf('=')
            if (eq > 0) {
                val k = pair.substring(0, eq).trim()
                val v = pair.substring(eq + 1).trim()
                if (k.isNotEmpty() && v.isNotEmpty()) Session.put(k, v)
            }
        }
    }

    private fun parseObj(resp: Http.Resp): JSONObject {
        handleSetCookies(resp)
        return try {
            JSONObject(resp.body)
        } catch (e: Exception) {
            JSONObject().put("code", -1).put("message", "网络异常: ${resp.body.take(120)}")
        }
    }

    private fun callWeapi(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        Session.get("__csrf")?.takeIf { it.isNotEmpty() }?.let { payload.put("csrf_token", it) }
        val (params, encSecKey) = NeteaseCrypto.weapi(payload.toString())
        val resp = Http.postForm(
            DOMAIN + "/weapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params, "encSecKey" to encSecKey),
            Session.cookieHeader(),
            mapOf("Referer" to DOMAIN, "User-Agent" to UA_WEAPI)
        )
        return parseObj(resp)
    }

    private fun callEapi(ctx: Context, uri: String, data: JSONObject): JSONObject {
        val payload = JSONObject(data.toString())
        payload.put("header", buildEapiHeader(ctx))
        val params = NeteaseCrypto.eapi(uri, payload.toString())
        val resp = Http.postForm(
            API_DOMAIN + "/eapi/" + uri.removePrefix("/api/"),
            mapOf("params" to params),
            eapiCookie(ctx),
            mapOf("User-Agent" to UA_API)
        )
        return parseObj(resp)
    }

    // ================= 登录 =================

    // ---- 匿名 token (MUSIC_A, 对齐官方客户端流程) ----

    /** XOR + MD5 + Base64 (cloudmusic_dll_encode_id) */
    private fun cloudmusicDllEncodeId(id: String): String {
        val key = "3go8&$8*3*3h0k(2)2"
        val sb = StringBuilder()
        for (i in id.indices) {
            sb.append((id[i].code xor key[i % key.length].code).toChar())
        }
        val md = java.security.MessageDigest.getInstance("MD5")
        return android.util.Base64.encodeToString(
            md.digest(sb.toString().toByteArray(Charsets.UTF_8)),
            android.util.Base64.NO_WRAP
        )
    }

    /** 注册匿名账号, 获得 MUSIC_A cookie */
    fun registerAnonymous(ctx: Context): Boolean {
        return try {
            val deviceId = Device.id(ctx)
            val encoded = android.util.Base64.encodeToString(
                "$deviceId ${cloudmusicDllEncodeId(deviceId)}".toByteArray(Charsets.UTF_8),
                android.util.Base64.NO_WRAP
            )
            val j = callWeapi(ctx, "/api/register/anonimous", JSONObject().put("username", encoded))
            if (!Session.has("MUSIC_A")) {
                j.optString("token", "").takeIf { it.isNotBlank() }?.let { Session.put("MUSIC_A", it) }
            }
            Session.has("MUSIC_A")
        } catch (_: Exception) {
            false
        }
    }

    /** 确保存在匿名 token (未登录时请求登录/扫码前调用) */
    fun ensureAnonymous(ctx: Context) {
        if (Session.isLoggedIn()) return
        if (Session.has("MUSIC_A")) return
        registerAnonymous(ctx)
    }

    /** 二维码登录: 获取 unikey */
    fun qrKey(ctx: Context): String {
        ensureAnonymous(ctx)
        val j = callEapi(ctx, "/api/login/qrcode/unikey", JSONObject().put("type", 3))
        val inner = j.optJSONObject("data")
        val key = inner?.optString("unikey", "")?.takeIf { it.isNotEmpty() } ?: j.optString("unikey", "")
        return key
    }

    /** 二维码登录: 轮询状态, 返回原始 JSON (code: 800过期/801等待/802已扫/803成功) */
    fun qrCheck(ctx: Context, key: String): JSONObject {
        return callEapi(ctx, "/api/login/qrcode/client/login", JSONObject().put("key", key).put("type", 3))
    }

    /** 手机号: 发送短信验证码 */
    fun sendCaptcha(ctx: Context, phone: String, ctcode: String = "86"): JSONObject {
        return callWeapi(ctx, "/api/sms/captcha/sent", JSONObject()
            .put("ctcode", ctcode)
            .put("cellphone", phone))
    }

    /** 手机号: 预校验验证码 (官方 App 流程: 发送 -> 校验 -> 登录) */
    fun verifyCaptcha(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        return callWeapi(ctx, "/api/sms/captcha/verify", JSONObject()
            .put("ctcode", ctcode)
            .put("cellphone", phone)
            .put("captcha", captcha))
    }

    /** 手机号: 验证码登录 */
    fun loginByCaptcha(ctx: Context, phone: String, captcha: String, ctcode: String = "86"): JSONObject {
        ensureAnonymous(ctx)
        return callWeapi(ctx, "/api/login/cellphone", JSONObject()
            .put("phone", phone)
            .put("countrycode", ctcode)
            .put("captcha", captcha)
            .put("rememberLogin", "true"))
    }

    /** 刷新登录态 (延长 cookie 有效期) */
    fun refreshLogin(ctx: Context): JSONObject {
        return callEapi[](mqqapi://markdown/node?nodeType=loading)
