package com.xbfhm.misakamusic.net

import android.content.Context

/** 模拟网易云官方 App 的设备信息 (对齐 osMap/android) */
object Device {
    const val OS = "android"
    const val APPV = "9.1.65.240927161425"
    const val OSVER = "14"
    const val CHANNEL = "xiaomi"
    const val VERSION_CODE = "9001065"
    const val MOBILE_NAME = "23013RK75C"
    const val RESOLUTION = "1440x3200"

    private var cachedId: String? = null

    fun id(ctx: Context): String {
        cachedId?.let { return it }
        val p = ctx.getSharedPreferences("device", Context.MODE_PRIVATE)
        cachedId = p.getString("deviceId", null) ?: run {
            val chars = "0123456789ABCDEF"
            val sb = StringBuilder(52)
            repeat(52) { sb.append(chars[(Math.random() * 16).toInt()]) }
            val id = sb.toString()
            p.edit().putString("deviceId", id).apply()
            id
        }
        return cachedId!!
    }
}
