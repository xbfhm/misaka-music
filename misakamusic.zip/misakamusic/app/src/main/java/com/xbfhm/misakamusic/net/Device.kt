package com.xbfhm.misakamusic.net

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

/** 模拟网易云官方 App 的设备信息
 *  品牌/型号/系统版本/分辨率 自动读取本机真实信息,
 *  避免"真我 GT5 扫码却上报小米 13"导致环境异常风控。
 *  网易云 App 版本号仍保持较新官方版本, 防止"版本过低"。
 */
object Device {
    const val OS = "android"
    // 网易云 App 版本号(不可从本机读取, 保持官方较新版本)
    const val APPV = "9.1.65.240927161425"
    const val VERSION_CODE = "9001065"

    // 以下字段在 App 启动时自动初始化为本机真实信息
    lateinit var OSVER: String
    lateinit var CHANNEL: String
    lateinit var MOBILE_NAME: String
    lateinit var RESOLUTION: String

    /** 初始化设备信息, 必须在 Application.onCreate 中最早调用 */
    fun init(ctx: Context) {
        OSVER = Build.VERSION.RELEASE ?: "14"
        CHANNEL = Build.BRAND?.lowercase()?.takeIf { it.isNotBlank() } ?: "android"
        MOBILE_NAME = Build.MODEL ?: "Android"
        RESOLUTION = readResolution(ctx)
        // 确保 deviceId 提前生成并持久化
        id(ctx)
    }

    private fun readResolution(ctx: Context): String {
        return try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            wm.defaultDisplay.getMetrics(metrics)
            "${metrics.widthPixels}x${metrics.heightPixels}"
        } catch (_: Exception) {
            "2400x1080"
        }
    }

    private var cachedId: String? = null

    fun id(ctx: Context): String {
        cachedId?.let { return it }
        val p = ctx.getSharedPreferences("device", Context.MODE_PRIVATE)
        cachedId = p.getString("deviceId", null) ?: run {
            val chars = "0123456789ABCDEF"
            val sb = StringBuilder(52)
            repeat(52) { sb.append(chars[(Math.random() * 16).toInt()]) }
            val id = sb.toString()
            p.edit().putString("deviceId", id).apply()
            id
        }
        return cachedId!!
    }
}
