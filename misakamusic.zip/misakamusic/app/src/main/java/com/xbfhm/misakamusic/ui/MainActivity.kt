package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.BuildConfig
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityMainBinding
import com.xbfhm.misakamusic.model.Playlist
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val songAdapter = SongAdapter { index -> playSong(index) }
    private var currentSongs: List<Song> = emptyList()
    private var searching = false
    private var liked: Playlist? = null

    /** 首页列表的队列标记 (区别于歌单 id) */
    private val HOME_TAG = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = songAdapter

        // 版本号水印 (一眼分辨新旧版)
        binding.tvVersion.text = "v${BuildConfig.VERSION_NAME}"

        binding.btnSettings.setOnClickListener { openSettings() }
        binding.avatar.setOnClickListener { openSettings() }

        // 搜索
        binding.etSearch.setOnEditorActionListener { _: TextView?, actionId: Int, _: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(binding.etSearch.text.toString().trim())
                true
            } else false
        }
        binding.btnClearSearch.setOnClickListener { clearSearch() }

        // 登录后功能
        binding.likedCard.setOnClickListener {
            liked?.let { openPlaylist(it) } ?: toast("未找到「我喜欢的音乐」")
        }
        binding.playlistsCard.setOnClickListener {
            startActivity(Intent(this, PlaylistsActivity::class.java))
        }

        // 换一批推荐
        binding.btnRefresh.setOnClickListener {
            if (searching) doSearch(binding.etSearch.text.toString().trim())
            else loadRecommendations()
        }

        // 迷你播放条
        binding.miniBar.setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.miniPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updateMiniPlayer()
        }

        loadRecommendations()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { _ -> runOnUiThread { updateMiniPlayer() } }
        PlayerEngine.onPlayState = { runOnUiThread { updateMiniPlayer() } }
        updateMiniPlayer()
        updateHeader()
        updateHighlight()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
    }

    // ---------------- 搜索 ----------------

    private fun doSearch(keyword: String) {
        if (keyword.isEmpty()) {
            toast(getString(R.string.search_empty))
            clearSearch()
            return
        }
        searching = true
        binding.tvSectionTitle.text = getString(R.string.section_search)
        binding.btnClearSearch.visibility = View.VISIBLE
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                NeteaseApi.search(this@MainActivity, keyword, 30)
            }
            currentSongs = list
            songAdapter.submit(list)
            if (list.isEmpty()) toast("没有找到相关歌曲")
        }
    }

    private fun clearSearch() {
        searching = false
        binding.etSearch.setText("")
        binding.btnClearSearch.visibility = View.GONE
        binding.tvSectionTitle.text = getString(R.string.section_recommend)
        binding.etSearch.clearFocus()
        hideKeyboard()
        loadRecommendations()
    }

    // ---------------- 推荐 ----------------

    private fun loadRecommendations() {
        binding.tvSectionTitle.text = getString(R.string.section_recommend)
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                NeteaseApi.recommendAnime(this@MainActivity, 20)
            }
            currentSongs = list
            songAdapter.submit(list)
            if (list.isEmpty()) toast("推荐获取失败，请检查网络")
        }
    }

    // ---------------- 播放 ----------------

    private fun playSong(index: Int) {
        if (index !in currentSongs.indices) return
        PlayerEngine.setPlaylist(HOME_TAG, currentSongs, index)
        songAdapter.currentIndex = PlayerEngine.currentIndex
        songAdapter.notifyDataSetChanged()
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun updateHighlight() {
        if (PlayerEngine.queueTag == HOME_TAG) {
            songAdapter.currentIndex = PlayerEngine.currentIndex
        } else {
            songAdapter.currentIndex = -1
        }
        songAdapter.notifyDataSetChanged()
    }

    // ---------------- 头部/登录态 ----------------

    private fun updateHeader() {
        val logged = Session.isLoggedIn()
        if (logged) {
            binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
            binding.avatar.visibility = View.VISIBLE
            Glide.with(this)
                .load(Session.avatar)
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .into(binding.avatar)
            if (liked == null) loadLikedAndPlaylists()
        } else {
            binding.tvNickname.text = getString(R.string.not_logged_in)
            binding.avatar.visibility = View.GONE
            binding.likedCard.visibility = View.GONE
            binding.playlistsCard.visibility = View.GONE
        }
    }

    private fun loadLikedAndPlaylists() {
        scope.launch {
            if (Session.uid <= 0) {
                val info = withContext(Dispatchers.IO) { NeteaseApi.accountInfo(this@MainActivity) }
                val profile = info.optJSONObject("profile")
                Session.uid = profile?.optLong("userId", 0) ?: 0
                Session.nickname = profile?.optString("nickname", "") ?: ""
                Session.avatar = profile?.optString("avatarUrl", "") ?: ""
                binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
            }
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@MainActivity, Session.uid)
            }
            liked = playlists.firstOrNull { it.isLiked }
            if (liked != null) {
                binding.likedCard.visibility = View.VISIBLE
                binding.likedInfo.text = "${liked!!.trackCount} 首"
                Glide.with(this@MainActivity)
                    .load(liked!!.cover)
                    .placeholder(R.drawable.ic_music_note)
                    .into(binding.likedCover)
            } else {
                binding.likedCard.visibility = View.GONE
            }
            binding.playlistsCard.visibility = View.VISIBLE
        }
    }

    private fun openPlaylist(p: Playlist) {
        val intent = Intent(this, PlaylistActivity::class.java)
        intent.putExtra(PlaylistActivity.EXTRA_ID, p.id)
        intent.putExtra(PlaylistActivity.EXTRA_NAME, p.name)
        startActivity(intent)
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    // ---------------- 迷你播放条 ----------------

    private fun updateMiniPlayer() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            binding.miniBar.visibility = View.GONE
            return
        }
        binding.miniBar.visibility = View.VISIBLE
        binding.miniTitle.text = song.name
        binding.miniArtist.text = song.artists
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .into(binding.miniCover)
        binding.miniPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun hideKeyboard() {
        val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
                as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(binding.etSearch.windowToken, 0)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
