package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.BuildConfig
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityMainBinding
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val fragments: List<Fragment> = listOf(
        RecommendFragment(),
        PlaylistsFragment(),
        SearchFragment()
    )
    private var currentIndex = 0
    private var brandClickCount = 0
    private var brandClickTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvVersion.text = "v${BuildConfig.VERSION_NAME}"

        // 隐藏日志入口: 点击左上角红色 "misakamusic" 5 次打开日志页
        binding.tvBrand.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - brandClickTime > 1500) brandClickCount = 0
            brandClickTime = now
            brandClickCount++
            if (brandClickCount >= 5) {
                brandClickCount = 0
                startActivity(Intent(this, LogActivity::class.java))
            }
        }

        binding.btnSettings.setOnClickListener { openSettings() }
        binding.avatar.setOnClickListener { openSettings() }

        binding.navRecommend.setOnClickListener { switchTab(0) }
        binding.navPlaylists.setOnClickListener { switchTab(1) }
        binding.navSearch.setOnClickListener { switchTab(2) }

        binding.miniBar.setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.miniPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updateMiniPlayer()
        }

        updateHeader()
        switchTab(0)
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { _ -> runOnUiThread { updateMiniPlayer() } }
        PlayerEngine.onPlayState = { runOnUiThread { updateMiniPlayer() } }
        updateMiniPlayer()
        updateHeader()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
    }

    // ---------------- 底部导航切换 ----------------

    private val fragmentTags = listOf("tab_recommend", "tab_playlists", "tab_search")

    private fun switchTab(index: Int) {
        if (index !in fragmentTags.indices) return
        val fm = supportFragmentManager
        val tag = fragmentTags[index]
        val target = fm.findFragmentByTag(tag) ?: fragments[index]
        val tx = fm.beginTransaction()
        // 先隐藏所有已添加的 fragment, 避免叠加
        fm.fragments.forEach { f ->
            if (f.isAdded && f != target) tx.hide(f)
        }
        if (target.isAdded) tx.show(target) else tx.add(R.id.fragmentContainer, target, tag)
        tx.commitNowAllowingStateLoss()
        currentIndex = index
        updateNavUI(index)
    }

    private fun updateNavUI(index: Int) {
        val primary = ContextCompat.getColor(this, R.color.net_red)
        val secondary = ContextCompat.getColor(this, android.R.color.darker_gray)

        binding.iconRecommend.setColorFilter(if (index == 0) primary else secondary)
        binding.tvRecommend.setTextColor(if (index == 0) primary else secondary)
        binding.iconPlaylists.setColorFilter(if (index == 1) primary else secondary)
        binding.tvPlaylists.setTextColor(if (index == 1) primary else secondary)
        binding.iconSearch.setColorFilter(if (index == 2) primary else secondary)
        binding.tvSearch.setTextColor(if (index == 2) primary else secondary)
    }

    // ---------------- 头部/登录态 ----------------

    private fun updateHeader() {
        if (Session.isLoggedIn()) {
            binding.tvNickname.text = Session.nickname.ifEmpty { "网易云用户" }
            binding.avatar.visibility = View.VISIBLE
            Glide.with(this)
                .load(Session.avatar)
                .placeholder(R.drawable.ic_account)
                .error(R.drawable.ic_account)
                .into(binding.avatar)
        } else {
            binding.tvNickname.text = getString(R.string.not_logged_in)
            binding.avatar.visibility = View.GONE
        }
    }

    // ---------------- 迷你播放条 ----------------

    private fun updateMiniPlayer() {
        val song = PlayerEngine.currentSong()
        if (song == null) {
            binding.miniBar.visibility = View.GONE
            return
        }
        binding.miniBar.visibility = View.VISIBLE
        binding.miniTitle.text = song.name
        binding.miniArtist.text = song.artists
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .into(binding.miniCover)
        binding.miniPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
