package com.xbfhm.misakamusic.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/**
 * 波形进度条 (namida 风格 Waveform Seekbar)
 *
 * 由于是流媒体音源、无本地音频文件, 用「歌曲 id 作为随机种子」生成稳定的伪随机波形,
 * 使同一首歌的波形保持一致、不同歌曲波形各异, 视觉上接近真实波形图。
 *
 * 已播放部分用主题色(封面取色)填充, 未播放部分用半透明灰。
 * 支持点击/拖动定位 (拖动结束才回调 seek, 避免流媒体频繁请求)。
 */
class WaveSeekBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val playedPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val unplayedPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private var bars = FloatArray(80) { 0.15f + 0.85f * abs(sin(it * 0.7f)) }

    var max: Int = 1000
        set(value) { field = value.coerceAtLeast(1); invalidate() }
    var progress: Int = 0
        set(value) { field = value.coerceIn(0, max); invalidate() }

    var accentColor: Int = Color.WHITE
        set(value) { field = value; invalidate() }

    var onSeekListener: ((Int) -> Unit)? = null

    private var dragging = false

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        playedPaint.color = Color.WHITE
        unplayedPaint.color = Color.argb(70, 255, 255, 255)
    }

    /** 根据歌曲 id 生成稳定的波形数据 */
    fun setWaveform(seed: Long) {
        val rnd = Random(seed.toInt())
        bars = FloatArray(80) { i ->
            val base = 0.35f + 0.35f * abs(sin(i * 0.45f + (seed % 10).toFloat()))
            val spike = 0.3f * abs(rnd.nextFloat())
            (base + spike).coerceIn(0.12f, 0.98f)
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        playedPaint.color = accentColor
        val barW = w / bars.size
        val gap = barW * 0.28f
        val barDrawW = barW - gap
        val playedRatio = if (max > 0) progress.toFloat() / max else 0f

        for (i in bars.indices) {
            val centerX = i * barW + barW / 2f
            val barH = h * bars[i]
            val top = (h - barH) / 2f
            rect.set(centerX - barDrawW / 2f, top, centerX + barDrawW / 2f, top + barH)
            val barRatio = (i + 0.5f) / bars.size
            val paint = if (barRatio <= playedRatio) playedPaint else unplayedPaint
            canvas.drawRoundRect(rect, barDrawW / 2f, barDrawW / 2f, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                updateFromTouch(event.x, false)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) { updateFromTouch(event.x, false); return true }
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                updateFromTouch(event.x, true)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun updateFromTouch(x: Float, notify: Boolean) {
        val ratio = (x / width.toFloat()).coerceIn(0f, 1f)
        progress = (ratio * max).toInt()
        if (notify) onSeekListener?.invoke(progress)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        invalidate()
    }
}
