package com.xbfhm.misakamusic.net

import android.content.Context

/** 登录会话: cookie 持久化 + 用户资料 */
object Session {
    private const val PREFS = "session"
    private lateinit var appCtx: Context
    private val cookies = LinkedHashMap<String, String>()

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        load()
        ensureDeviceCookies()
    }

    private fun prefs() = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun load() {
        cookies.clear()
        val raw = prefs().getString("cookies", null)
        if (raw != null) {
            val parts: List<String> = raw.split(";")
            for (part in parts) {
                val i = part.indexOf('=')
                if (i > 0) {
                    val k = part.substring(0, i).trim()
                    val v = part.substring(i + 1).trim()
                    if (k.isNotEmpty()) cookies[k] = v
                }
            }
        }
    }

    private fun save() {
        prefs().edit()
            .putString("cookies", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
            .apply()
    }

    /** 补充设备相关 cookie (对齐 request.js processCookieObject) */
    private fun ensureDeviceCookies() {
        var changed = false
        if (!cookies.containsKey("_ntes_nuid")) {
            cookies["_ntes_nuid"] = randomHex(32)
            changed = true
        }
        if (!cookies.containsKey("os")) { cookies["os"] = Device.OS; changed = true }
        if (!cookies.containsKey("osver")) { cookies["osver"] = Device.OSVER; changed = true }
        if (!cookies.containsKey("appver")) { cookies["appver"] = Device.APPV; changed = true }
        if (!cookies.containsKey("channel")) { cookies["channel"] = Device.CHANNEL; changed = true }
        if (!cookies.containsKey("WEVNSM")) { cookies["WEVNSM"] = "1.0.0"; changed = true }
        if (!cookies.containsKey("__remember_me")) { cookies["__remember_me"] = "true"; changed = true }
        if (changed) save()
    }

    private fun randomHex(len: Int): String {
        val chars = "0123456789abcdef"
        val sb = StringBuilder(len)
        repeat(len) { sb.append(chars[(Math.random() * 16).toInt()]) }
        return sb.toString()
    }

    /** 从 Set-Cookie 或响应体 cookie 字段吸收 */
    fun absorbCookieString(str: String) {
        if (str.isBlank()) return
        str.split(";").forEach { part ->
            val i = part.indexOf('=')
            if (i > 0) {
                val k = part.substring(0, i).trim()
                val v = part.substring(i + 1).trim()
                if (k.isNotEmpty()) cookies[k] = v
            }
        }
        save()
    }

    fun put(key: String, value: String) {
        cookies[key] = value
        save()
    }

    fun get(key: String): String? = cookies[key]

    fun has(key: String): Boolean = !cookies[key].isNullOrEmpty()

    fun cookieHeader(): String =
        cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }

    fun isLoggedIn(): Boolean = has("MUSIC_U")

    fun clearLogin() {
        cookies.clear()
        save()
        prefs().edit().remove("nickname").remove("avatar").remove("uid").apply()
    }

    // ---- 用户资料 ----
    var nickname: String
        get() = prefs().getString("nickname", "") ?: ""
        set(v) { prefs().edit().putString("nickname", v).apply() }

    var avatar: String
        get() = prefs().getString("avatar", "") ?: ""
        set(v) { prefs().edit().putString("avatar", v).apply() }

    var uid: Long
        get() = prefs().getLong("uid", 0)
        set(v) { prefs().edit().putLong("uid", v).apply() }
}
