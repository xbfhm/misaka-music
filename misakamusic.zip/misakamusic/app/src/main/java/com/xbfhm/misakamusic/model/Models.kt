package com.xbfhm.misakamusic.model

data class Song(
    val id: Long,
    val name: String,
    val artists: String,
    val album: String,
    val duration: Long,
    val cover: String,
    val fee: Int = 0,   // 0=免费, 1=VIP
    val alias: String = ""  // 翻译名/别名 (如日文歌的中文译名)
)

data class Playlist(
    val id: Long,
    val name: String,
    val cover: String,
    val trackCount: Int,
    val playCount: Long,
    val isLiked: Boolean = false
)

/** 网易云用户 (搜索用户结果) */
data class User(
    val id: Long,
    val nickname: String,
    val avatar: String,
    val signature: String
)
