package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityPlayerBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var dragging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!PlayerEngine.hasQueue()) {
            finish()
            return
        }

        binding.btnMode.setOnClickListener {
            PlayerEngine.toggleMode()
            updateModeIcon()
            toast(PlayerEngine.playModeLabel())
        }
        binding.btnTimer.setOnClickListener { showTimerDialog() }
        binding.btnPrev.setOnClickListener { PlayerEngine.prev() }
        binding.btnNext.setOnClickListener { PlayerEngine.next() }
        binding.btnPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updatePlayBtn()
        }
        binding.btnFav.setOnClickListener { onFavClick() }
        binding.cover.setOnClickListener {
            startActivity(Intent(this, LyricActivity::class.java))
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.tvCur.text = formatMs(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dragging = false
                PlayerEngine.seekTo(seekBar?.progress?.toLong() ?: 0)
            }
        })

        updateModeIcon()
        renderSong(PlayerEngine.currentSong())
        ensureLikedLoaded()
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { s -> runOnUiThread { renderSong(s) } }
        PlayerEngine.onPlayState = { runOnUiThread { updatePlayBtn() } }
        renderSong(PlayerEngine.currentSong())
        updatePlayBtn()
        ensureLikedLoaded()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    private fun renderSong(song: Song?) {
        if (song == null) {
            finish()
            return
        }
        binding.tvName.text = song.name
        if (song.alias.isNotBlank() && song.alias != song.name) {
            binding.tvAlias.visibility = View.VISIBLE
            binding.tvAlias.text = "${getString(R.string.alias_title)}：${song.alias}"
        } else {
            binding.tvAlias.visibility = View.GONE
        }
        binding.tvArtist.text = song.artists
        renderQuality(song)
        updateFavIcon(song)
        binding.tvDur.text = formatMs(song.duration)
        binding.seekBar.max = song.duration.toInt().coerceAtLeast(1)
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(binding.cover)
        updatePlayBtn()
    }

    /** 音质 + VIP 标签 */
    private fun renderQuality(song: Song) {
        val label = when (Session.quality) {
            "standard" -> getString(R.string.quality_standard)
            "higher" -> getString(R.string.quality_higher)
            "exhigh" -> getString(R.string.quality_exhigh)
            "lossless" -> getString(R.string.quality_lossless)
            "hires" -> getString(R.string.quality_hires)
            else -> getString(R.string.quality_exhigh)
        }
        val vip = if (song.fee > 0) " · ${getString(R.string.vip_tag)}" else ""
        binding.tvQuality.text = "$label$vip"
    }

    private fun currentSong(): Song? = PlayerEngine.currentSong()

    // ---------------- 收藏 ----------------

    private fun updateFavIcon(song: Song) {
        val liked = if (Session.isLoggedIn()) Session.isLiked(song.id) else Session.isLocalLiked(song.id)
        binding.btnFav.setImageResource(
            if (liked) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
        val tint = ContextCompat.getColor(
            this,
            if (liked) R.color.net_red else android.R.color.darker_gray
        )
        binding.btnFav.setColorFilter(tint)
    }

    private fun ensureLikedLoaded() {
        if (!Session.isLoggedIn() || Session.likedLoaded) return
        scope.launch {
            val ids = withContext(Dispatchers.IO) {
                NeteaseApi.likelist(this@PlayerActivity, Session.uid)
            }
            Session.setLikedIds(ids)
            renderSong(PlayerEngine.currentSong())
        }
    }

    private fun onFavClick() {
        val song = currentSong() ?: return
        if (Session.isLoggedIn()) {
            if (Session.isLiked(song.id)) {
                unlikeSong(song)
            } else {
                showFavOptions(song)
            }
        } else {
            val liked = Session.toggleLocalLiked(song.id)
            updateFavIcon(song)
            toast(
                if (liked) getString(R.string.fav_success_local)
                else getString(R.string.fav_cancel_local)
            )
        }
    }

    private fun showFavOptions(song: Song) {
        val options = arrayOf(
            getString(R.string.fav_add_liked),
            getString(R.string.fav_add_playlist)
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.fav_song))
            .setItems(options) { _: DialogInterface?, which: Int ->
                when (which) {
                    0 -> likeSong(song)
                    1 -> showPlaylistPicker(song)
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun likeSong(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@PlayerActivity, song.id, true)
            }
            if (j.optInt("code", -1) == 200) {
                Session.setLiked(song.id, true)
                updateFavIcon(song)
                toast(getString(R.string.fav_success))
            } else {
                toast(getString(R.string.fav_fail))
            }
        }
    }

    private fun unlikeSong(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@PlayerActivity, song.id, false)
            }
            if (j.optInt("code", -1) == 200) {
                Session.setLiked(song.id, false)
                updateFavIcon(song)
                toast(getString(R.string.fav_cancel))
            } else {
                toast(getString(R.string.fav_fail))
            }
        }
    }

    /** 弹窗选择要加入的歌单 */
    private fun showPlaylistPicker(song: Song) {
        scope.launch {
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@PlayerActivity, Session.uid)
            }
            if (playlists.isEmpty()) {
                toast(getString(R.string.user_no_playlist))
                return@launch
            }
            val names = playlists.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(this@PlayerActivity)
                .setTitle(getString(R.string.fav_add_playlist))
                .setItems(names) { _: DialogInterface?, which: Int ->
                    addSongToPlaylist(song, playlists[which].id)
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun addSongToPlaylist(song: Song, pid: Long) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.addSongToPlaylist(this@PlayerActivity, pid, listOf(song.id))
            }
            toast(
                if (j.optInt("code", -1) == 200) getString(R.string.fav_success)
                else getString(R.string.fav_fail)
            )
        }
    }

    // ---------------- 播放控制 UI ----------------

    private fun updatePlayBtn() {
        binding.btnPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateModeIcon() {
        val icon = when (PlayerEngine.mode) {
            PlayMode.ORDER -> R.drawable.ic_order
            PlayMode.LOOP -> R.drawable.ic_repeat
            PlayMode.SHUFFLE -> R.drawable.ic_shuffle
        }
        binding.btnMode.setImageResource(icon)
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                if (!dragging) {
                    val pos = PlayerEngine.player.currentPosition
                    binding.seekBar.progress = pos.toInt()
                    binding.tvCur.text = formatMs(pos)
                }
                updatePlayBtn()
                updateSleepText()
            }
        }
    }

    private fun updateSleepText() {
        if (PlayerEngine.hasSleepTimer()) {
            binding.tvSleep.visibility = View.VISIBLE
            val ms = PlayerEngine.sleepRemainingMs()
            val s = ms / 1000
            binding.tvSleep.text =
                "${getString(R.string.sleep_remaining)} %d:%02d".format(s / 60, s % 60)
        } else {
            binding.tvSleep.visibility = View.GONE
        }
    }

    private fun showTimerDialog() {
        val options = arrayOf("15 ${getString(R.string.sleep_minutes)}", "30 ${getString(R.string.sleep_minutes)}", "45 ${getString(R.string.sleep_minutes)}", "60 ${getString(R.string.sleep_minutes)}", getString(R.string.sleep_cancel))
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.sleep_timer))
            .setItems(options) { _: DialogInterface?, which: Int ->
                when (which) {
                    0, 1, 2, 3 -> {
                        PlayerEngine.setSleepTimer(listOf(15, 30, 45, 60)[which])
                        toast("${options[which]}后自动停止播放")
                    }
                    4 -> {
                        PlayerEngine.cancelSleepTimer()
                        toast(getString(R.string.sleep_canceled))
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
    }
}
