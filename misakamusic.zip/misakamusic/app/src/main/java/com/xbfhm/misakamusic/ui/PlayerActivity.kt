package com.xbfhm.misakamusic.ui

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityPlayerBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var dragging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!PlayerEngine.hasQueue()) {
            finish()
            return
        }

        binding.btnMode.setOnClickListener {
            PlayerEngine.toggleMode()
            updateModeIcon()
            toast(PlayerEngine.playModeLabel())
        }
        binding.btnPrev.setOnClickListener { PlayerEngine.prev() }
        binding.btnNext.setOnClickListener { PlayerEngine.next() }
        binding.btnPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updatePlayBtn()
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.tvCur.text = formatMs(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dragging = false
                PlayerEngine.seekTo(seekBar?.progress?.toLong() ?: 0)
            }
        })

        updateModeIcon()
        renderSong(PlayerEngine.currentSong())
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { s -> runOnUiThread { renderSong(s) } }
        PlayerEngine.onPlayState = { runOnUiThread { updatePlayBtn() } }
        renderSong(PlayerEngine.currentSong())
        updatePlayBtn()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    private fun renderSong(song: Song?) {
        if (song == null) {
            finish()
            return
        }
        binding.tvName.text = song.name
        binding.tvArtist.text = song.artists
        binding.tvDur.text = formatMs(song.duration)
        binding.seekBar.max = song.duration.toInt().coerceAtLeast(1)
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(binding.cover)
        updatePlayBtn()
    }

    private fun updatePlayBtn() {
        binding.btnPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateModeIcon() {
        val icon = when (PlayerEngine.mode) {
            PlayMode.ORDER -> R.drawable.ic_order
            PlayMode.LOOP -> R.drawable.ic_repeat
            PlayMode.SHUFFLE -> R.drawable.ic_shuffle
        }
        binding.btnMode.setImageResource(icon)
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                if (!dragging) {
                    val pos = PlayerEngine.player.currentPosition
                    binding.seekBar.progress = pos.toInt()
                    binding.tvCur.text = formatMs(pos)
                }
                updatePlayBtn()
            }
        }
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
    }
}
