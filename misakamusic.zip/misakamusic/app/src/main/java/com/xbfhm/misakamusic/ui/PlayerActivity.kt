package com.xbfhm.misakamusic.ui

import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityPlayerBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var dragging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!PlayerEngine.hasQueue()) {
            finish()
            return
        }

        binding.btnMode.setOnClickListener {
            PlayerEngine.toggleMode()
            updateModeIcon()
            toast(PlayerEngine.playModeLabel())
        }
        binding.btnTimer.setOnClickListener { showTimerDialog() }
        binding.btnPrev.setOnClickListener { PlayerEngine.prev() }
        binding.btnNext.setOnClickListener { PlayerEngine.next() }
        binding.btnPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updatePlayBtn()
        }
        binding.btnFav.setOnClickListener { onFavClick() }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.tvCur.text = formatMs(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dragging = false
                PlayerEngine.seekTo(seekBar?.progress?.toLong() ?: 0)
            }
        })

        updateModeIcon()
        renderSong(PlayerEngine.currentSong())
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { s -> runOnUiThread { renderSong(s) } }
        PlayerEngine.onPlayState = { runOnUiThread { updatePlayBtn() } }
        renderSong(PlayerEngine.currentSong())
        updatePlayBtn()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    private fun renderSong(song: Song?) {
        if (song == null) {
            finish()
            return
        }
        binding.tvName.text = song.name
        if (song.alias.isNotBlank() && song.alias != song.name) {
            binding.tvAlias.visibility = View.VISIBLE
            binding.tvAlias.text = "${getString(R.string.alias_title)}：${song.alias}"
        } else {
            binding.tvAlias.visibility = View.GONE
        }
        binding.tvArtist.text = song.artists
        updateFavIcon(song)
        binding.tvDur.text = formatMs(song.duration)
        binding.seekBar.max = song.duration.toInt().coerceAtLeast(1)
        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(binding.cover)
        updatePlayBtn()
    }

    private fun currentSong(): Song? = PlayerEngine.currentSong()

    private fun updateFavIcon(song: Song) {
        val liked = if (Session.isLoggedIn()) false else Session.isLocalLiked(song.id)
        binding.btnFav.setImageResource(
            if (liked) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
    }

    private fun onFavClick() {
        val song = currentSong() ?: return
        if (Session.isLoggedIn()) {
            // 已登录: 弹窗选择 加入"我喜欢的音乐" 或 加入歌单
            val options = arrayOf(
                getString(R.string.fav_add_liked),
                getString(R.string.fav_add_playlist)
            )
            MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.fav_song))
                .setItems(options) { _: DialogInterface?, which: Int ->
                    when (which) {
                        0 -> likeToLiked(song)
                        1 -> showPlaylistPicker(song)
                    }
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        } else {
            // 未登录: 本地收藏
            val liked = Session.toggleLocalLiked(song.id)
            updateFavIcon(song)
            toast(
                if (liked) getString(R.string.fav_success_local)
                else getString(R.string.fav_cancel_local)
            )
        }
    }

    private fun likeToLiked(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@PlayerActivity, song.id, true)
            }
            val code = j.optInt("code", -1)
            toast(
                if (code == 200) getString(R.string.fav_success)
                else getString(R.string.fav_fail)
            )
        }
    }

    /** 弹窗选择要加入的歌单 */
    private fun showPlaylistPicker(song: Song) {
        scope.launch {
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@PlayerActivity, Session.uid)
            }
            if (playlists.isEmpty()) {
                toast(getString(R.string.user_no_playlist))
                return@launch
            }
            val names = playlists.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(this@PlayerActivity)
                .setTitle(getString(R.string.fav_add_playlist))
                .setItems(names) { _: DialogInterface?, which: Int ->
                    addSongToPlaylist(song, playlists[which].id)
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun addSongToPlaylist(song: Song, pid: Long) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.addSongToPlaylist(this@PlayerActivity, pid, listOf(song.id))
            }
            val code = j.optInt("code", -1)
            toast(
                if (code == 200) getString(R.string.fav_success)
                else getString(R.string.fav_fail)
            )
        }
    }

    private fun updatePlayBtn() {
        binding.btnPlay.setImageResource(
            if (PlayerEngine.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateModeIcon() {
        val icon = when (PlayerEngine.mode) {
            PlayMode.ORDER -> R.drawable.ic_order
            PlayMode.LOOP -> R.drawable.ic_repeat
            PlayMode.SHUFFLE -> R.drawable.ic_shuffle
        }
        binding.btnMode.setImageResource(icon)
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                if (!dragging) {
                    val pos = PlayerEngine.player.currentPosition
                    binding.seekBar.progress = pos.toInt()
                    binding.tvCur.text = formatMs(pos)
                }
                updatePlayBtn()
                updateSleepText()
            }
        }
    }

    private fun updateSleepText() {
        if (PlayerEngine.hasSleepTimer()) {
            binding.tvSleep.visibility = View.VISIBLE
            val ms = PlayerEngine.sleepRemainingMs()
            val s = ms / 1000
            binding.tvSleep.text =
                "${getString(R.string.sleep_remaining)} %d:%02d".format(s / 60, s % 60)
        } else {
            binding.tvSleep.visibility = View.GONE
        }
    }

    private fun showTimerDialog() {
        val options = arrayOf("15 ${getString(R.string.sleep_minutes)}", "30 ${getString(R.string.sleep_minutes)}", "45 ${getString(R.string.sleep_minutes)}", "60 ${getString(R.string.sleep_minutes)}", getString(R.string.sleep_cancel))
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.sleep_timer))
            .setItems(options) { _: DialogInterface?, which: Int ->
                when (which) {
                    0, 1, 2, 3 -> {
                        PlayerEngine.setSleepTimer(listOf(15, 30, 45, 60)[which])
                        toast("${options[which]}后自动停止播放")
                    }
                    4 -> {
                        PlayerEngine.cancelSleepTimer()
                        toast(getString(R.string.sleep_canceled))
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
    }
}
