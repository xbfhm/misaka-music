package com.xbfhm.misakamusic.ui

import android.Manifest
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityPlayerBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 播放页 (namida 风格): 大圆角方形封面 + 波形进度条 + 动态取色。
 * 点击封面进入歌词页。
 */
class PlayerActivity : BaseActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var dragging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 播放页关闭时向下滑出 (namida 手感)
        backAnimIn = R.anim.fade_in
        backAnimOut = R.anim.slide_out_bottom
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupEdgeToEdge()

        if (!PlayerEngine.hasQueue()) {
            finish()
            return
        }
        requestNotifyPermission()
        applyBlurBackground()

        binding.btnBack.setOnClickListener { finish() }
        binding.btnMode.setOnClickListener {
            PlayerEngine.toggleMode()
            updateModeIcon()
            toast(PlayerEngine.playModeLabel())
        }
        binding.btnTimer.setOnClickListener { showTimerDialog() }
        binding.btnPrev.setOnClickListener { PlayerEngine.prev() }
        binding.btnNext.setOnClickListener { PlayerEngine.next() }
        binding.btnPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updatePlayBtn()
        }
        binding.btnFav.setOnClickListener { onFavClick() }
        binding.cover.setOnClickListener {
            startActivity(Intent(this, LyricActivity::class.java))
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        }
        binding.waveSeek.onSeekListener = { ms ->
            dragging = false
            PlayerEngine.seekTo(ms.toLong())
        }

        updateModeIcon()
        renderSong(PlayerEngine.currentSong())
        ensureLikedLoaded()
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { s -> runOnUiThread { renderSong(s) } }
        PlayerEngine.onPlayState = { runOnUiThread { updatePlayBtn() } }
        renderSong(PlayerEngine.currentSong())
        updatePlayBtn()
        ensureLikedLoaded()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    /** Edge-to-edge 沉浸式: 封面背景延伸到状态栏后, 内容顶栏避开状态栏 (namida 全屏质感) */
    private fun setupEdgeToEdge() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        val base = (12 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            binding.contentRoot.updatePadding(top = top + base)
            insets
        }
    }

    /** 背景高斯模糊: Android 12+ 用 RenderEffect, 低版本降级为半透明 */
    private fun applyBlurBackground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            binding.bgCover.setRenderEffect(
                RenderEffect.createBlurEffect(42f, 42f, Shader.TileMode.CLAMP)
            )
        } else {
            binding.bgCover.alpha = 0.45f
        }
    }

    private fun renderSong(song: Song?) {
        if (song == null) return
        binding.tvName.text = song.name
        binding.tvHeaderTitle.text = getString(R.string.now_playing)
        if (song.alias.isNotBlank() && song.alias != song.name) {
            binding.tvAlias.visibility = View.VISIBLE
            binding.tvAlias.text = "${getString(R.string.alias_title)}：${song.alias}"
        } else {
            binding.tvAlias.visibility = View.GONE
        }
        binding.tvArtist.text = song.artists
        binding.tvHeaderSub.text = renderQuality(song)
        updateFavIcon(song)
        binding.tvDur.text = formatMs(song.duration)
        binding.waveSeek.max = song.duration.toInt().coerceAtLeast(1)
        binding.waveSeek.setWaveform(song.id)

        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(binding.cover)
        Glide.with(this)
            .load(song.cover)
            .into(binding.bgCover)

        // 切歌动效: 封面回弹缩放 + 背景淡入 (namida 质感)
        binding.coverCard.scaleX = 0.92f
        binding.coverCard.scaleY = 0.92f
        binding.coverCard.animate()
            .scaleX(1f).scaleY(1f)
            .setDuration(420)
            .setInterpolator(android.view.animation.OvershootInterpolator(1.4f))
            .start()
        binding.bgCover.alpha = 0f
        binding.bgCover.animate().alpha(1f).setDuration(600).start()

        applyPalette(song.cover)
        updatePlayBtn()
    }

    /** 从封面提取主色, 动态应用到波形 / 播放键 (namida 取色设计) */
    private fun applyPalette(cover: String) {
        if (cover.isBlank()) {
            setAccent(0xFFFFFFFF.toInt())
            return
        }
        scope.launch {
            val palette = try {
                withContext(Dispatchers.IO) {
                    Glide.with(this@PlayerActivity)
                        .asBitmap()
                        .load(cover)
                        .submit()
                        .get()
                        ?.let { Palette.from(it).generate() }
                }
            } catch (_: Exception) { null }
            if (palette == null) return@launch
            val swatch = palette.vibrantSwatch
                ?: palette.dominantSwatch
                ?: palette.mutedSwatch
                ?: return@launch
            runOnUiThread { setAccent(swatch.rgb) }
        }
    }

    private fun setAccent(color: Int) {
        binding.waveSeek.accentColor = color
        binding.btnPlay.backgroundTintList = ColorStateList.valueOf(color)
    }

    /** 音质 + VIP 标签 */
    private fun renderQuality(song: Song): String {
        val label = when (Session.quality) {
            "standard" -> getString(R.string.quality_standard)
            "higher" -> getString(R.string.quality_higher)
            "exhigh" -> getString(R.string.quality_exhigh)
            "lossless" -> getString(R.string.quality_lossless)
            "hires" -> getString(R.string.quality_hires)
            else -> getString(R.string.quality_exhigh)
        }
        val vip = if (song.fee > 0) " · ${getString(R.string.vip_tag)}" else ""
        return "$label$vip"
    }

    private fun currentSong(): Song? = PlayerEngine.currentSong()

    // ---------------- 收藏 ----------------

    private fun updateFavIcon(song: Song) {
        val liked = if (Session.isLoggedIn()) Session.isLiked(song.id) else Session.isLocalLiked(song.id)
        binding.btnFav.setImageResource(
            if (liked) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
        val tint = ContextCompat.getColor(
            this,
            if (liked) R.color.net_red else android.R.color.white
        )
        binding.btnFav.setColorFilter(tint)
    }

    private fun ensureLikedLoaded() {
        if (!Session.isLoggedIn() || Session.likedLoaded) return
        scope.launch {
            val ids = withContext(Dispatchers.IO) {
                NeteaseApi.likelist(this@PlayerActivity, Session.uid)
            }
            Session.setLikedIds(ids)
            renderSong(PlayerEngine.currentSong())
        }
    }

    private fun onFavClick() {
        val song = currentSong() ?: return
        if (Session.isLoggedIn()) {
            if (Session.isLiked(song.id)) {
                unlikeSong(song)
            } else {
                showFavOptions(song)
            }
        } else {
            val liked = Session.toggleLocalLiked(song.id)
            updateFavIcon(song)
            toast(
                if (liked) getString(R.string.fav_success_local)
                else getString(R.string.fav_cancel_local)
            )
        }
    }

    private fun showFavOptions(song: Song) {
        val options = arrayOf(
            getString(R.string.fav_add_liked),
            getString(R.string.fav_add_playlist)
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.fav_song))
            .setItems(options) { _: DialogInterface?, which: Int ->
                when (which) {
                    0 -> likeSong(song)
                    1 -> showPlaylistPicker(song)
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun likeSong(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@PlayerActivity, song.id, true)
            }
            if (j.optInt("code", -1) == 200) {
                Session.setLiked(song.id, true)
                updateFavIcon(song)
                toast(getString(R.string.fav_success))
            } else {
                toast(getString(R.string.fav_fail))
            }
        }
    }

    private fun unlikeSong(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@PlayerActivity, song.id, false)
            }
            if (j.optInt("code", -1) == 200) {
                Session.setLiked(song.id, false)
                updateFavIcon(song)
                toast(getString(R.string.fav_cancel))
            } else {
                toast(getString(R.string.fav_fail))
            }
        }
    }

    /** 弹窗选择要加入的歌单 */
    private fun showPlaylistPicker(song: Song) {
        scope.launch {
            val playlists = withContext(Dispatchers.IO) {
                NeteaseApi.userPlaylists(this@PlayerActivity, Session.uid)
            }
            if (playlists.isEmpty()) {
                toast(getString(R.string.user_no_playlist))
                return@launch
            }
            val names = playlists.map { it.name }.toTypedArray()
            MaterialAlertDialogBuilder(this@PlayerActivity)
                .setTitle(getString(R.string.fav_add_playlist))
                .setItems(names) { _: DialogInterface?, which: Int ->
                    addSongToPlaylist(song, playlists[which].id)
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun addSongToPlaylist(song: Song, pid: Long) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.addSongToPlaylist(this@PlayerActivity, pid, listOf(song.id))
            }
            toast(
                if (j.optInt("code", -1) == 200) getString(R.string.fav_success)
                else getString(R.string.fav_fail)
            )
        }
    }

    // ---------------- 播放控制 UI ----------------

    private fun updatePlayBtn() {
        val playing = PlayerEngine.isPlaying()
        binding.btnPlay.setImageResource(
            if (playing) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateModeIcon() {
        val icon = when (PlayerEngine.mode) {
            PlayMode.ORDER -> R.drawable.ic_order
            PlayMode.LOOP -> R.drawable.ic_repeat
            PlayMode.SHUFFLE -> R.drawable.ic_shuffle
        }
        binding.btnMode.setImageResource(icon)
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                if (!dragging) {
                    val pos = PlayerEngine.player.currentPosition
                    binding.waveSeek.progress = pos.toInt()
                    binding.tvCur.text = formatMs(pos)
                }
                updatePlayBtn()
                updateSleepText()
            }
        }
    }

    private fun updateSleepText() {
        if (PlayerEngine.hasSleepTimer()) {
            binding.tvSleep.visibility = View.VISIBLE
            val ms = PlayerEngine.sleepRemainingMs()
            val s = ms / 1000
            binding.tvSleep.text =
                "${getString(R.string.sleep_remaining)} %d:%02d".format(s / 60, s % 60)
        } else {
            binding.tvSleep.visibility = View.GONE
        }
    }

    private fun showTimerDialog() {
        val options = arrayOf("15 ${getString(R.string.sleep_minutes)}", "30 ${getString(R.string.sleep_minutes)}", "45 ${getString(R.string.sleep_minutes)}", "60 ${getString(R.string.sleep_minutes)}", getString(R.string.sleep_cancel))
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.sleep_timer))
            .setItems(options) { _: DialogInterface?, which: Int ->
                when (which) {
                    0, 1, 2, 3 -> {
                        PlayerEngine.setSleepTimer(listOf(15, 30, 45, 60)[which])
                        toast("${options[which]}后自动停止播放")
                    }
                    4 -> {
                        PlayerEngine.cancelSleepTimer()
                        toast(getString(R.string.sleep_canceled))
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    /** Android 13+ 通知权限 (后台播放/状态栏卡片需要) */
    private fun requestNotifyPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in, R.anim.slide_out_bottom)
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
    }
}
