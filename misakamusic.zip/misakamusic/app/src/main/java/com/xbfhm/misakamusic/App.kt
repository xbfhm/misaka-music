package com.xbfhm.misakamusic

import android.app.Application
import android.util.Log
import com.xbfhm.misakamusic.net.Device
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine
import com.xbfhm.misakamusic.util.Logger

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // 捕获未处理异常, 写入内存日志 (供日志页查看, 定位闪退)
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Logger.log("Crash", "未捕获异常: ${throwable::class.java.simpleName}: ${throwable.message}")
            throwable.stackTrace.take(20).forEach { Logger.log("Crash", "  at $it") }
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // 1. 先初始化真实设备信息(影响后续所有网络请求头/Cookie)
        Device.init(this)
        Session.init(this)
        PlayerEngine.init(this)
        PlayerEngine.urlResolver = { id -> NeteaseApi.resolvePlayUrl(this, id) }
        PlayerEngine.scrobbleReporter = { songId, sourceId, timeSec ->
            NeteaseApi.scrobble(this, songId, sourceId, timeSec)
        }
        // 后台预取匿名 token (MUSIC_A), 提升登录/请求成功率
        Thread {
            try { NeteaseApi.ensureAnonymous(this) } catch (_: Exception) {}
        }.start()

        Logger.log("App", "应用启动完成")
    }
}
