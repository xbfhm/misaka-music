package com.xbfhm.misakamusic

import android.app.Application
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayerEngine

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Session.init(this)
        PlayerEngine.init(this)
        PlayerEngine.urlResolver = { id -> NeteaseApi.resolvePlayUrl(this, id) }
    }
}
