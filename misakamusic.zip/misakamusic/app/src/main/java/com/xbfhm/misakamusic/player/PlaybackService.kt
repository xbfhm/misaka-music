package com.xbfhm.misakamusic.player

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.xbfhm.misakamusic.ui.PlayerActivity

/**
 * 后台播放服务: 通过 MediaSession 向系统暴露播放状态,
 * 让状态栏媒体卡片 / 灵动岛 / 锁屏 / 蓝牙耳机都能显示并控制播放。
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        // 点击通知打开播放页
        val sessionActivity = PendingIntent.getActivity(
            this,
            0,
            Intent(this, PlayerActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        mediaSession = MediaSession.Builder(this, PlayerEngine.player)
            .setSessionActivity(sessionActivity)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // 没队列或没在播放时才停止, 避免误杀后台播放
        if (!PlayerEngine.hasQueue() || !PlayerEngine.isPlaying()) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        // 注意: 只释放 session, 不释放 PlayerEngine.player (全局单例, 还要继续用)
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }
}
