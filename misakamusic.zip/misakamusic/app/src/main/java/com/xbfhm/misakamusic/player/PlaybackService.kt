package com.xbfhm.misakamusic.player

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.xbfhm.misakamusic.ui.PlayerActivity
import com.xbfhm.misakamusic.util.Logger

/**
 * 后台播放服务: 通过 MediaSession 向系统暴露播放状态,
 * 让状态栏媒体卡片 / 灵动岛 / 锁屏 / 蓝牙耳机都能显示并控制播放。
 *
 * 关键点: 必须设置 MediaNotification.Provider, 否则 MediaSessionService
 * 不会调用 startForeground(), 5 秒后系统抛 ForegroundServiceDidNotStartInTimeException
 * 杀掉进程 —— 这正是「播放几秒后返回主界面停止播放」的根因。
 */
@UnstableApi
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        Logger.log("PlaybackService", "onCreate")
        createNotificationChannel()

        // 点击通知打开播放页
        val sessionActivity = PendingIntent.getActivity(
            this,
            0,
            Intent(this, PlayerActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaSession.Builder(this, PlayerEngine.player)
            .setId("misaka_music_session")
            .setSessionActivity(sessionActivity)
            .build()

        // 关键: 注册通知 Provider, 让服务正确进入前台
        val provider = DefaultMediaNotificationProvider.Builder(this)
            .setNotificationId(1001)
            .setChannelId(CHANNEL_ID)
            .build()
        setMediaNotificationProvider(provider)
        Logger.log("PlaybackService", "MediaNotification.Provider 已设置")
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        Logger.log("PlaybackService", "onGetSession")
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Logger.log("PlaybackService", "onTaskRemoved hasQueue=${PlayerEngine.hasQueue()} playing=${PlayerEngine.isPlaying()}")
        // 没队列或没在播放时才停止, 避免误杀后台播放
        if (!PlayerEngine.hasQueue() || !PlayerEngine.isPlaying()) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        Logger.log("PlaybackService", "onDestroy")
        // 注意: 只释放 session, 不释放 PlayerEngine.player (全局单例, 还要继续用)
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "音乐播放",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "正在播放的音乐"
                enableLights(false)
                enableVibration(false)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "misaka_music_channel"
    }
}
