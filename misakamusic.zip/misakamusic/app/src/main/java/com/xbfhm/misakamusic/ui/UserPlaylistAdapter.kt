package com.xbfhm.misakamusic.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ItemUserPlaylistBinding
import com.xbfhm.misakamusic.model.Playlist

/** 用户歌单列表 (带收藏加号) */
class UserPlaylistAdapter(
    private val onClick: (Playlist) -> Unit,
    private val onSubscribe: (Playlist) -> Unit
) : RecyclerView.Adapter<UserPlaylistAdapter.VH>() {

    private val items = mutableListOf<Playlist>()

    fun submit(list: List<Playlist>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemUserPlaylistBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.binding.tvName.text = p.name
        holder.binding.tvInfo.text = "${p.trackCount} 首"
        Glide.with(holder.binding.cover)
            .load(p.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(holder.binding.cover)
        holder.binding.btnAdd.setOnClickListener { onSubscribe(p) }
        holder.binding.root.setOnClickListener { onClick(p) }
    }

    class VH(val binding: ItemUserPlaylistBinding) : RecyclerView.ViewHolder(binding.root)
}
