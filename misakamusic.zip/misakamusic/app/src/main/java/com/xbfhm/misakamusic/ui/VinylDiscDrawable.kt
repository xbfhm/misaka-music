package com.xbfhm.misakamusic.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable

/**
 * 真实黑胶唱片盘面 (代码绘制):
 *  - 径向渐变底色模拟反光
 *  - 密集同心圆沟槽
 *  - 两条扇形高光 (模拟灯光打在唱片上的反射)
 * 旋转时整体一起转, 视觉上非常接近真实唱片。
 */
class VinylDiscDrawable : Drawable() {

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0 || h <= 0) return
        val cx = w / 2f
        val cy = h / 2f
        val radius = w.coerceAtMost(h) / 2f

        // 1) 底色: 径向渐变 (边缘亮 -> 中心暗)
        discPaint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(
                Color.rgb(58, 58, 58),
                Color.rgb(26, 26, 26),
                Color.rgb(8, 8, 8)
            ),
            floatArrayOf(0.0f, 0.65f, 1.0f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, discPaint)
        discPaint.shader = null

        // 2) 密集沟槽 (同心圆, 由外向内)
        groovePaint.color = Color.argb(60, 255, 255, 255)
        val labelR = radius * 0.40f // 中心标签区(封面)之外的半径
        var r = radius - 3f
        var i = 0
        while (r > labelR) {
            // 交替深浅, 增强沟槽质感
            groovePaint.color = if (i % 2 == 0)
                Color.argb(48, 255, 255, 255)
            else
                Color.argb(14, 0, 0, 0)
            canvas.drawCircle(cx, cy, r, groovePaint)
            r -= 2.6f
            i++
        }
        groovePaint.color = Color.argb(40, 255, 255, 255)

        // 3) 两条扇形高光 (模拟灯光反射)
        shinePaint.shader = SweepGradient(cx, cy,
            intArrayOf(
                Color.argb(0, 255, 255, 255),
                Color.argb(60, 255, 255, 255),
                Color.argb(0, 255, 255, 255)
            ),
            null
        )
        canvas.save()
        canvas.rotate(-30f, cx, cy)
        val arcRect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.drawArc(arcRect, 0f, 70f, true, shinePaint)
        canvas.restore()
        shinePaint.shader = null

        // 4) 内圈高光细线 (标签区外缘)
        val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.argb(70, 255, 255, 255)
        }
        canvas.drawCircle(cx, cy, labelR, rim)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}
