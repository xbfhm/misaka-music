package com.xbfhm.misakamusic.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.xbfhm.misakamusic.databinding.FragmentSearchBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.model.User
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 搜索页: 双栏 (歌曲 / 用户) */
class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songAdapter = SongAdapter { index -> playSong(index) }
    private val userAdapter = UserAdapter { u -> openUser(u) }
    private var songs: List<Song> = emptyList()
    private var users: List<User> = emptyList()
    private var currentTab = 0  // 0=歌曲 1=用户
    private val SEARCH_TAG = -2L

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvSongs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSongs.adapter = songAdapter
        binding.rvUsers.layoutManager = LinearLayoutManager(requireContext())
        binding.rvUsers.adapter = userAdapter

        binding.etSearch.setOnEditorActionListener { _: TextView?, actionId: Int, _: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(binding.etSearch.text.toString().trim())
                true
            } else false
        }
        binding.btnClearSearch.setOnClickListener { clearSearch() }

        binding.tabResult.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentTab = tab.position
                render()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        render()
    }

    private fun doSearch(keyword: String) {
        if (keyword.isEmpty()) {
            toast("请输入要搜索的内容")
            return
        }
        binding.tvEmpty.visibility = View.GONE
        scope.launch {
            val s = withContext(Dispatchers.IO) { NeteaseApi.search(requireContext(), keyword, 30) }
            val u = withContext(Dispatchers.IO) { NeteaseApi.searchUser(requireContext(), keyword, 20) }
            songs = s
            users = u
            render()
        }
    }

    private fun render() {
        if (currentTab == 0) {
            binding.rvSongs.visibility = View.VISIBLE
            binding.rvUsers.visibility = View.GONE
            songAdapter.submit(songs)
            binding.tvEmpty.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE
            if (songs.isEmpty()) binding.tvEmpty.text = "没有找到相关歌曲"
        } else {
            binding.rvSongs.visibility = View.GONE
            binding.rvUsers.visibility = View.VISIBLE
            userAdapter.submit(users)
            binding.tvEmpty.visibility = if (users.isEmpty()) View.VISIBLE else View.GONE
            if (users.isEmpty()) binding.tvEmpty.text = "没有找到相关用户"
        }
    }

    private fun clearSearch() {
        binding.etSearch.setText("")
        songs = emptyList()
        users = emptyList()
        songAdapter.submit(emptyList())
        userAdapter.submit(emptyList())
        binding.tvEmpty.visibility = View.GONE
        binding.etSearch.clearFocus()
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.etSearch.windowToken, 0)
    }

    private fun playSong(index: Int) {
        if (index !in songs.indices) return
        PlayerEngine.setPlaylist(SEARCH_TAG, songs, index)
        songAdapter.currentIndex = PlayerEngine.currentIndex
        songAdapter.notifyDataSetChanged()
        startActivity(Intent(requireContext(), PlayerActivity::class.java))
        requireActivity().overridePendingTransition(R.anim.slide_in_bottom, R.anim.fade_out)
    }

    private fun openUser(u: User) {
        val intent = Intent(requireContext(), UserActivity::class.java)
        intent.putExtra(UserActivity.EXTRA_UID, u.id)
        intent.putExtra(UserActivity.EXTRA_NICKNAME, u.nickname)
        startActivity(intent)
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
