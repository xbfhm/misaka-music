package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xbfhm.misakamusic.databinding.FragmentRecommendBinding
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 推荐页: 分段加载 (下拉刷新 + 上拉加载更多) */
class RecommendFragment : Fragment() {

    private var _binding: FragmentRecommendBinding? = null
    private val binding get() = _binding!!
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val adapter = SongAdapter { index -> playSong(index) }
    private var displaySongs: List<Song> = emptyList()
    private var pool: List<Song> = emptyList()
    private var shown = 0
    private var poolLoaded = false
    private var loading = false
    private val PAGE = 20
    private val RECOMMEND_TAG = 0L

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecommendBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvSongs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSongs.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { refresh() }
        binding.rvSongs.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val lm = rv.layoutManager as? LinearLayoutManager ?: return
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.itemCount - 3) {
                    loadMore()
                }
            }
        })

        refresh()
    }

    private fun refresh() {
        poolLoaded = false
        pool = emptyList()
        displaySongs = emptyList()
        shown = 0
        adapter.submit(emptyList())
        binding.footer.visibility = View.GONE
        loadMore()
    }

    private fun loadMore() {
        if (loading) return
        if (poolLoaded && shown >= pool.size) return
        loading = true
        binding.swipeRefresh.isRefreshing = !poolLoaded
        scope.launch {
            if (!poolLoaded) {
                pool = withContext(Dispatchers.IO) {
                    NeteaseApi.recommendPool(requireContext(), 200)
                }
                poolLoaded = true
                shown = 0
                displaySongs = emptyList()
            }
            val next = (shown + PAGE).coerceAtMost(pool.size)
            if (next > shown) {
                displaySongs = displaySongs + pool.subList(shown, next)
                adapter.submit(displaySongs)
                shown = next
            }
            loading = false
            binding.swipeRefresh.isRefreshing = false
            binding.footer.visibility = if (shown >= pool.size) View.VISIBLE else View.GONE
        }
    }

    private fun playSong(index: Int) {
        if (index !in displaySongs.indices) return
        PlayerEngine.setPlaylist(RECOMMEND_TAG, displaySongs, index)
        adapter.currentIndex = PlayerEngine.currentIndex
        adapter.notifyDataSetChanged()
        startActivity(Intent(requireContext(), PlayerActivity::class.java))
        requireActivity().overridePendingTransition(R.anim.slide_in_bottom, R.anim.fade_out)
    }

    override fun onResume() {
        super.onResume()
        updateHighlight()
    }

    private fun updateHighlight() {
        if (PlayerEngine.queueTag == RECOMMEND_TAG) {
            adapter.currentIndex = PlayerEngine.currentIndex
        } else {
            adapter.currentIndex = -1
        }
        adapter.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
