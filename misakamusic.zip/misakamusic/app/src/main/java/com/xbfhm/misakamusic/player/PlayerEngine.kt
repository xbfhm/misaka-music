package com.xbfhm.misakamusic.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlayMode { ORDER, LOOP, SHUFFLE }

/**
 * 全局播放引擎 (单例)
 *  - ORDER   顺序: 播完最后一首停止
 *  - LOOP    循环
 *  - SHUFFLE 随机: ExoPlayer 洗牌模式
 *
 * 关键点:
 *  1. 音频 URL 必须带 Referer 头(网易云防盗链), 否则播几秒被 403 掐断。
 *     通过 DefaultHttpDataSource.Factory 全局注入请求头解决。
 *  2. 采用「先单曲秒开 + 后台解析整队后一次性 setMediaItems 替换」策略,
 *     全程不用占位 URL 与 replaceMediaItem, 避免闪退与下标错乱。
 */
object PlayerEngine {

    private lateinit var appCtx: Context
    private var listenerAttached = false

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        ensurePlayer()
    }

    val player: ExoPlayer by lazy {
        // 网易云防盗链: 音频 URL 需要 Referer 与浏览器 UA
        val httpFactory = DefaultHttpDataSource.Factory()
            .setDefaultRequestProperties(
                mapOf(
                    "Referer" to "https://music.163.com/",
                    "User-Agent" to "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                )
            )
        ExoPlayer.Builder(appCtx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songs = mutableListOf<Song>()
    var currentIndex: Int = -1
        private set
    var mode: PlayMode = PlayMode.ORDER
        private set
    var queueTag: Long = -1L

    private var consecutiveFail = 0
    private var preloadJob: Job? = null

    /** 解析播放地址 (由 App 注入 NeteaseApi) */
    var urlResolver: (suspend (Long) -> String?)? = null

    /** 当前可见界面监听 (onResume 时设置) */
    var listener: ((Song?) -> Unit)? = null
    var onPlayState: (() -> Unit)? = null

    private fun ensurePlayer() {
        if (listenerAttached) return
        listenerAttached = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                onPlayState?.invoke()
                if (state == Player.STATE_ENDED && mode == PlayMode.ORDER) {
                    player.pause()
                    player.seekTo(0)
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = player.currentMediaItemIndex
                if (idx in songs.indices) {
                    currentIndex = idx
                    consecutiveFail = 0
                    listener?.invoke(songs[idx])
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return
                }
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                } else if (mode != PlayMode.ORDER) {
                    player.seekTo(0, 0)
                    player.play()
                } else {
                    player.pause()
                    player.seekTo(0)
                }
            }
        })
    }

    fun currentSong(): Song? = if (currentIndex in songs.indices) songs[currentIndex] else null

    fun isPlaying(): Boolean = player.isPlaying

    fun setPlaylist(tag: Long, list: List<Song>, startIndex: Int = 0) {
        preloadJob?.cancel()
        songs.clear(); songs.addAll(list)
        consecutiveFail = 0
        queueTag = tag
        applyMode()
        if (list.isEmpty()) { currentIndex = -1; listener?.invoke(null); return }
        playAt(startIndex.coerceIn(0, list.size - 1))
    }

    fun playAt(index: Int) {
        if (index !in songs.indices) return
        currentIndex = index
        listener?.invoke(songs[index])
        resolveAndStart(index)
    }

    private fun resolveAndStart(startIndex: Int) {
        preloadJob?.cancel()
        preloadJob = scope.launch {
            // 阶段1: 解析用户点的那首, 单曲秒开
            val firstUrl = resolveUrl(songs[startIndex].id)
            if (firstUrl.isNullOrBlank()) {
                handleUnplayable(startIndex)
                return@launch
            }
            consecutiveFail = 0
            player.setMediaItem(buildItem(songs[startIndex], firstUrl))
            player.prepare()
            player.play()
            startPlaybackService()

            // 阶段2: 后台并发解析整队, 一次性替换成完整队列(保持当前下标与进度)
            val urls = resolveAll()
            val pos = player.currentPosition
            val items = songs.mapIndexed { i, s -> buildItem(s, urls[i]) }
            player.setMediaItems(items, startIndex, pos)
            if (player.isPlaying) player.play()
        }
    }

    private fun handleUnplayable(index: Int) {
        consecutiveFail++
        if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
            consecutiveFail = 0
            player.pause()
            toast("当前队列暂无可用音源")
            return
        }
        toast(unplayableMsg(songs[index]))
        val nextIdx = (index + 1) % songs.size
        if (nextIdx != index) playAt(nextIdx)
    }

    private fun unplayableMsg(song: Song): String = when {
        song.fee > 0 && !Session.isLoggedIn() -> "《${song.name}》需要 VIP，请先在设置中登录"
        song.fee > 0 -> "《${song.name}》需要 VIP 会员"
        else -> "《${song.name}》无法播放（可能已下架或无版权）"
    }

    private suspend fun resolveUrl(id: Long): String? {
        val resolver = urlResolver ?: return null
        return withContext(Dispatchers.IO) {
            try { resolver.invoke(id) } catch (_: Exception) { null }
        }
    }

    /** 并发解析整队 URL (每批 8 首), 返回与 songs 对齐的 URL 列表 */
    private suspend fun resolveAll(): List<String?> = withContext(Dispatchers.IO) {
        val result = arrayOfNulls<String>(songs.size)
        songs.indices.toList().chunked(8).forEach { chunk ->
            chunk.map { idx ->
                async {
                    idx to (try { urlResolver?.invoke(songs[idx].id) } catch (_: Exception) { null })
                }
            }.awaitAll().forEach { (idx, url) -> result[idx] = url }
        }
        result.toList()
    }

    private fun buildItem(song: Song, url: String?): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(song.name)
            .setArtist(song.artists)
            .setAlbumTitle(song.album)
            .setArtworkUri(if (song.cover.isNotBlank()) Uri.parse(song.cover) else null)
            .build()
        val finalUrl = if (url.isNullOrBlank()) "https://127.0.0.1/misaka-unplayable.mp3" else url
        return MediaItem.Builder()
            .setUri(finalUrl)
            .setMediaId(song.id.toString())
            .setMediaMetadata(meta)
            .build()
    }

    private fun applyMode() {
        when (mode) {
            PlayMode.ORDER -> { player.repeatMode = Player.REPEAT_MODE_OFF; player.shuffleModeEnabled = false }
            PlayMode.LOOP -> { player.repeatMode = Player.REPEAT_MODE_ALL; player.shuffleModeEnabled = false }
            PlayMode.SHUFFLE -> { player.repeatMode = Player.REPEAT_MODE_ALL; player.shuffleModeEnabled = true }
        }
    }

    fun next() {
        if (songs.isEmpty()) return
        if (player.hasNextMediaItem()) player.seekToNextMediaItem()
        else player.seekTo(0, 0)
    }

    fun prev() {
        if (songs.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
        else player.seekTo(0)
    }

    fun toggleMode(): PlayMode {
        mode = when (mode) {
            PlayMode.ORDER -> PlayMode.LOOP
            PlayMode.LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.ORDER
        }
        applyMode()
        return mode
    }

    fun togglePlayPause() {
        if (currentIndex < 0) return
        if (player.isPlaying) player.pause()
        else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.prepare()
            player.play()
        }
    }

    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun playModeLabel(): String = when (mode) {
        PlayMode.ORDER -> "顺序播放"
        PlayMode.LOOP -> "循环播放"
        PlayMode.SHUFFLE -> "随机播放"
    }

    fun hasQueue(): Boolean = songs.isNotEmpty()

    fun songCount(): Int = songs.size

    // ---------------- 定时关闭 ----------------

    private var sleepEndMs: Long = 0
    private var sleepJob: Job? = null

    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) { sleepEndMs = 0; return }
        sleepEndMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            while (System.currentTimeMillis() < sleepEndMs) delay(1000)
            sleepEndMs = 0
            player.pause()
            toast("定时关闭：已停止播放")
        }
    }

    fun cancelSleepTimer() { sleepJob?.cancel(); sleepEndMs = 0 }

    fun hasSleepTimer(): Boolean = sleepEndMs > 0

    fun sleepRemainingMs(): Long = (sleepEndMs - System.currentTimeMillis()).coerceAtLeast(0)

    fun stopAndClear() {
        preloadJob?.cancel()
        player.stop()
        player.clearMediaItems()
        songs.clear()
        currentIndex = -1
        consecutiveFail = 0
        listener?.invoke(null)
    }

    private fun startPlaybackService() {
        try {
            val intent = Intent(appCtx, PlaybackService::class.java)
            ContextCompat.startForegroundService(appCtx, intent)
        } catch (_: Exception) {}
    }

    private fun toast(msg: String) {
        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
    }
}
