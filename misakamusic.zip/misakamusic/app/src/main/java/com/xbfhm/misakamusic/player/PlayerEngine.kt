package com.xbfhm.misakamusic.player

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlayMode { ORDER, LOOP, SHUFFLE }

/**
 * 全局播放引擎 (单例)
 *  - ORDER   顺序: 播完最后一首停止
 *  - LOOP    循环
 *  - SHUFFLE 随机: ExoPlayer 洗牌模式
 *
 * 关键点:
 *  1. 音频 URL 必须带 Referer 头(网易云防盗链), 否则播几秒被 403 掐断。
 *  2. 必须通过 MediaController 连接 MediaSessionService, 否则前台服务 5 秒后
 *     被系统强制终止, 导致进程重启「返回主界面并停止播放」。
 *  3. 播放采用「单曲秒开 + 后台解析整队后一次性 setMediaItems 替换」, 全程
 *     不打断当前播放。
 */
object PlayerEngine {

    private lateinit var appCtx: Context
    private var listenerAttached = false

    private var mediaController: MediaController? = null

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        ensurePlayer()
        // 提前建立 MediaSession 连接, 让 PlaybackService 正确进入前台,
        // 从根本上解决「播放几秒被系统杀掉返回主界面」的问题。
        connectMediaSession()
    }

    val player: ExoPlayer by lazy {
        // 网易云防盗链: 音频 URL 需要 Referer 与浏览器 UA
        val httpFactory = DefaultHttpDataSource.Factory()
            .setDefaultRequestProperties(
                mapOf(
                    "Referer" to "https://music.163.com/",
                    "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                )
            )

        ExoPlayer.Builder(appCtx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songs = mutableListOf<Song>()
    var currentIndex: Int = -1
        private set
    var mode: PlayMode = PlayMode.ORDER
        private set
    var queueTag: Long = -1L

    private var consecutiveFail = 0
    private var preloadJob: Job? = null

    /** 解析播放地址 (由 App 注入 NeteaseApi) */
    var urlResolver: (suspend (Long) -> String?)? = null

    /** 播放记录上报回调 (由 App 注入 NeteaseApi.scrobble) */
    var scrobbleReporter: (suspend (songId: Long, sourceId: Long, timeSec: Int) -> Unit)? = null

    /** 当前可见界面监听 (onResume 时设置) */
    var listener: ((Song?) -> Unit)? = null
    var onPlayState: (() -> Unit)? = null

    @OptIn(UnstableApi::class)
    private fun connectMediaSession() {
        if (mediaController != null) return
        try {
            val token = SessionToken(appCtx, ComponentName(appCtx, PlaybackService::class.java))
            val future = MediaController.Builder(appCtx, token).buildAsync()
            future.addListener({
                try {
                    mediaController = future.get()
                    Logger.log("PlayerEngine", "MediaController 已连接, 前台服务就绪")
                } catch (e: Exception) {
                    Logger.log("PlayerEngine", "MediaController 连接失败: ${e.message}")
                }
            }, ContextCompat.getMainExecutor(appCtx))
        } catch (e: Exception) {
            Logger.log("PlayerEngine", "SessionToken 构建失败: ${e.message}")
        }
    }

    private fun ensurePlayer() {
        if (listenerAttached) return
        listenerAttached = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                Logger.log("PlayerEngine", "onPlaybackStateChanged state=$state playing=${player.isPlaying}")
                onPlayState?.invoke()
                if (state == Player.STATE_ENDED && mode == PlayMode.ORDER) {
                    player.pause()
                    player.seekTo(0)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                Logger.log("PlayerEngine", "onIsPlayingChanged playing=$isPlaying")
                if (isPlaying) onScrobblePlay() else onScrobblePause()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = songs.indexOfFirst { it.id.toString() == mediaItem?.mediaId }
                Logger.log("PlayerEngine", "onMediaItemTransition mediaId=${mediaItem?.mediaId} idx=$idx reason=$reason")
                if (idx in songs.indices) {
                    currentIndex = idx
                    consecutiveFail = 0
                    listener?.invoke(songs[idx])
                    onScrobbleSongChanged()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                Logger.log("PlayerEngine", "onPlayerError code=${error.errorCode} msg=${error.message} fail=$consecutiveFail")
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return
                }
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                } else if (mode != PlayMode.ORDER) {
                    player.seekTo(0, 0)
                    player.play()
                } else {
                    player.pause()
                    player.seekTo(0)
                }
            }
        })
    }

    fun currentSong(): Song? {
        // 通过 mediaId 反查实际播放项, 避免 SHUFFLE 模式下 currentMediaItemIndex 索引错乱
        val mediaId = player.currentMediaItem?.mediaId
        if (mediaId != null) {
            songs.firstOrNull { it.id.toString() == mediaId }?.let { return it }
        }
        // 回退: 刚 setPlaylist 尚未 setMediaItem 时, currentMediaItem 还是旧的, 用 currentIndex
        return if (currentIndex in songs.indices) songs[currentIndex] else null
    }

    fun isPlaying(): Boolean = player.isPlaying

    fun setPlaylist(tag: Long, list: List<Song>, startIndex: Int = 0, randomStart: Boolean = false) {
        Logger.log("PlayerEngine", "setPlaylist tag=$tag size=${list.size} start=$startIndex random=$randomStart")
        preloadJob?.cancel()
        songs.clear(); songs.addAll(list)
        consecutiveFail = 0
        queueTag = tag
        applyMode()
        if (list.isEmpty()) { currentIndex = -1; listener?.invoke(null); return }
        // 随机播放: 从头开始时随机选一首作为起点, 保证封面与声音从一开始就一致
        val start = if (randomStart && list.size > 1) {
            (list.indices).random()
        } else {
            startIndex.coerceIn(0, list.size - 1)
        }
        playAt(start)
    }

    fun playAt(index: Int) {
        if (index !in songs.indices) return
        Logger.log("PlayerEngine", "playAt index=$index song=${songs[index].name}")
        currentIndex = index
        listener?.invoke(songs[index])
        resolveAndStart(index)
    }

    private fun resolveAndStart(startIndex: Int) {
        preloadJob?.cancel()
        preloadJob = scope.launch {
            // 阶段1: 解析用户点的那首, 单曲秒开
            val firstUrl = resolveUrl(songs[startIndex].id)
            if (firstUrl.isNullOrBlank()) {
                Logger.log("PlayerEngine", "首曲 URL 解析失败 index=$startIndex")
                handleUnplayable(startIndex)
                return@launch
            }
            consecutiveFail = 0
            Logger.log("PlayerEngine", "首曲秒开: ${songs[startIndex].name}")
            player.setMediaItem(buildItem(songs[startIndex], firstUrl))
            player.prepare()
            player.play()
            startPlaybackService()

            // 阶段2: 后台并发解析整队, 一次性替换成完整队列(保持当前下标与进度)
            val urls = resolveAll()
            // 替换前确认仍在播放, 避免与用户操作竞态
            if (preloadJob?.isCancelled == true) return@launch
            val pos = player.currentPosition
            val items = songs.mapIndexed { i, s -> buildItem(s, urls[i]) }
            Logger.log("PlayerEngine", "整队替换 items=${items.size} start=$startIndex pos=$pos")
            player.setMediaItems(items, startIndex, pos)
            player.prepare()
            player.play()
            // 立即同步 UI 到实际播放项, 修复随机播放时封面/歌手信息显示错误
            syncCurrentFromPlayer()
        }
    }

    /** 将 currentIndex 与 ExoPlayer 实际播放项对齐, 并通知 UI 刷新 (基于 mediaId 反查, 规避 SHUFFLE 索引错乱) */
    private fun syncCurrentFromPlayer() {
        val mediaId = player.currentMediaItem?.mediaId ?: return
        val idx = songs.indexOfFirst { it.id.toString() == mediaId }
        if (idx in songs.indices && idx != currentIndex) {
            Logger.log("PlayerEngine", "syncCurrentFromPlayer mediaId=$mediaId idx=$idx (原 $currentIndex)")
            currentIndex = idx
            consecutiveFail = 0
            listener?.invoke(songs[idx])
        }
    }

    private fun handleUnplayable(index: Int) {
        consecutiveFail++
        if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
            consecutiveFail = 0
            player.pause()
            toast("当前队列暂无可用音源")
            return
        }
        toast(unplayableMsg(songs[index]))
        val nextIdx = (index + 1) % songs.size
        if (nextIdx != index) playAt(nextIdx)
    }

    private fun unplayableMsg(song: Song): String = when {
        song.fee > 0 && !Session.isLoggedIn() -> "《${song.name}》需要 VIP，请先在设置中登录"
        song.fee > 0 -> "《${song.name}》需要 VIP 会员"
        else -> "《${song.name}》无法播放（可能已下架或无版权）"
    }

    private suspend fun resolveUrl(id: Long): String? {
        val resolver = urlResolver ?: return null
        return withContext(Dispatchers.IO) {
            try { resolver.invoke(id) } catch (e: Exception) {
                Logger.log("PlayerEngine", "resolveUrl 异常 id=$id ${e.message}")
                null
            }
        }
    }

    /** 并发解析整队 URL (每批 8 首), 返回与 songs 对齐的 URL 列表 */
    private suspend fun resolveAll(): List<String?> = withContext(Dispatchers.IO) {
        val result = arrayOfNulls<String>(songs.size)
        songs.indices.toList().chunked(8).forEach { chunk ->
            chunk.map { idx ->
                async {
                    idx to (try { urlResolver?.invoke(songs[idx].id) } catch (_: Exception) { null })
                }
            }.awaitAll().forEach { (idx, url) -> result[idx] = url }
        }
        result.toList()
    }

    private fun buildItem(song: Song, url: String?): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(song.name)
            .setArtist(song.artists)
            .setAlbumTitle(song.album)
            .setArtworkUri(if (song.cover.isNotBlank()) Uri.parse(song.cover) else null)
            .build()
        val finalUrl = if (url.isNullOrBlank()) "https://127.0.0.1/misaka-unplayable.mp3" else url
        return MediaItem.Builder()
            .setUri(finalUrl)
            .setMediaId(song.id.toString())
            .setMediaMetadata(meta)
            .build()
    }

    private fun applyMode() {
        when (mode) {
            PlayMode.ORDER -> { player.repeatMode = Player.REPEAT_MODE_OFF; player.shuffleModeEnabled = false }
            PlayMode.LOOP -> { player.repeatMode = Player.REPEAT_MODE_ALL; player.shuffleModeEnabled = false }
            PlayMode.SHUFFLE -> { player.repeatMode = Player.REPEAT_MODE_ALL; player.shuffleModeEnabled = true }
        }
    }

    fun next() {
        if (songs.isEmpty()) return
        if (player.hasNextMediaItem()) player.seekToNextMediaItem()
        else player.seekTo(0, 0)
    }

    fun prev() {
        if (songs.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
        else player.seekTo(0)
    }

    fun toggleMode(): PlayMode {
        mode = when (mode) {
            PlayMode.ORDER -> PlayMode.LOOP
            PlayMode.LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.ORDER
        }
        applyMode()
        return mode
    }

    fun togglePlayPause() {
        if (currentIndex < 0) return
        if (player.isPlaying) player.pause()
        else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.prepare()
            player.play()
        }
    }

    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun playModeLabel(): String = when (mode) {
        PlayMode.ORDER -> "顺序播放"
        PlayMode.LOOP -> "循环播放"
        PlayMode.SHUFFLE -> "随机播放"
    }

    fun hasQueue(): Boolean = songs.isNotEmpty()

    fun songCount(): Int = songs.size

    // ---------------- 定时关闭 ----------------

    private var sleepEndMs: Long = 0
    private var sleepJob: Job? = null

    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) { sleepEndMs = 0; return }
        sleepEndMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            while (System.currentTimeMillis() < sleepEndMs) delay(1000)
            sleepEndMs = 0
            player.pause()
            toast("定时关闭：已停止播放")
        }
    }

    fun cancelSleepTimer() { sleepJob?.cancel(); sleepEndMs = 0 }

    fun hasSleepTimer(): Boolean = sleepEndMs > 0

    fun sleepRemainingMs(): Long = (sleepEndMs - System.currentTimeMillis()).coerceAtLeast(0)

    // ---------------- 播放记录上报 (同步听歌时长) ----------------

    private var scrobbleSongId = -1L
    private var scrobblePendingSec = 0
    private var scrobbleAnchorMs = 0L
    private var scrobbleJob: Job? = null

    /** 开始/恢复播放: 锚定起点, 启动 30s 定时上报 */
    private fun onScrobblePlay() {
        if (scrobbleReporter == null || !Session.isLoggedIn()) return
        val song = currentSong() ?: return
        if (scrobbleSongId != song.id) {
            scrobbleSongId = song.id
            scrobblePendingSec = 0
        }
        scrobbleAnchorMs = System.currentTimeMillis()
        startScrobbleTick()
    }

    /** 暂停: 补记零头并上报 */
    private fun onScrobblePause() {
        if (scrobbleSongId > 0 && scrobbleAnchorMs > 0) {
            val extra = ((System.currentTimeMillis() - scrobbleAnchorMs) / 1000).toInt()
            if (extra > 0) scrobblePendingSec += extra
            scrobbleAnchorMs = 0
        }
        flushScrobble()
        scrobbleJob?.cancel()
    }

    /** 切歌: 先把上一首的时长 flush 掉, 再准备追踪新歌 */
    private fun onScrobbleSongChanged() {
        onScrobblePause()
        scrobbleSongId = -1
        scrobblePendingSec = 0
        if (player.isPlaying) onScrobblePlay()
    }

    private fun startScrobbleTick() {
        scrobbleJob?.cancel()
        scrobbleJob = scope.launch {
            while (isActive) {
                delay(30_000L)
                if (player.isPlaying && scrobbleSongId > 0) {
                    scrobblePendingSec += 30
                    scrobbleAnchorMs = System.currentTimeMillis()
                    flushScrobble()
                }
            }
        }
    }

    private fun flushScrobble() {
        val reporter = scrobbleReporter ?: return
        if (!Session.isLoggedIn()) return
        val id = scrobbleSongId
        val sec = scrobblePendingSec
        if (id <= 0 || sec <= 0) return
        scrobblePendingSec = 0
        val src = if (queueTag > 0) queueTag else 0L
        scope.launch(Dispatchers.IO) {
            try {
                reporter.invoke(id, src, sec)
            } catch (e: Exception) {
                Logger.log("PlayerEngine", "scrobble 上报异常: ${e.message}")
            }
        }
    }

    fun stopAndClear() {
        Logger.log("PlayerEngine", "stopAndClear")
        preloadJob?.cancel()
        player.stop()
        player.clearMediaItems()
        songs.clear()
        currentIndex = -1
        consecutiveFail = 0
        listener?.invoke(null)
    }

    private fun startPlaybackService() {
        try {
            val intent = Intent(appCtx, PlaybackService::class.java)
            ContextCompat.startForegroundService(appCtx, intent)
            Logger.log("PlayerEngine", "startPlaybackService 已调用")
        } catch (e: Exception) {
            Logger.log("PlayerEngine", "startPlaybackService 异常: ${e.message}")
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
    }
}
