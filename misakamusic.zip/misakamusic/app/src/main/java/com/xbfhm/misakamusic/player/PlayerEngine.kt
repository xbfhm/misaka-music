package com.xbfhm.misakamusic.player

import android.content.Context
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.xbfhm.misakamusic.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlayMode { ORDER, LOOP, SHUFFLE }

/**
 * 全局播放引擎 (单例)
 * 播放模式:
 *  - ORDER  顺序: 顺序播完最后一首停止
 *  - LOOP   循环: 列表循环
 *  - SHUFFLE 随机: 洗牌袋算法, 播放完一首后随机下一首且不重复, 全部播完重新洗牌
 */
object PlayerEngine {

    private lateinit var appCtx: Context
    private var listenerAttached = false

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        ensurePlayer()
    }

    val player: ExoPlayer by lazy { ExoPlayer.Builder(appCtx).build() }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songs = mutableListOf<Song>()
    var currentIndex: Int = -1
        private set
    var mode: PlayMode = PlayMode.ORDER
        private set
    var queueTag: Long = -1L   // 当前队列来源歌单 id (用于高亮)

    private val shuffleQueue = ArrayDeque<Int>()
    private val history = ArrayDeque<Int>()
    private var consecutiveFail = 0

    /** 解析播放地址 (由 App 注入 NeteaseApi) */
    var urlResolver: (suspend (Long) -> String?)? = null

    /** 当前可见界面监听 (MainActivity / PlayerActivity 在 onResume 时设置) */
    var listener: ((Song?) -> Unit)? = null
    var onPlayState: (() -> Unit)? = null

    private fun ensurePlayer() {
        if (listenerAttached) return
        listenerAttached = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                onPlayState?.invoke()
                if (state == Player.STATE_ENDED) autoNext()
            }

            override fun onPlayerError(error: PlaybackException) {
                autoNext()
            }
        })
    }

    fun currentSong(): Song? = if (currentIndex in songs.indices) songs[currentIndex] else null

    fun isPlaying(): Boolean = player.isPlaying

    fun setPlaylist(tag: Long, list: List<Song>, startIndex: Int = 0) {
        songs.clear(); songs.addAll(list)
        history.clear(); shuffleQueue.clear()
        consecutiveFail = 0
        queueTag = tag
        if (list.isEmpty()) { currentIndex = -1; listener?.invoke(null); return }
        playAt(startIndex.coerceIn(0, list.size - 1))
    }

    /** 用户点列表里的歌: 播放并(随机模式下)重建随机队列避免立刻重复 */
    fun playFromList(index: Int) {
        if (index !in songs.indices) return
        playAt(index)
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
    }

    fun playAt(index: Int) {
        if (index !in songs.indices) return
        currentIndex = index
        history.addLast(index)
        if (history.size > 200) history.removeFirst()
        listener?.invoke(songs[index])
        resolveAndPlay()
    }

    private suspend fun resolveUrl(id: Long): String? {
        val resolver = urlResolver ?: return null
        return withContext(Dispatchers.IO) {
            try {
                resolver.invoke(id)
            } catch (_: Exception) {
                null
            }
        }
    }

    private fun resolveAndPlay() {
        val song = currentSong() ?: return
        val id = song.id
        scope.launch {
            val url = resolveUrl(id)
            if (url.isNullOrEmpty()) {
                consecutiveFail++
                if (consecutiveFail >= songs.size) { player.stop(); return@launch }
                val msg = when {
                    song.fee > 0 && !com.xbfhm.misakamusic.net.Session.isLoggedIn() ->
                        "《${song.name}》需要 VIP，请先在设置中登录"
                    song.fee > 0 -> "《${song.name}》需要 VIP 会员"
                    else -> "《${song.name}》无法播放（可能已下架）"
                }
                toast(msg)
                autoNext()
            } else {
                consecutiveFail = 0
                val item = MediaItem.Builder()
                    .setUri(url)
                    .setMediaId(id.toString())
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.play()
            }
        }
    }

    private fun sessionLost(): Boolean {
        return !com.xbfhm.misakamusic.net.Session.isLoggedIn()
    }

    /** 一首歌自然播完后的自动下一首 */
    fun autoNext() {
        if (songs.isEmpty()) return
        when (mode) {
            PlayMode.ORDER -> {
                if (currentIndex >= songs.size - 1) {
                    player.seekTo(0)
                    player.pause()
                    return
                }
                playAt(currentIndex + 1)
            }
            PlayMode.LOOP -> playAt((currentIndex + 1) % songs.size)
            PlayMode.SHUFFLE -> {
                if (shuffleQueue.isEmpty()) rebuildShuffle()
                if (shuffleQueue.isEmpty()) return
                playAt(shuffleQueue.removeFirst())
            }
        }
    }

    /** 手动下一首 (顺序/循环模式到末尾环绕; 随机模式取随机队列) */
    fun next() {
        if (songs.isEmpty()) return
        when (mode) {
            PlayMode.ORDER, PlayMode.LOOP -> playAt((currentIndex + 1) % songs.size)
            PlayMode.SHUFFLE -> {
                if (shuffleQueue.isEmpty()) rebuildShuffle()
                if (shuffleQueue.isEmpty()) return
                playAt(shuffleQueue.removeFirst())
            }
        }
    }

    /** 上一首: 回到播放历史; 超过3秒则从头播放 */
    fun prev() {
        if (songs.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        if (history.size > 1) {
            history.removeLast()
            val prevIdx = history.removeLast()
            playAt(prevIdx)
        } else {
            player.seekTo(0)
        }
    }

    /** 随机队列重建: 除当前歌曲外全部打乱, 保证不重复且不立刻回到当前 */
    private fun rebuildShuffle() {
        val list = (0 until songs.size).toMutableList()
        if (currentIndex in list && songs.size > 1) list.remove(currentIndex)
        list.shuffle()
        shuffleQueue.clear()
        shuffleQueue.addAll(list)
    }

    fun toggleMode(): PlayMode {
        mode = when (mode) {
            PlayMode.ORDER -> PlayMode.LOOP
            PlayMode.LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.ORDER
        }
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
        return mode
    }

    fun togglePlayPause() {
        if (currentIndex < 0) return
        if (player.isPlaying) player.pause()
        else {
            player.prepare()
            player.play()
        }
    }

    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun playModeLabel(): String = when (mode) {
        PlayMode.ORDER -> "顺序播放"
        PlayMode.LOOP -> "循环播放"
        PlayMode.SHUFFLE -> "随机播放"
    }

    fun hasQueue(): Boolean = songs.isNotEmpty()

    fun songCount(): Int = songs.size

    fun stopAndClear() {
        player.stop()
        songs.clear()
        currentIndex = -1
        history.clear()
        shuffleQueue.clear()
        listener?.invoke(null)
    }

    private fun toast(msg: String) {
        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
    }
}
