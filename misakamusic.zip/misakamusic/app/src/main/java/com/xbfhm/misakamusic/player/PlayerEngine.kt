package com.xbfhm.misakamusic.player

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class PlayMode { ORDER, LOOP, SHUFFLE }

/**
 * 全局播放引擎 (单例) —— 基于列表切歌, 可靠稳定
 *  - 点"下一首/上一首" = 按当前歌单列表主动切歌, 绝不依赖 ExoPlayer 队列(那会因增量加载未完成而切不动)
 *  - 自然播完自动连播下一首
 *  - SHUFFLE 用洗牌袋算法: 完全随机且不重复, 播完重新洗牌
 *  - 保留: 播放上报(scrobble) / 收藏 / 定时关闭
 */
object PlayerEngine {

    private lateinit var appCtx: Context
    private var listenerAttached = false

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        ensurePlayer()
    }

    val player: ExoPlayer by lazy { ExoPlayer.Builder(appCtx).build() }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val songs = mutableListOf<Song>()
    var currentIndex: Int = -1
        private set
    var mode: PlayMode = PlayMode.ORDER
        private set
    var queueTag: Long = -1L   // 队列来源 (歌单id / 首页 0L)

    private val shuffleQueue = ArrayDeque<Int>()
    private val history = ArrayDeque<Int>()
    private var consecutiveFail = 0

    var urlResolver: (suspend (Long) -> String?)? = null

    var listener: ((Song?) -> Unit)? = null
    var onPlayState: (() -> Unit)? = null

    /** 播放上报 (网易云同步最近播放/时长), 由 App 注入 NeteaseApi.scrobble */
    var scrobbleReporter: (suspend (songId: Long, sourceId: Long, timeSec: Int) -> Unit)? = null

    private fun ensurePlayer() {
        if (listenerAttached) return
        listenerAttached = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                onPlayState?.invoke()
                if (state == Player.STATE_ENDED) autoNext()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) onScrobblePlay() else onScrobblePause()
            }

            override fun onPlayerError(error: PlaybackException) {
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return
                }
                toast(unplayableMsg(currentSong()))
                autoNext()
            }
        })
    }

    fun currentSong(): Song? = if (currentIndex in songs.indices) songs[currentIndex] else null

    fun isPlaying(): Boolean = player.isPlaying

    fun hasQueue(): Boolean = songs.isNotEmpty()

    fun setPlaylist(tag: Long, list: List<Song>, startIndex: Int = 0, randomStart: Boolean = false) {
        preloadJob?.cancel()
        songs.clear(); songs.addAll(list)
        history.clear(); shuffleQueue.clear()
        consecutiveFail = 0
        queueTag = tag
        if (list.isEmpty()) { currentIndex = -1; listener?.invoke(null); return }
        val start = if (randomStart && list.size > 1) {
            list.indices.random()
        } else {
            startIndex.coerceIn(0, list.size - 1)
        }
        playAt(start)
    }

    fun playFromList(index: Int) {
        if (index !in songs.indices) return
        playAt(index)
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
    }

    fun playAt(index: Int) {
        if (index !in songs.indices) return
        currentIndex = index
        history.addLast(index)
        if (history.size > 200) history.removeFirst()
        listener?.invoke(songs[index])
        resolveAndPlay()
    }

    private suspend fun resolveUrl(id: Long): String? {
        val resolver = urlResolver ?: return null
        return withContext(Dispatchers.IO) {
            try { resolver.invoke(id) } catch (_: Exception) { null }
        }
    }

    private fun resolveAndPlay() {
        val song = currentSong() ?: return
        val id = song.id
        preloadJob?.cancel()
        preloadJob = scope.launch {
            val url = resolveUrl(id)
            if (url.isNullOrEmpty()) {
                consecutiveFail++
                if (consecutiveFail >= songs.size.coerceAtLeast(1)) {
                    consecutiveFail = 0
                    player.pause()
                    toast("当前队列暂无可用音源")
                    return@launch
                }
                toast(unplayableMsg(song))
                autoNext()
            } else {
                consecutiveFail = 0
                val item = MediaItem.Builder()
                    .setUri(url)
                    .setMediaId(id.toString())
                    .setMediaMetadata(MediaMetadata.Builder()
                        .setTitle(song.name)
                        .setArtist(song.artists)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(if (song.cover.isNotBlank()) Uri.parse(song.cover) else null)
                        .build())
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.play()
            }
        }
    }

    private fun unplayableMsg(song: Song?): String = when {
        song == null -> "无法播放"
        song.fee > 0 && !Session.isLoggedIn() -> "《${song.name}》需要 VIP，请先在设置中登录"
        song.fee > 0 -> "《${song.name}》需要 VIP 会员"
        else -> "《${song.name}》无法播放（可能已下架或无版权）"
    }

    /** 自动/手动下一首: 按当前模式基于列表切歌 */
    fun autoNext() {
        if (songs.isEmpty()) return
        when (mode) {
            PlayMode.ORDER -> {
                if (currentIndex >= songs.size - 1) {
                    player.seekTo(0)
                    player.pause()
                    return
                }
                playAt(currentIndex + 1)
            }
            PlayMode.LOOP -> playAt((currentIndex + 1) % songs.size)
            PlayMode.SHUFFLE -> {
                if (shuffleQueue.isEmpty()) rebuildShuffle()
                if (shuffleQueue.isEmpty()) return
                playAt(shuffleQueue.removeFirst())
            }
        }
    }

    /** 手动下一首 (和自动连播一致, 保证点击必切) */
    fun next() = autoNext()

    /** 上一首: 回到播放历史; 播放超3秒则从头 */
    fun prev() {
        if (songs.isEmpty()) return
        if (player.currentPosition > 3000) { player.seekTo(0); return }
        if (history.size > 1) {
            history.removeLast()
            val prevIdx = history.removeLast()
            playAt(prevIdx)
        } else {
            player.seekTo(0)
        }
    }

    private fun rebuildShuffle() {
        val list = (0 until songs.size).toMutableList()
        if (currentIndex in list && songs.size > 1) list.remove(currentIndex)
        list.shuffle()
        shuffleQueue.clear()
        shuffleQueue.addAll(list)
    }

    fun toggleMode(): PlayMode {
        mode = when (mode) {
            PlayMode.ORDER -> PlayMode.LOOP
            PlayMode.LOOP -> PlayMode.SHUFFLE
            PlayMode.SHUFFLE -> PlayMode.ORDER
        }
        if (mode == PlayMode.SHUFFLE) rebuildShuffle()
        return mode
    }

    fun togglePlayPause() {
        if (currentIndex < 0) return
        if (player.isPlaying) player.pause()
        else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.prepare()
            player.play()
        }
    }

    fun seekTo(ms: Long) { player.seekTo(ms) }

    fun playModeLabel(): String = when (mode) {
        PlayMode.ORDER -> "顺序播放"
        PlayMode.LOOP -> "循环播放"
        PlayMode.SHUFFLE -> "随机播放"
    }

    // ---------------- 播放上报 (网易云同步) ----------------

    private var preloadJob: Job? = null
    private var scrobbleSongId = -1L
    private var scrobblePendingSec = 0
    private var scrobbleAnchorMs = 0L
    private var scrobbleJob: Job? = null

    private fun onScrobblePlay() {
        if (scrobbleReporter == null || !Session.isLoggedIn()) return
        val song = currentSong() ?: return
        if (scrobbleSongId != song.id) {
            scrobbleSongId = song.id
            scrobblePendingSec = 0
        }
        scrobbleAnchorMs = System.currentTimeMillis()
        startScrobbleTick()
    }

    private fun onScrobblePause() {
        if (scrobbleSongId > 0 && scrobbleAnchorMs > 0) {
            val extra = ((System.currentTimeMillis() - scrobbleAnchorMs) / 1000).toInt()
            if (extra > 0) scrobblePendingSec += extra
            scrobbleAnchorMs = 0
        }
        flushScrobble()
        scrobbleJob?.cancel()
    }

    private fun startScrobbleTick() {
        scrobbleJob?.cancel()
        scrobbleJob = scope.launch {
            while (true) {
                delay(30_000L)
                if (player.isPlaying && scrobbleSongId > 0) {
                    scrobblePendingSec += 30
                    scrobbleAnchorMs = System.currentTimeMillis()
                    flushScrobble()
                }
            }
        }
    }

    private fun flushScrobble() {
        val id = scrobbleSongId
        val time = scrobblePendingSec
        if (id <= 0 || time <= 0) return
        val src = queueTag
        scope.launch {
            try {
                withContext(Dispatchers.IO) { scrobbleReporter?.invoke(id, src, time) }
            } catch (_: Exception) {}
        }
        scrobblePendingSec = 0
    }

    // ---------------- 定时关闭 ----------------

    private var sleepEndMs: Long = 0
    private var sleepJob: Job? = null

    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) {
            sleepEndMs = 0
            return
        }
        sleepEndMs = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = scope.launch {
            while (System.currentTimeMillis() < sleepEndMs) {
                delay(1000)
            }
            sleepEndMs = 0
            player.pause()
            toast("定时关闭：已停止播放")
        }
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel()
        sleepEndMs = 0
    }

    fun hasSleepTimer(): Boolean = sleepEndMs > 0

    fun sleepRemainingMs(): Long = (sleepEndMs - System.currentTimeMillis()).coerceAtLeast(0)

    fun stopAndClear() {
        player.stop()
        songs.clear()
        currentIndex = -1
        history.clear()
        shuffleQueue.clear()
        listener?.invoke(null)
    }

    private fun toast(msg: String) {
        Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
    }
}
