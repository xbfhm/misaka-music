package com.xbfhm.misakamusic.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ItemUserBinding
import com.xbfhm.misakamusic.model.User

/** 搜索用户结果列表 */
class UserAdapter(
    private val onClick: (User) -> Unit
) : RecyclerView.Adapter<UserAdapter.VH>() {

    private val items = mutableListOf<User>()

    fun submit(list: List<User>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val u = items[position]
        holder.binding.tvName.text = u.nickname
        holder.binding.tvSig.text = u.signature
        holder.binding.tvSig.visibility =
            if (u.signature.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
        Glide.with(holder.binding.avatar)
            .load(u.avatar)
            .placeholder(R.drawable.ic_account)
            .error(R.drawable.ic_account)
            .into(holder.binding.avatar)
        holder.binding.root.setOnClickListener { onClick(u) }
    }

    class VH(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)
}
