package com.xbfhm.misakamusic.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 全局日志: 内存环形缓冲, 保留最近 500 行。
 * 用于定位「播放几秒后中断/返回主界面」等疑难问题。
 * 日志页 (LogActivity) 可一键复制全部缓冲。
 */
object Logger {

    private const val MAX_LINES = 500
    private val buffer = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun log(tag: String, msg: String) {
        val line = "${fmt.format(Date())} [$tag] $msg"
        buffer.addLast(line)
        while (buffer.size > MAX_LINES) buffer.removeFirst()
        Log.d("Misaka/$tag", msg)
    }

    /** 最近 N 行 (默认 500), 拼接成字符串 */
    @Synchronized
    fun recent(): String = buffer.joinToString("\n")

    @Synchronized
    fun recentLines(): List<String> = buffer.toList()

    @Synchronized
    fun clear() = buffer.clear()
}
