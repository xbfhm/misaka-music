package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLoginBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 登录页 (仅 Cookie 登录)
 * 从浏览器/官方 App 复制完整 Cookie 粘贴即可
 */
class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Session.isLoggedIn()) {
            goMain()
            return
        }

        binding.btnCookieTutorial.setOnClickListener {
            openPage(Intent(this, CookieTutorialActivity::class.java))
        }
        binding.btnCookieImport.setOnClickListener { importCookie() }
    }

    private fun importCookie() {
        val raw = binding.etCookie.text.toString().trim()
        if (raw.isEmpty()) {
            toast(getString(R.string.cookie_empty))
            return
        }
        Session.absorbCookieString(raw)
        if (!Session.has("MUSIC_U")) {
            toast(getString(R.string.cookie_need_music_u))
            return
        }
        binding.btnCookieImport.isEnabled = false
        scope.launch {
            withContext(Dispatchers.IO) { NeteaseApi.afterLogin(this@LoginActivity) }
            Session.clearLiked()
            toast(getString(R.string.cookie_success))
            goMain()
        }
    }

    private fun goMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        openPage(intent)
        finish()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
