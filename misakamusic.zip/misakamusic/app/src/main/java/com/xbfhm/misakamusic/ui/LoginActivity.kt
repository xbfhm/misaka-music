package com.xbfhm.misakamusic.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLoginBinding
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TAB = "login_tab"  // 0=扫码 1=手机号
    }

    private lateinit var binding: ActivityLoginBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var qrKey = ""
    private var qrJob: Job? = null
    private var countdownJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Session.isLoggedIn()) {
            goMain()
            return
        }

        binding.tabLayout.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab) {
                val isQr = tab.position == 0
                binding.qrPanel.visibility = if (isQr) View.VISIBLE else View.GONE
                binding.phonePanel.visibility = if (isQr) View.GONE else View.VISIBLE
            }
            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab) {}
            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab) {}
        })

        // 从设置页进入时, 按选择预选登录方式
        val tab = intent.getIntExtra(EXTRA_TAB, 0)
        binding.tabLayout.getTabAt(tab.coerceIn(0, 1))?.select()

        setupQr()
        setupPhone()
    }

    // ---------------- 扫码登录 ----------------

    private fun setupQr() {
        binding.btnQrRefresh.setOnClickListener { refreshQr() }
        refreshQr()
    }

    private fun refreshQr() {
        qrJob?.cancel()
        binding.tvQrStatus.text = getString(R.string.qr_fetching)
        binding.qrImg.setImageDrawable(null)
        scope.launch {
            val key = withContext(Dispatchers.IO) { NeteaseApi.qrKey(this@LoginActivity) }
            if (key.isEmpty()) {
                binding.tvQrStatus.text = getString(R.string.qr_failed)
                return@launch
            }
            qrKey = key
            // 官方标准格式 (与 YesPlayMusic 等成熟客户端一致)
            val url = "https://music.163.com/login?codekey=$key"
            val bmp = withContext(Dispatchers.IO) { QrGen.generate(url, 512) }
            binding.qrImg.setImageBitmap(bmp)
            binding.tvQrStatus.text = getString(R.string.qr_waiting)
            startQrPolling()
        }
    }

    private fun startQrPolling() {
        qrJob?.cancel()
        qrJob = scope.launch {
            while (true) {
                delay(2000)
                val j = withContext(Dispatchers.IO) { NeteaseApi.qrCheck(this@LoginActivity, qrKey) }
                val code = j.optInt("code", -1)
                when (code) {
                    800 -> {
                        binding.tvQrStatus.text = getString(R.string.qr_expired)
                        qrJob?.cancel()
                    }
                    801 -> binding.tvQrStatus.text = getString(R.string.qr_waiting)
                    802 -> binding.tvQrStatus.text = getString(R.string.qr_scanned)
                    803 -> {
                        // 成功: 吸收 cookie (响应头已由底层处理, 此处兜底响应体 cookie 字段)
                        j.optString("cookie", "").takeIf { it.isNotBlank() }?.let {
                            Session.absorbCookieString(it)
                        }
                        binding.tvQrStatus.text = getString(R.string.login_success)
                        qrJob?.cancel()
                        onLoginSuccess()
                    }
                    else -> {
                        binding.tvQrStatus.text = j.optString("message", "登录状态异常($code)")
                    }
                }
            }
        }
    }

    // ---------------- 手机号验证码登录 ----------------

    private fun setupPhone() {
        binding.btnSendCode.setOnClickListener {
            val phone = binding.etPhone.text.toString().trim()
            if (phone.length < 6) {
                toast(getString(R.string.phone_hint))
                return@setOnClickListener
            }
            binding.btnSendCode.isEnabled = false
            binding.btnSendCode.text = getString(R.string.sending)
            scope.launch {
                val j = withContext(Dispatchers.IO) { NeteaseApi.sendCaptcha(this@LoginActivity, phone) }
                val code = j.optInt("code", -1)
                if (code == 200) {
                    toast(getString(R.string.code_sent))
                    startCountdown(60)
                } else {
                    binding.btnSendCode.isEnabled = true
                    binding.btnSendCode.text = getString(R.string.send_code)
                    toast(describeError(code, j))
                }
            }
        }

        binding.btnLogin.setOnClickListener {
            val phone = binding.etPhone.text.toString().trim()
            val captcha = binding.etCode.text.toString().trim()
            if (phone.length < 6) { toast(getString(R.string.phone_hint)); return@setOnClickListener }
            if (captcha.isEmpty()) { toast(getString(R.string.code_hint)); return@setOnClickListener }
            binding.btnLogin.isEnabled = false
            scope.launch {
                // 优先走 eapi 官方 App 接口(已修复 Device 版本号, 不再报"版本过低")
                // 若仍被风控, 再回退到 weapi 网页端接口重试
                var j = withContext(Dispatchers.IO) { NeteaseApi.loginByCaptchaEapi(this@LoginActivity, phone, captcha) }
                var code = j.optInt("code", -1)
                if (code != 200 && code != 503 && !Session.isLoggedIn()) {
                    j = withContext(Dispatchers.IO) { NeteaseApi.loginByCaptcha(this@LoginActivity, phone, captcha) }
                    code = j.optInt("code", -1)
                }
                binding.btnLogin.isEnabled = true
                if (code == 200 || Session.isLoggedIn()) {
                    toast(getString(R.string.login_success))
                    onLoginSuccess()
                } else {
                    toast(describeError(code, j))
                }
            }
        }
    }

    /** 把网易云错误码转成可读提示 */
    private fun describeError(code: Int, j: org.json.JSONObject): String {
        val msg = j.optString("message", j.optString("msg", ""))
        return when (code) {
            503 -> if (msg.isNotEmpty()) msg else "验证码错误或已过期"
            460, 461, 462 -> "登录被安全限制（风控），请先到官方网易云 App 登录一次，稍后再试或改用扫码登录"
            451 -> "操作过于频繁，请稍后再试"
            400 -> if (msg.isNotEmpty()) msg else "请求失败(400)"
            301 -> "未登录或登录态失效"
            else -> if (msg.isNotEmpty()) "请求失败($code): $msg" else "请求失败($code)"
        }
    }

    private fun startCountdown(total: Int) {
        countdownJob?.cancel()
        countdownJob = scope.launch {
            for (i in total downTo 0) {
                binding.btnSendCode.text = if (i > 0) "${i}s" else getString(R.string.send_code)
                binding.btnSendCode.isEnabled = i == 0
                delay(1000)
            }
        }
    }

    private fun onLoginSuccess() {
        scope.launch {
            withContext(Dispatchers.IO) { NeteaseApi.afterLogin(this@LoginActivity) }
            goMain()
        }
    }

    private fun goMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        startActivity(intent)
        finish()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        qrJob?.cancel()
        countdownJob?.cancel()
    }
}
