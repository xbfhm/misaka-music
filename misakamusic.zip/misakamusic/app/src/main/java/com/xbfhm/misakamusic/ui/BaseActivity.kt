package com.xbfhm.misakamusic.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import com.xbfhm.misakamusic.R

/**
 * 基础 Activity: 统一「流畅动态过渡动画」(namida 风格)
 *  - 前进: 新页面从右侧滑入, 旧页面向左滑出
 *  - 返回/关闭: 新页面(下层)从左滑入, 当前页向右滑出
 *  - 播放页用 openPageUp: 从底部滑入, 关闭时向下滑出
 */
open class BaseActivity : AppCompatActivity() {

    /** 返回/关闭时: 下层页面进入动画 */
    protected var backAnimIn: Int = R.anim.slide_in_left

    /** 返回/关闭时: 当前页面退场动画 */
    protected var backAnimOut: Int = R.anim.slide_out_right

    /** 标准前进过渡 (左右滑动) */
    protected fun openPage(intent: Intent) {
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    /** 从底部滑入 (播放页/底部弹层式页面) */
    protected fun openPageUp(intent: Intent) {
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_bottom, R.anim.slide_out_bottom)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(backAnimIn, backAnimOut)
    }
}
