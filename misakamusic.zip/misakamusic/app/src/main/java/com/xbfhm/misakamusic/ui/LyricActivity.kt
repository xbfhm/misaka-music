package com.xbfhm.misakamusic.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLyricBinding
import com.xbfhm.misakamusic.databinding.ItemLyricBinding
import com.xbfhm.misakamusic.model.LyricLine
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 歌词页: 滚动歌词 + 翻译, 随播放进度高亮当前行 */
class LyricActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLyricBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private val lines = mutableListOf<LyricLine>()
    private lateinit var adapter: LyricAdapter
    private lateinit var layoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLyricBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val song = PlayerEngine.currentSong()
        binding.tvTitle.text = song?.name ?: ""
        binding.tvArtist.text = song?.artists ?: ""

        binding.btnBack.setOnClickListener { finish() }

        adapter = LyricAdapter(this, lines)
        layoutManager = LinearLayoutManager(this)
        binding.rvLyric.layoutManager = layoutManager
        binding.rvLyric.adapter = adapter

        loadLyric()
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        ticker?.cancel()
    }

    private fun loadLyric() {
        val song = PlayerEngine.currentSong() ?: return
        scope.launch {
            val j = withContext(Dispatchers.IO) { NeteaseApi.lyric(this@LyricActivity, song.id) }
            val lrc = j.optJSONObject("lrc")?.optString("lyric", "") ?: ""
            val tlyric = j.optJSONObject("tlyric")?.optString("lyric", "") ?: ""
            val parsed = buildLines(lrc, tlyric)
            lines.clear()
            if (parsed.isEmpty()) {
                lines.add(LyricLine(0, "暂无歌词", ""))
            } else {
                lines.addAll(parsed)
            }
            adapter.notifyDataSetChanged()
        }
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(500)
                val pos = PlayerEngine.player.currentPosition
                val idx = findCurrentLine(pos)
                adapter.currentIndex = idx
                if (idx in 0 until adapter.itemCount) {
                    val offset = binding.rvLyric.height / 2
                    layoutManager.scrollToPositionWithOffset(idx, offset)
                }
            }
        }
    }

    private fun findCurrentLine(pos: Long): Int {
        if (lines.isEmpty()) return -1
        var idx = -1
        for (i in lines.indices) {
            if (lines[i].timeMs <= pos) idx = i else break
        }
        return if (idx >= 0) idx else 0
    }

    /** 解析 LRC 并合并翻译 */
    private fun buildLines(lrc: String, tlyric: String): List<LyricLine> {
        val main = parseLrc(lrc)
        val transMap = parseLrc(tlyric).associate { it.first to it.second }
        return main.map { (t, text) -> LyricLine(t, text, transMap[t].orEmpty()) }
    }

    private fun parseLrc(lrc: String): List<Pair<Long, String>> {
        val result = mutableListOf<Pair<Long, String>>()
        val regex = Regex("\\[(\\d{1,2}):(\\d{1,2})(?:[.:](\\d{1,3}))?\\]")
        for (raw in lrc.split("\n")) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val matches = regex.findAll(line).toList()
            if (matches.isEmpty()) continue
            val text = line.substringAfterLast("]").trim()
            if (text.isEmpty()) continue
            for (m in matches) {
                val min = m.groupValues[1].toIntOrNull() ?: continue
                val sec = m.groupValues[2].toIntOrNull() ?: continue
                val fracStr = m.groupValues[3]
                val frac = if (fracStr.isEmpty()) 0 else fracStr.padEnd(3, '0').take(3).toIntOrNull() ?: 0
                val ms = min * 60000L + sec * 1000L + frac
                result.add(ms to text)
            }
        }
        return result.sortedBy { it.first }
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
    }

    private class LyricAdapter(
        private val context: Context,
        private val lines: List<LyricLine>
    ) : RecyclerView.Adapter<LyricAdapter.VH>() {

        var currentIndex = -1
            set(value) {
                if (field == value) return
                val old = field
                field = value
                if (old in 0 until lines.size) notifyItemChanged(old)
                if (value in 0 until lines.size) notifyItemChanged(value)
            }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemLyricBinding.inflate(LayoutInflater.from(context), parent, false)
            return VH(b)
        }

        override fun getItemCount(): Int = lines.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(lines[position], position == currentIndex)
        }

        class VH(private val b: ItemLyricBinding) : RecyclerView.ViewHolder(b.root) {
            fun bind(line: LyricLine, highlight: Boolean) {
                b.tvLyric.text = line.text
                if (line.translation.isNotBlank()) {
                    b.tvLyricTrans.visibility = View.VISIBLE
                    b.tvLyricTrans.text = line.translation
                } else {
                    b.tvLyricTrans.visibility = View.GONE
                }
                val color = if (highlight) {
                    ContextCompat.getColor(b.root.context, R.color.net_red)
                } else {
                    android.graphics.Color.rgb(128, 128, 128)
                }
                b.tvLyric.setTextColor(color)
                if (highlight) {
                    b.tvLyric.textSize = 19f
                    b.tvLyricTrans.textSize = 15f
                } else {
                    b.tvLyric.textSize = 16f
                    b.tvLyricTrans.textSize = 13f
                }
            }
        }
    }
}
