package com.xbfhm.misakamusic.ui

import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ActivityLyricBinding
import com.xbfhm.misakamusic.databinding.ItemLyricBinding
import com.xbfhm.misakamusic.model.LyricLine
import com.xbfhm.misakamusic.model.Song
import com.xbfhm.misakamusic.net.NeteaseApi
import com.xbfhm.misakamusic.net.Session
import com.xbfhm.misakamusic.player.PlayMode
import com.xbfhm.misakamusic.player.PlayerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 歌词播放页 (namida 风格): 圆角封面 + 滚动歌词 + 波形进度条 + 完整播放控制。
 * 点击歌词行可精准跳转到对应进度。
 */
class LyricActivity : BaseActivity() {

    private lateinit var binding: ActivityLyricBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var ticker: Job? = null
    private var dragging = false
    private var manualScrollUntil = 0L

    private val lines = mutableListOf<LyricLine>()
    private lateinit var adapter: LyricAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private var loadedSongId = -1L
    /** 歌词偏移校准 (毫秒): 正值=歌词比音频慢, 负值=歌词比音频快 */
    private var lrcOffset = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLyricBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupEdgeToEdge()

        if (!PlayerEngine.hasQueue()) {
            finish()
            return
        }

        applyBlurBackground()

        binding.btnBack.setOnClickListener { finish() }
        binding.btnMode.setOnClickListener {
            PlayerEngine.toggleMode()
            updateModeIcon()
            toast(PlayerEngine.playModeLabel())
        }
        binding.btnTimer.setOnClickListener { showTimerDialog() }
        binding.btnPrev.setOnClickListener { PlayerEngine.prev() }
        binding.btnNext.setOnClickListener { PlayerEngine.next() }
        binding.btnPlay.setOnClickListener {
            PlayerEngine.togglePlayPause()
            updatePlayBtn()
        }
        binding.btnFav.setOnClickListener { onFavClick() }
        binding.waveSeek.onSeekListener = { ms ->
            dragging = false
            PlayerEngine.seekTo(ms.toLong())
        }

        // 歌词列表: 点击行精准跳转 / 长按校准偏移
        adapter = LyricAdapter(this, lines, { line ->
            PlayerEngine.seekTo((line.timeMs + lrcOffset).coerceAtLeast(0))
            adapter.currentIndex = lines.indexOf(line)
            adapter.notifyDataSetChanged()
            manualScrollUntil = System.currentTimeMillis() + 3000
        }, {
            showCalibrateDialog()
            true
        })
        layoutManager = LinearLayoutManager(this)
        binding.rvLyric.layoutManager = layoutManager
        binding.rvLyric.adapter = adapter

        updateModeIcon()
        renderSong(PlayerEngine.currentSong())
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        PlayerEngine.listener = { s -> runOnUiThread { renderSong(s) } }
        PlayerEngine.onPlayState = { runOnUiThread { updatePlayBtn() } }
        renderSong(PlayerEngine.currentSong())
        updatePlayBtn()
        startTicker()
    }

    override fun onPause() {
        super.onPause()
        PlayerEngine.listener = null
        PlayerEngine.onPlayState = null
        ticker?.cancel()
    }

    /** Edge-to-edge 沉浸式: 封面背景延伸到状态栏后, 内容顶栏避开状态栏 */
    private fun setupEdgeToEdge() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        val base = (10 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            binding.contentRoot.updatePadding(top = top + base)
            insets
        }
    }

    private fun applyBlurBackground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            binding.bgCover.setRenderEffect(
                RenderEffect.createBlurEffect(42f, 42f, Shader.TileMode.CLAMP)
            )
        } else {
            binding.bgCover.alpha = 0.45f
        }
    }

    private fun renderSong(song: Song?) {
        if (song == null) return
        binding.tvTitle.text = song.name
        binding.tvArtist.text = song.artists
        updateFavIcon(song)
        binding.tvDur.text = formatMs(song.duration)
        binding.waveSeek.max = song.duration.toInt().coerceAtLeast(1)
        binding.waveSeek.setWaveform(song.id)

        Glide.with(this)
            .load(song.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(binding.cover)
        Glide.with(this)
            .load(song.cover)
            .into(binding.bgCover)

        applyPalette(song.cover)
        updatePlayBtn()

        // 切歌时重新加载歌词
        if (song.id != loadedSongId) {
            loadedSongId = song.id
            loadLyric(song)
        }
    }

    private fun applyPalette(cover: String) {
        if (cover.isBlank()) {
            setAccent(0xFFFFFFFF.toInt())
            return
        }
        scope.launch {
            val palette = try {
                withContext(Dispatchers.IO) {
                    Glide.with(this@LyricActivity)
                        .asBitmap()
                        .load(cover)
                        .submit()
                        .get()
                        ?.let { Palette.from(it).generate() }
                }
            } catch (_: Exception) { null }
            if (palette == null) return@launch
            val swatch = palette.vibrantSwatch
                ?: palette.dominantSwatch
                ?: palette.mutedSwatch
                ?: return@launch
            runOnUiThread { setAccent(swatch.rgb) }
        }
    }

    private fun setAccent(color: Int) {
        binding.waveSeek.accentColor = color
        binding.btnPlay.backgroundTintList = ColorStateList.valueOf(color)
    }

    // ---------------- 歌词 ----------------

    private fun loadLyric(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) { NeteaseApi.lyric(this@LyricActivity, song.id) }
            val lrc = j.optJSONObject("lrc")?.optString("lyric", "") ?: ""
            val tlyric = j.optJSONObject("tlyric")?.optString("lyric", "") ?: ""
            val parsed = buildLines(lrc, tlyric)
            lines.clear()
            if (parsed.isEmpty()) {
                lines.add(LyricLine(0, "暂无歌词", ""))
            } else {
                lines.addAll(parsed)
            }
            adapter.currentIndex = -1
            adapter.notifyDataSetChanged()
        }
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (true) {
                delay(400)
                val pos = PlayerEngine.player.currentPosition
                if (!dragging) {
                    binding.waveSeek.progress = pos.toInt()
                    binding.tvCur.text = formatMs(pos)
                }
                updatePlayBtn()
                updateLyricHighlight(pos)
            }
        }
    }

    /** 高亮当前歌词行 + 自动滚动 (手动跳转后短暂暂停自动滚动) */
    private fun updateLyricHighlight(pos: Long) {
        val idx = findCurrentLine(pos)
        adapter.currentIndex = idx
        if (idx in 0 until adapter.itemCount) {
            if (System.currentTimeMillis() >= manualScrollUntil) {
                val offset = binding.rvLyric.height / 2
                layoutManager.scrollToPositionWithOffset(idx, offset)
            }
        }
    }

    private fun findCurrentLine(pos: Long): Int {
        if (lines.isEmpty()) return -1
        var idx = -1
        for (i in lines.indices) {
            if (lines[i].timeMs + lrcOffset <= pos) idx = i else break
        }
        return if (idx >= 0) idx else 0
    }

    /** 歌词偏移校准 (像网易云一样手动对齐歌词) */
    private fun showCalibrateDialog() {
        val options = arrayOf(
            "-3秒", "-1秒", "-500毫秒", "重置", "+500毫秒", "+1秒", "+3秒"
        )
        val deltas = listOf(-3000L, -1000L, -500L, 0L, 500L, 1000L, 3000L)
        MaterialAlertDialogBuilder(this)
            .setTitle("歌词校准（当前 ${lrcOffset}ms）\n长按歌词也可校准")
            .setItems(options) { _: DialogInterface?, which: Int ->
                lrcOffset += deltas[which]
                toast("歌词偏移：${lrcOffset}ms")
                adapter.notifyDataSetChanged()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /** 解析 LRC 并合并翻译 */
    private fun buildLines(lrc: String, tlyric: String): List<LyricLine> {
        val main = parseLrc(lrc)
        val transMap = parseLrc(tlyric).associate { it.first to it.second }
        return main.map { (t, text) -> LyricLine(t, text, transMap[t].orEmpty()) }
    }

    private fun parseLrc(lrc: String): List<Pair<Long, String>> {
        val result = mutableListOf<Pair<Long, String>>()
        val regex = Regex("\\[(\\d{1,2}):(\\d{1,2})(?:[.:](\\d{1,3}))?\\]")
        for (raw in lrc.split("\n")) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val matches = regex.findAll(line).toList()
            if (matches.isEmpty()) continue
            val text = line.substringAfterLast("]").trim()
            if (text.isEmpty()) continue
            for (m in matches) {
                val min = m.groupValues[1].toIntOrNull() ?: continue
                val sec = m.groupValues[2].toIntOrNull() ?: continue
                val fracStr = m.groupValues[3]
                val frac = if (fracStr.isEmpty()) 0 else fracStr.padEnd(3, '0').take(3).toIntOrNull() ?: 0
                val ms = min * 60000L + sec * 1000L + frac
                result.add(ms to text)
            }
        }
        return result.sortedBy { it.first }
    }

    // ---------------- 收藏 ----------------

    private fun updateFavIcon(song: Song) {
        val liked = if (Session.isLoggedIn()) Session.isLiked(song.id) else Session.isLocalLiked(song.id)
        binding.btnFav.setImageResource(
            if (liked) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
        val tint = ContextCompat.getColor(
            this,
            if (liked) R.color.net_red else android.R.color.white
        )
        binding.btnFav.setColorFilter(tint)
    }

    private fun onFavClick() {
        val song = PlayerEngine.currentSong() ?: return
        if (Session.isLoggedIn()) {
            if (Session.isLiked(song.id)) {
                unlikeSong(song)
            } else {
                likeSong(song)
            }
        } else {
            val liked = Session.toggleLocalLiked(song.id)
            updateFavIcon(song)
            toast(
                if (liked) getString(R.string.fav_success_local)
                else getString(R.string.fav_cancel_local)
            )
        }
    }

    private fun likeSong(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@LyricActivity, song.id, true)
            }
            if (j.optInt("code", -1) == 200) {
                Session.setLiked(song.id, true)
                updateFavIcon(song)
                toast(getString(R.string.fav_success))
            } else {
                toast(getString(R.string.fav_fail))
            }
        }
    }

    private fun unlikeSong(song: Song) {
        scope.launch {
            val j = withContext(Dispatchers.IO) {
                NeteaseApi.likeSong(this@LyricActivity, song.id, false)
            }
            if (j.optInt("code", -1) == 200) {
                Session.setLiked(song.id, false)
                updateFavIcon(song)
                toast(getString(R.string.fav_cancel))
            } else {
                toast(getString(R.string.fav_fail))
            }
        }
    }

    // ---------------- 播放控制 UI ----------------

    private fun updatePlayBtn() {
        val playing = PlayerEngine.isPlaying()
        binding.btnPlay.setImageResource(
            if (playing) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateModeIcon() {
        val icon = when (PlayerEngine.mode) {
            PlayMode.ORDER -> R.drawable.ic_order
            PlayMode.LOOP -> R.drawable.ic_repeat
            PlayMode.SHUFFLE -> R.drawable.ic_shuffle
        }
        binding.btnMode.setImageResource(icon)
    }

    private fun showTimerDialog() {
        val options = arrayOf("15 ${getString(R.string.sleep_minutes)}", "30 ${getString(R.string.sleep_minutes)}", "45 ${getString(R.string.sleep_minutes)}", "60 ${getString(R.string.sleep_minutes)}", getString(R.string.sleep_cancel))
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.sleep_timer))
            .setItems(options) { _: DialogInterface?, which: Int ->
                when (which) {
                    0, 1, 2, 3 -> {
                        PlayerEngine.setSleepTimer(listOf(15, 30, 45, 60)[which])
                        toast("${options[which]}后自动停止播放")
                    }
                    4 -> {
                        PlayerEngine.cancelSleepTimer()
                        toast(getString(R.string.sleep_canceled))
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
    }

    private class LyricAdapter(
        private val context: Context,
        private val lines: List<LyricLine>,
        private val onItemClick: (LyricLine) -> Unit,
        private val onLongClick: () -> Boolean
    ) : RecyclerView.Adapter<LyricAdapter.VH>() {

        var currentIndex = -1
            set(value) {
                if (field == value) return
                val old = field
                field = value
                if (old in 0 until lines.size) notifyItemChanged(old)
                if (value in 0 until lines.size) notifyItemChanged(value)
            }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemLyricBinding.inflate(LayoutInflater.from(context), parent, false)
            return VH(b)
        }

        override fun getItemCount(): Int = lines.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(lines[position], position == currentIndex)
            holder.itemView.setOnClickListener { onItemClick(lines[position]) }
            holder.itemView.setOnLongClickListener { onLongClick() }
        }

        class VH(private val b: ItemLyricBinding) : RecyclerView.ViewHolder(b.root) {
            fun bind(line: LyricLine, highlight: Boolean) {
                b.tvLyric.text = line.text
                if (line.translation.isNotBlank()) {
                    b.tvLyricTrans.visibility = View.VISIBLE
                    b.tvLyricTrans.text = line.translation
                } else {
                    b.tvLyricTrans.visibility = View.GONE
                }
                val color = if (highlight) {
                    ContextCompat.getColor(b.root.context, R.color.namida_primary)
                } else {
                    android.graphics.Color.rgb(190, 190, 190)
                }
                b.tvLyric.setTextColor(color)
                if (highlight) {
                    b.tvLyric.textSize = 19f
                    b.tvLyricTrans.textSize = 15f
                } else {
                    b.tvLyric.textSize = 16f
                    b.tvLyricTrans.textSize = 13f
                }
            }
        }
    }
}
