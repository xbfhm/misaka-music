package com.xbfhm.misakamusic.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xbfhm.misakamusic.R
import com.xbfhm.misakamusic.databinding.ItemSongBinding
import com.xbfhm.misakamusic.model.Song

class SongAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.VH>() {

    private val items = mutableListOf<Song>()
    var currentIndex: Int = -1

    fun submit(list: List<Song>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val playing = position == currentIndex
        val ctx = holder.binding.root.context

        holder.binding.tvName.text = (if (playing) "♪ " else "") + s.name
        holder.binding.tvName.setTextColor(
            if (playing) ContextCompat.getColor(ctx, R.color.namida_primary)
            else textColorPrimary(ctx)
        )
        holder.binding.tvInfo.text =
            listOf(s.artists, s.album).filter { it.isNotBlank() }.joinToString(" · ")
        holder.binding.tvVip.visibility =
            if (s.fee > 0) View.VISIBLE else View.GONE
        holder.binding.tvDur.text = formatMs(s.duration)
        Glide.with(holder.binding.cover)
            .load(s.cover)
            .placeholder(R.drawable.ic_music_note)
            .error(R.drawable.ic_music_note)
            .into(holder.binding.cover)
        holder.binding.root.setOnClickListener { onClick(position) }
    }

    private fun textColorPrimary(context: Context): Int {
        val ta = context.obtainStyledAttributes(intArrayOf(android.R.attr.textColorPrimary))
        val color = ta.getColor(0, 0xFF000000.toInt())
        ta.recycle()
        return color
    }

    private fun formatMs(ms: Long): String {
        if (ms <= 0) return "--:--"
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    class VH(val binding: ItemSongBinding) : RecyclerView.ViewHolder(binding.root)
}
