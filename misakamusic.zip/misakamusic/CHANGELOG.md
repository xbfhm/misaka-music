# 更新日志 CHANGELOG

## [未发布] - 2026-08-27

### 关于页（About）

- 新增「联系方式」卡片：作者「西北风喝吗」、QQ `2563805214`
- 新增「项目仓库」卡片：`https://github.com/xbfhm/misaka-music`（可点击跳转）
- 免责声明扩展至 7 条，覆盖：非商用、与网易云无关联、不存储/传播音频、账号行为归属用户、法律责任自负、接口变动免责、第三方改版免责

### 新功能

- 🎚️ **音质选择**：设置页新增音质切换，五档可选
  - 标准 128kbps → 较高 192kbps → 极高 320kbps → 无损 FLAC → Hi-Res 母带级
  - 播放时按所选音质逐级尝试，拿不到自动降级
- ❤️ **收藏歌曲**
  - 已登录：可加入「我喜欢的音乐」或任选歌单
  - 未登录：本地收藏（SharedPreferences 存储）
  - 播放页歌名旁新增红心按钮
- 🎧 **后台播放**：接入 Media3 MediaSession，支持状态栏媒体卡片、灵动岛、锁屏与蓝牙耳机控制
- 🌐 **歌曲翻译名**：日文等外文歌曲在播放页显示中文译名/别名

### 修复

- 收藏歌单接口修正：`/api/playlist/subscribe` 改为按动作区分 `subscribe` / `unsubscribe`
- VIP 信息接口修正：`vip_info` 改用 eapi，正确读取黑胶等级 `redVipLevel` 与音乐包到期时间 `musicPackage.expireTime`
